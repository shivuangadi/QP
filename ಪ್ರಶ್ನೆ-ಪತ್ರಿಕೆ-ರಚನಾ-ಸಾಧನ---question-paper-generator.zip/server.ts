/**
 * Full-Stack Server: Express + Vite Middleware with Gemini Multimodal LBA PDF Extraction
 * Author: S R Angadi / M I Nilaji
 */

import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Generous JSON body parser limit for large PDF base64 payloads
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ extended: true, limit: '60mb' }));

// Ensure user_banks directory exists
const userBanksDir = path.join(__dirname, 'public', 'assets', 'user_banks');
if (!fs.existsSync(userBanksDir)) {
  fs.mkdirSync(userBanksDir, { recursive: true });
}

// User banks index file
const userBanksIndexPath = path.join(userBanksDir, 'index.json');
if (!fs.existsSync(userBanksIndexPath)) {
  fs.writeFileSync(userBanksIndexPath, JSON.stringify({ files: [] }, null, 2), 'utf8');
}

// Initialize Gemini Client
const ai = new GoogleGenAI();

/**
 * Health check & Gemini API Key verification
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    port: PORT,
  });
});

/**
 * Safely parse JSON from Gemini response, stripping markdown fences if present
 */
function parseGeminiJson(rawText: string): any {
  if (!rawText || !rawText.trim()) return {};
  let cleaned = rawText.trim();
  // Strip ```json ... ``` or ``` ... ```
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\s*\n?/, '').replace(/\n?```\s*$/, '');
  }
  return JSON.parse(cleaned);
}

/**
 * Candidate models with fallback sequence.
 * gemini-3.5-flash and gemini-3.6-flash have high free quota and excellent multimodal capability.
 */
const CANDIDATE_MODELS = [
  'gemini-3.8-flash',
  'gemini-3.5-flash',
  'gemini-3.6-flash',
  'gemini-flash-lite-latest',
];

/**
 * Execute Gemini content generation with automatic multi-model fallback on 429 quota exhaustion or 503 high demand.
 */
async function generateWithFallback(options: {
  contents: any[];
  config?: any;
}): Promise<{ text: string; modelUsed: string }> {
  let lastError: any = null;

  for (const model of CANDIDATE_MODELS) {
    try {
      console.log(`[Gemini SDK] Requesting with model: ${model}`);
      const response = await ai.models.generateContent({
        model,
        contents: options.contents,
        config: options.config,
      });
      console.log(`[Gemini SDK] Model ${model} succeeded!`);
      return { text: response.text || '{}', modelUsed: model };
    } catch (err: any) {
      console.warn(`[Gemini SDK] Model ${model} failed:`, err?.message || err);
      lastError = err;
      const msg = String(err?.message || '');
      const code = err?.status || err?.code;

      // Check if quota exceeded (429), high demand (503), or deprecated (404)
      if (
        code === 429 ||
        code === 503 ||
        code === 404 ||
        msg.includes('429') ||
        msg.includes('503') ||
        msg.includes('RESOURCE_EXHAUSTED') ||
        msg.includes('quota') ||
        msg.includes('rate-limits')
      ) {
        console.log(`[Gemini SDK] Quota limit or busy on ${model}. Switching to next model...`);
        continue;
      }
      throw err;
    }
  }

  throw lastError || new Error('All available Gemini models are currently exhausted or unavailable.');
}

/**
 * API: Scan LBA PDF Table of Contents & Structure
 * Uses Gemini multimodal vision to analyze syllabus, chapters, and question/answer page ranges.
 */
app.post('/api/ai/scan-lba-pdf', async (req, res) => {
  console.log(`[/api/ai/scan-lba-pdf] Received scan request`);
  try {
    const { base64Pdf, fileName } = req.body;

    if (!base64Pdf) {
      return res.status(400).json({ error: 'PDF data is required (PDF ಡೇಟಾ ಅಗತ್ಯವಿದೆ).' });
    }

    const cleanBase64 = base64Pdf.replace(/^data:application\/pdf;base64,/, '');
    const byteLength = Buffer.byteLength(cleanBase64, 'base64');
    console.log(`[/api/ai/scan-lba-pdf] Payload size: ${(byteLength / 1024).toFixed(1)} KB for ${fileName || 'unnamed.pdf'}`);

    const prompt = `Analyze this Karnataka DSERT LBA (Learning Outcomes Based Assessment / ಕಲಿಕಾಫಲ ಆಧಾರಿತ ಮೌಲ್ಯಾಂಕನ) or Karnataka State Textbook PDF document.
Identify document metadata, all chapter/unit titles, and automatically detect WHERE QUESTIONS & ANSWERS are located.

CRITICAL INSTRUCTIONS FOR AUTOMATIC UNIT QUESTION & ANSWER PAGE DETECTION:
1. UNIT NAME & CHAPTER DETECTION:
   - Identify every unit/chapter in the syllabus index (ಅಧ್ಯಾಯಗಳು / ಪಾಠಗಳು).
   - Capture exact Kannada names and unit numbers.
2. QUESTION & EXERCISE PAGE DETECTION (ಅಭ್ಯಾಸ ಮತ್ತು ಪ್ರಶ್ನೆ ಪುಟಗಳು):
   - For EACH unit, automatically detect the physical PDF pages containing the evaluation questions, exercises, or question bank (ಅಭ್ಯಾಸ, ಪ್ರಶ್ನೋತ್ತರ, ಮೌಲ್ಯಮಾಪನ, Exercise, Questions, Q&A).
   - In LBA question bank books, each unit typically has dedicated question pages (e.g., "15-22").
   - Provide "questionPages": the exact PDF page range (e.g. "15-22") where questions for that unit are found.
   - If question pages cannot be conclusively segregated from the index, provide the full unit range so the user can review or manually adjust.
3. ANSWER PAGES DETECTION (ಉತ್ತರ ಸೂಚಿ ಪುಟಗಳು):
   - Locate where the official Model Answers / Solutions / ಮಾದರಿ ಉತ್ತರಗಳು / ಉತ್ತರ ಸೂಚಿ are placed:
     - End of book global key (e.g. pages "85-110") -> populate in metadata.globalAnswerPages.
     - Or unit-wise answer key -> populate in "answerPages" for that unit.
4. PAGE NUMBER OFFSET:
   - If printed page 1 starts after prelim pages (e.g. PDF page 7), calculate "prelimOffset" (e.g. 6).
   - "printedPages": page range as printed in the book's index.
   - "questionPages": actual physical PDF page range in the PDF viewer.

Return STRICT JSON matching this exact structure:
{
  "metadata": {
    "title": "String title in Kannada/English",
    "grade": "e.g. 7 ನೇ ತರಗತಿ (Class 7)",
    "gradeKey": "7",
    "subject": "e.g. ವಿಜ್ಞಾನ (Science)",
    "subjectCode": "SCI",
    "medium": "ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)",
    "academicYear": "2026-27",
    "department": "ಕರ್ನಾಟಕ ಸರ್ಕಾರ, ಶಾಲಾ ಶಿಕ್ಷಣ ಮತ್ತು ಸಾಕ್ಷರತಾ ಇಲಾಖೆ",
    "institution": "DSERT ಬೆಂಗಳೂರು",
    "totalChapters": 0,
    "prelimOffset": 0,
    "globalAnswerPages": "85-110"
  },
  "learningOutcomes": [
    { "code": "LO 1", "title": "ಕಲಿವಿನ ಫಲ ಶೀರ್ಷಿಕೆ" }
  ],
  "chapters": [
    {
      "chapterNumber": 1,
      "chapterId": "ch-1",
      "chapterName": "ಪಾಠದ ಹೆಸರು",
      "sectionType": "ಗದ್ಯಭಾಗ / ಪಾಠ / ಘಟಕ",
      "semester": 1,
      "weightagePercent": 15,
      "weightageMarks": 10,
      "learningOutcomes": ["LO 1", "LO 2"],
      "printedPages": "1-10",
      "questionPages": "1-10",
      "answerPages": "85-88",
      "qaDetected": true
    }
  ]
}
Do not include markdown fences outside the JSON.`;

    const { text, modelUsed } = await generateWithFallback({
      contents: [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                mimeType: 'application/pdf',
                data: cleanBase64,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = parseGeminiJson(text);
    console.log(`[/api/ai/scan-lba-pdf] Scan successful via ${modelUsed}: found ${parsed.chapters?.length || 0} chapters`);
    return res.json({ success: true, data: parsed, modelUsed });
  } catch (error: any) {
    console.error('Error scanning LBA PDF:', error);
    return res.status(500).json({
      error: error.message || 'Failed to analyze LBA PDF structure.',
    });
  }
});

/**
 * API: Extract Questions & Match Answers for a Chapter/Page Range
 * Extracts Kannada text verbatim using OCR, categorizes question formats, and pairs with answer keys.
 */
app.post('/api/ai/extract-chapter', async (req, res) => {
  try {
    const {
      base64Pdf,
      chapterName,
      chapterNumber,
      questionPages,
      answerPages,
      metadata,
    } = req.body;

    if (!base64Pdf) {
      return res.status(400).json({ error: 'PDF data is required.' });
    }

    const cleanBase64 = base64Pdf.replace(/^data:application\/pdf;base64,/, '');
    const byteLength = Buffer.byteLength(cleanBase64, 'base64');
    console.log(`[/api/ai/extract-chapter] Processing Ch ${chapterNumber}: "${chapterName}", slice size: ${(byteLength / 1024).toFixed(1)} KB`);

    const prompt = `You are a high-precision Kannada OCR and educational assessment extractor.
Extract ALL questions and their EXACT matching answers for Chapter ${chapterNumber}: "${chapterName}" from this Karnataka DSERT LBA PDF.
Target Question Pages: ${questionPages || 'Entire Chapter'}
Target Answer Key Pages: ${answerPages || 'Back of chapter or end of book'}

CRITICAL RULES:
1. STRICT VERBATIM: Do not invent, modify, rephrase, or translate questions or answers. Extract exact text with complete Unicode accuracy.
2. COMPLETE COVERAGE & DISCRETE SUB-QUESTIONS:
   - If a heading like "ಒಂದು ವಾಕ್ಯದಲ್ಲಿ ಉತ್ತರಿಸಿ / एक वाक्य में उत्तर लिखिए" contains multiple numbered sub-questions (1, 2, 3... 11), DO NOT bundle them into one question! Extract EACH individual sub-question as its own separate question item in the array, each with its own question text, matching answer, and marks: 1.
3. MATCH ANSWERS:
   - Carefully lookup and match the official answer from the answer key pages.
   - For MCQs, include the correct option letter and answer text (e.g. "B) 4" or "ಅ) ಮಿಥಿಲೆಯ ರಾಜ").
   - If an answer is given in the key, attach it to the question's \`answer\` field.
   - If an answer is genuinely absent in the key, write "ಉತ್ತರವನ್ನು ಪರಿಶೀಲಿಸಿ".
4. QUESTION FORMAT CATEGORY & ACCURATE MARKS:
   - "mcq" for 4-option multiple choice questions (marks: 1)
   - "fill_blank" for fill in the blank questions with blanks (marks: 1)
   - "true_false" for true/false statements (marks: 1)
   - "analogy" for sambandha kalpisi (marks: 1)
   - "match" for match the following (MUST include "items" array with all left and right pairs. Marks MUST EQUAL the number of sub-items/pairs: 4 pairs = 4 marks, 5 pairs = 5 marks, 6 pairs = 6 marks! Each pair is 1 mark).
   - "one_sentence" for 1-sentence answers (marks: 1 per question)
   - "short_2m" for 2-mark brief answers (marks: 2)
   - "short_3m" for 3-mark descriptive answers (marks: 3)
   - "long_4m" for 4-mark detailed questions/diagrams (marks: 4)
5. EDUCATIONAL OBJECTIVE (ಉದ್ದಿಷ್ಟ):
   Classify every question into one of the 4 Karnataka DSERT standard objectives:
   - "ಜ್ಞಾನ" (Knowledge): Recall, naming, defining, stating facts.
   - "ತಿಳುವಳಿಕೆ" (Understanding): Explaining, distinguishing, giving reasons, summarizing.
   - "ಅನ್ವಯ" (Application): Problem solving, numerical calculations, applying concepts to situations.
   - "ಕೌಶಲ" (Skill): Diagrams, drawing, map marking, labeling parts, experimental apparatus.
   Ensure balanced representation across all 4 objectives!
6. DIFFICULTY (ಕ್ಲಿಷ್ಟತೆ):
   - "ಸುಲಭ" (Easy)
   - "ಸಾಧಾರಣ" (Average / Medium)
   - "ಕಠಿಣ" (Difficult)

Return a JSON object:
{
  "chapterId": "ch-${chapterNumber}",
  "chapterNumber": ${chapterNumber},
  "chapterName": "${chapterName}",
  "semester": ${chapterNumber > 5 ? 2 : 1},
  "extractedQuestionsCount": 0,
  "questions": [
    {
      "id": "q-${chapterNumber}-1",
      "question_number": 1,
      "type": "mcq / fill_blank / one_sentence / short_2m / short_3m / long_4m / match",
      "formatCategoryId": "mcq",
      "formatCategoryName": "೧. ಬಹು ಆಯ್ಕೆ (1M)",
      "question": "ನಿಖರವಾದ ಪ್ರಶ್ನೆ ಕನ್ನಡದಲ್ಲಿ",
      "options": ["ಅ) ಆಯ್ಕೆ ೧", "ಆ) ಆಯ್ಕೆ ೨", "ಇ) ಆಯ್ಕೆ ೩", "ಈ) ಆಯ್ಕೆ ೪"],
      "items": [{"left": "1. ಎಡ", "right": "ಅ. ಬಲ"}],
      "marks": 1,
      "objective": "ಜ್ಞಾನ / ತಿಳುವಳಿಕೆ / ಅನ್ವಯ / ಕೌಶಲ",
      "difficulty": "ಸುಲಭ / ಸಾಧಾರಣ / ಕಠಿಣ",
      "learning_outcome": "LO 1",
      "answer": "ಸಂಪೂರ್ಣ ಅಧಿಕೃತ ಉತ್ತರ",
      "hasDiagram": false,
      "diagramDescription": "ಚಿತ್ರದ ವಿವರಣೆ (ಚಿತ್ರ ಆಧಾರಿತ ಪ್ರಶ್ನೆಯಾಗಿದ್ದರೆ)"
    }
  ]
}
Do not output markdown codeblocks outside the JSON.`;

    const { text, modelUsed } = await generateWithFallback({
      contents: [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                mimeType: 'application/pdf',
                data: cleanBase64,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = parseGeminiJson(text);
    console.log(`[/api/ai/extract-chapter] Ch ${chapterNumber} extraction complete via ${modelUsed}: ${parsed.questions?.length || 0} questions`);
    return res.json({ success: true, data: parsed, modelUsed });
  } catch (error: any) {
    console.error('Error extracting chapter:', error);
    return res.status(500).json({
      error: error.message || 'Failed to extract questions from chapter.',
    });
  }
});

/**
 * API: Save Generated Question Bank JSON to Server
 * Writes to public/assets/user_banks and registers in index so it can be loaded into Question Paper Generator!
 */
// Static file serving for user banks and public assets
app.use('/assets/user_banks', express.static(userBanksDir));
app.use('/assets', express.static(path.join(__dirname, 'public', 'assets')));

/**
 * Dynamically scans user_banks directory on disk, parses JSON files,
 * deduces proper Grade and Subject codes, and synchronizes index.json.
 * This guarantees that ANY question bank JSON file placed on disk or uploaded
 * is permanently indexed and immediately available in the UI dropdowns.
 */
function syncUserBanks(): { files: any[] } {
  if (!fs.existsSync(userBanksDir)) {
    fs.mkdirSync(userBanksDir, { recursive: true });
  }
  const diskFiles = fs.readdirSync(userBanksDir).filter(f => f.endsWith('.json') && f !== 'index.json');
  const entries: any[] = [];

  for (const filename of diskFiles) {
    try {
      const fullPath = path.join(userBanksDir, filename);
      const raw = fs.readFileSync(fullPath, 'utf8');
      const content = JSON.parse(raw);
      if (content && content.chapters && Array.isArray(content.chapters)) {
        const meta = content.metadata || {};
        const rawGrade = String(meta.grade || meta.gradeKey || filename || '');
        const gradeMatch = rawGrade.match(/(\d+)/);
        const gradeKey = meta.gradeKey || (gradeMatch ? gradeMatch[1] : '7');
        const grade = meta.grade || `${gradeKey} ನೇ ತರಗತಿ (Class ${gradeKey})`;
        const subject = meta.subject || filename.replace('.json', '');

        // Standard subjectCode deduction
        let subjectCode = meta.subjectCode;
        if (!subjectCode) {
          const s = String(subject).toLowerCase();
          if (s.includes('ಸಮಾಜ') || s.includes('social')) subjectCode = 'SOC';
          else if (s.includes('ವಿಜ್ಞಾನ') || s.includes('science')) subjectCode = 'SCI';
          else if (s.includes('ಗಣಿತ') || s.includes('math')) subjectCode = 'MATH';
          else if (s.includes('ಕನ್ನಡ') || s.includes('kannada')) subjectCode = 'KAN';
          else if (s.includes('ಇಂಗ್ಲಿಷ್') || s.includes('english')) subjectCode = 'ENG';
          else if (s.includes('ಹಿಂದಿ') || s.includes('hindi') || s.includes('हिंदी')) subjectCode = 'HIN';
          else subjectCode = 'GEN';
        }

        const id = meta.id || `bank_${filename.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9_]/g, '_')}`;
        entries.push({
          id,
          path: `/assets/user_banks/${encodeURI(filename)}`,
          filename,
          grade,
          gradeKey,
          subject,
          subjectCode,
          medium: meta.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
          academicYear: meta.academicYear || '2026-27',
          totalChapters: content.chapters.length,
          totalQuestions: content.chapters.reduce(
            (sum: number, c: any) => sum + (c.questions?.length || 0),
            0
          ),
          isUserGenerated: true,
          createdAt: meta.createdAt || new Date().toISOString(),
        });
      }
    } catch (e: any) {
      console.error(`Error indexing user bank ${filename}:`, e.message);
    }
  }

  // Sort: newest first or alphabetical
  entries.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));

  const result = { files: entries };
  try {
    fs.writeFileSync(userBanksIndexPath, JSON.stringify(result, null, 2), 'utf8');
  } catch (e: any) {
    console.error('Error updating index.json:', e.message);
  }
  return result;
}

// Initial sync on server start
syncUserBanks();

/**
 * API: Save Generated Question Bank JSON to Server
 * Writes to public/assets/user_banks and registers in index so it can be loaded into Question Paper Generator!
 */
app.post('/api/save-question-bank', (req, res) => {
  try {
    const { questionBank } = req.body;

    if (!questionBank || !questionBank.metadata || !questionBank.chapters) {
      return res.status(400).json({ error: 'Invalid question bank JSON schema.' });
    }

    const grade = questionBank.metadata.grade || '7ನೇ ತರಗತಿ';
    const subject = questionBank.metadata.subject || 'ವಿಷಯ';
    const safeSub = subject.replace(/[^a-zA-Z0-9_\u0C80-\u0CFF]/g, '_').slice(0, 30);
    const id = questionBank.metadata.id || `bank_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const filename = `${safeSub}_${id}.json`;
    const filePath = path.join(userBanksDir, filename);

    // Save JSON file
    fs.writeFileSync(filePath, JSON.stringify(questionBank, null, 2), 'utf8');

    // Run dynamic sync across disk files to update index.json
    const indexData = syncUserBanks();
    const createdEntry = indexData.files.find(f => f.filename === filename) || {
      id,
      path: `/assets/user_banks/${encodeURI(filename)}`,
      filename,
      grade,
      subject,
    };

    return res.json({
      success: true,
      message: 'Question bank saved permanently and indexed!',
      entry: createdEntry,
      downloadUrl: `/assets/user_banks/${encodeURI(filename)}`,
    });
  } catch (error: any) {
    console.error('Error saving question bank:', error);
    return res.status(500).json({ error: error.message || 'Failed to save question bank.' });
  }
});

/**
 * API: List User-Saved Question Banks
 */
app.get('/api/saved-question-banks', (req, res) => {
  try {
    const data = syncUserBanks();
    return res.json(data);
  } catch (error: any) {
    return res.json({ files: [] });
  }
});

// Setup Vite Dev Middleware in Dev, or Static Hosting in Prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: PORT,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
