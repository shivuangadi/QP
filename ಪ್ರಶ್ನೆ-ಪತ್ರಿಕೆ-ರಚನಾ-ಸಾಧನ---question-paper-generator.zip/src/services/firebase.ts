/**
 * Firebase Client Service
 * Initializes Firebase App and Firestore using firebase-applet-config.json
 * Provides cloud persistence for Question Banks and Question Papers
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  getDocs,
  collection,
  deleteDoc,
  getDocFromServer,
  query,
  orderBy,
  Firestore,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { QuestionBank, GeneratedPaper } from '../types/questionBank.ts';

// Initialize Firebase App singleton
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore targeting the specific databaseId if provided
export const db: Firestore = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Test connection on boot
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('Firebase Firestore connection verified successfully.');
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline. Check network or configuration.');
    } else {
      console.log('Firebase connection initialized:', (error as Error).message);
    }
    return false;
  }
}

// Automatically test connection
testFirestoreConnection();

/**
 * Save a Question Bank to Firebase Firestore
 */
export function deduceSubjectCodeFirebase(subjectStr: string | undefined | null): string {
  if (!subjectStr) return 'GEN';
  const s = String(subjectStr).toLowerCase();
  if (s === 'soc' || s.includes('ಸಮಾಜ') || s.includes('social')) return 'SOC';
  if (s === 'sci' || s.includes('ವಿಜ್ಞಾನ') || s.includes('science')) return 'SCI';
  if (s === 'math' || s.includes('ಗಣಿತ') || s.includes('math')) return 'MATH';
  if (s === 'kan' || s.includes('ಕನ್ನಡ') || s.includes('kannada')) return 'KAN';
  if (s === 'eng' || s.includes('ಇಂಗ್ಲಿಷ್') || s.includes('english')) return 'ENG';
  if (s === 'hin' || s.includes('ಹಿಂದಿ') || s.includes('hindi')) return 'HIN';
  return 'GEN';
}

/**
 * Save a Question Bank to Firebase Firestore
 */
export async function saveQuestionBankToFirebase(bank: QuestionBank): Promise<string> {
  const bankId: string =
    typeof bank.metadata.id === 'string' && bank.metadata.id
      ? bank.metadata.id
      : `bank_${Date.now()}`;
  const docRef = doc(db, 'question_banks', bankId);
  const subjectCode = deduceSubjectCodeFirebase(String(bank.metadata.subjectCode || bank.metadata.subject || ''));

  const payload = {
    id: bankId,
    title: bank.metadata.title || `${bank.metadata.grade} ${bank.metadata.subject}`,
    grade: bank.metadata.grade,
    gradeKey: bank.metadata.gradeKey,
    subject: bank.metadata.subject,
    subjectCode,
    medium: bank.metadata.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
    academicYear: bank.metadata.academicYear || '2026-27',
    totalChapters: bank.chapters.length,
    totalQuestions: bank.chapters.reduce((sum, ch) => sum + (ch.questions?.length || 0), 0),
    metadata: {
      ...bank.metadata,
      id: bankId,
      subjectCode,
    },
    chapters: bank.chapters,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  await setDoc(docRef, payload);
  return bankId;
}

/**
 * Fetch all Question Banks saved in Firebase Firestore
 */
export async function getQuestionBanksFromFirebase(): Promise<QuestionBank[]> {
  try {
    const colRef = collection(db, 'question_banks');
    const snapshot = await getDocs(colRef);
    const banks: QuestionBank[] = [];

    snapshot.forEach(d => {
      const data = d.data();
      if (data && data.chapters) {
        const rawMeta = (data.metadata || {}) as Record<string, unknown>;
        const docId = String(d.id || data.id || rawMeta.id || '');
        const subjectCode = deduceSubjectCodeFirebase(
          String(rawMeta.subjectCode || data.subjectCode || rawMeta.subject || data.subject || '')
        );

        banks.push({
          metadata: {
            title: String(rawMeta.title || data.title || `${data.grade || ''} ${data.subject || ''}`.trim()),
            grade: String(rawMeta.grade || data.grade || '7 ನೇ ತರಗತಿ (Class 7)'),
            gradeKey: String(rawMeta.gradeKey || data.gradeKey || '7'),
            subject: String(rawMeta.subject || data.subject || 'ವಿಷಯ'),
            subjectCode,
            medium: String(rawMeta.medium || data.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)'),
            academicYear: String(rawMeta.academicYear || data.academicYear || '2026-27'),
            totalChapters: data.chapters.length,
            totalQuestions: data.chapters.reduce(
              (sum: number, ch: any) => sum + (ch.questions?.length || 0),
              0
            ),
            ...rawMeta,
            id: docId,
          },
          chapters: data.chapters,
        });
      }
    });

    return banks;
  } catch (err) {
    console.error('Error fetching question banks from Firebase:', err);
    return [];
  }
}

/**
 * Save a Generated Question Paper to Firebase Firestore
 */
export async function saveQuestionPaperToFirebase(paper: GeneratedPaper): Promise<string> {
  const paperId = paper.id || `paper_${Date.now()}`;
  const docRef = doc(db, 'question_papers', paperId);

  const payload = {
    id: paperId,
    schoolName: paper.header.schoolName,
    examName: paper.header.examName,
    grade: paper.header.grade,
    subject: paper.header.subject,
    academicYear: paper.header.academicYear,
    totalMarks: paper.totalMarks,
    totalQuestions: paper.totalQuestions,
    header: paper.header,
    sections: paper.sections,
    createdAt: paper.createdAt || new Date().toISOString(),
  };

  await setDoc(docRef, payload);
  return paperId;
}

/**
 * Fetch all saved Question Papers from Firebase Firestore
 */
export async function getQuestionPapersFromFirebase(): Promise<GeneratedPaper[]> {
  try {
    const colRef = collection(db, 'question_papers');
    const snapshot = await getDocs(query(colRef, orderBy('createdAt', 'desc')));
    const papers: GeneratedPaper[] = [];

    snapshot.forEach(d => {
      const data = d.data() as GeneratedPaper;
      papers.push(data);
    });

    return papers;
  } catch (err) {
    console.error('Error fetching question papers from Firebase:', err);
    return [];
  }
}

/**
 * Delete a Question Paper from Firebase Firestore
 */
export async function deleteQuestionPaperFromFirebase(paperId: string): Promise<void> {
  const docRef = doc(db, 'question_papers', paperId);
  await deleteDoc(docRef);
}

export interface UploadedPdfRecord {
  id: string;
  fileName: string;
  fileSizeMB: string;
  totalPages: number;
  grade?: string;
  subject?: string;
  detectedDoc?: any;
  uploadedAt: string;
}

/**
 * Save an uploaded PDF record to Firebase Firestore
 */
export async function saveUploadedPdfToFirebase(record: UploadedPdfRecord): Promise<string> {
  const pdfId = record.id || `pdf_${Date.now()}`;
  const docRef = doc(db, 'uploaded_pdfs', pdfId);
  await setDoc(docRef, {
    ...record,
    id: pdfId,
    uploadedAt: record.uploadedAt || new Date().toISOString(),
  });
  return pdfId;
}

/**
 * Fetch all saved Uploaded PDF records from Firebase Firestore
 */
export async function getUploadedPdfsFromFirebase(): Promise<UploadedPdfRecord[]> {
  try {
    const colRef = collection(db, 'uploaded_pdfs');
    const snapshot = await getDocs(query(colRef, orderBy('uploadedAt', 'desc')));
    const list: UploadedPdfRecord[] = [];
    snapshot.forEach(d => {
      const data = d.data() as UploadedPdfRecord;
      if (data && data.fileName) {
        list.push(data);
      }
    });
    return list;
  } catch (err) {
    console.error('Error fetching uploaded PDFs from Firebase:', err);
    return [];
  }
}
