/**
 * Data Loader Service for Question Paper Generator
 * Automatically discovers and normalizes official Karnataka DSERT Question Banks
 * Author: S R Angadi
 */

import {
  BankIndex,
  IndexEntry,
  QuestionBank,
  Chapter,
  QuestionItem,
  STANDARD_QUESTION_FORMATS,
} from '../types/questionBank.ts';
import { getQuestionBanksFromFirebase } from './firebase.ts';

// In-memory cache for loaded banks
const bankCache = new Map<string, QuestionBank>();

// Central index fallback pointing to provided files
const FALLBACK_INDEX: BankIndex = {
  version: '2.0',
  description: 'Karnataka State Syllabus DSERT LBA Official Question Banks',
  files: [
    {
      id: 'maths_class6',
      path: '/assets/aistudio/maths_class6_question_bank_f388d7c3.json',
      grade: '6 ನೇ ತರಗತಿ (Class 6)',
      gradeKey: '6',
      subject: 'ಗಣಿತ (Mathematics)',
      subjectCode: 'MATH',
      medium: 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
      academicYear: '2026-27',
    },
    {
      id: 'kannada_class6',
      path: '/assets/aistudio/kannada_class6_question_bank_0e721821.json',
      grade: '6 ನೇ ತರಗತಿ (Class 6)',
      gradeKey: '6',
      subject: 'ಕನ್ನಡ (Kannada)',
      subjectCode: 'KAN',
      medium: 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
      academicYear: '2026-27',
    },
    {
      id: 'english_class6',
      path: '/assets/aistudio/english_class6_question_bank_767d543a.json',
      grade: '6 ನೇ ತರಗತಿ (Class 6)',
      gradeKey: '6',
      subject: 'English (Second Language)',
      subjectCode: 'ENG',
      medium: 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
      academicYear: '2026-27',
    },
    {
      id: 'hindi_class6',
      path: '/assets/aistudio/hindi_class6_question_bank_98dd4289.json',
      grade: '6 ನೇ ತರಗತಿ (Class 6)',
      gradeKey: '6',
      subject: 'ಹಿಂದಿ (Hindi)',
      subjectCode: 'HIN',
      medium: 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
      academicYear: '2026-27',
    },
    {
      id: 'science_class6',
      path: '/assets/aistudio/Class6_Science_Kannada_Chapterwise_QA_Bank_230b74ea.json',
      grade: '6 ನೇ ತರಗತಿ (Class 6)',
      gradeKey: '6',
      subject: 'ವಿಜ್ಞಾನ (Science)',
      subjectCode: 'SCI',
      medium: 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
      academicYear: '2026-27',
    },
    {
      id: 'social_class6',
      path: '/assets/aistudio/class-6-social-science-kannada-lba-unicode_1be3aa51.json',
      grade: '6 ನೇ ತರಗತಿ (Class 6)',
      gradeKey: '6',
      subject: 'ಸಮಾಜ ವಿಜ್ಞಾನ (Social Science)',
      subjectCode: 'SOC',
      medium: 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
      academicYear: '2026-27',
    },
  ],
};

/**
 * Categorizes any question into one of the 12 standard formats shown in the UI reference
 */
export function categorizeQuestion(
  rawType: string,
  questionText: string,
  marks: number,
  hasOptions: boolean,
  hasItems: boolean
): { id: string; name: string } {
  const t = rawType.toLowerCase().trim();
  const q = questionText.toLowerCase();

  // 1. Multiple Choice
  if (
    hasOptions ||
    t.includes('mcq') ||
    t.includes('ಬಹು ಆಯ್ಕೆ') ||
    t.includes('ಆಯ್ಕೆ') ||
    t.includes('multiple')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'mcq')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 3. True / False
  if (
    t.includes('true_false') ||
    t.includes('truefalse') ||
    t.includes('ಸರಿ ಅಥವಾ ತಪ್ಪು') ||
    t.includes('ಸರಿ/ತಪ್ಪು') ||
    t.includes('ಸರಿ (✓)') ||
    q.includes('ಸರಿ ಅಥವಾ ತಪ್ಪು') ||
    q.includes('ಸರಿ [✔] ಅಥವಾ ತಪ್ಪು')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'true_false')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 5. Match the following
  if (
    hasItems ||
    t.includes('match') ||
    t.includes('ಹೊಂದಿಸಿ') ||
    t.includes('ಮಿಲಾನ') ||
    t.includes('rhyming_words') ||
    q.includes('ಹೊಂದಿಸಿ ಬರೆಯಿರಿ') ||
    q.includes('ಜೋಡಿಸಿ ಬರೆಯಿರಿ')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'match')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 4. Analogy / Related word
  if (
    t.includes('analogy') ||
    t.includes('ಸಂಬಂಧ') ||
    t.includes('ಮೊದಲೆರಡು ಪದ') ||
    t.includes('odd_word') ||
    t.includes('odd_one_out') ||
    t.includes('collocation') ||
    q.includes('ಸಂಬಂಧಿಸಿದಂತೆ') ||
    q.includes('::')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'analogy')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 2. Fill in the blanks
  if (
    t.includes('fill') ||
    t.includes('blank') ||
    t.includes('ಬಿಟ್ಟ ಸ್ಥಳ') ||
    t.includes('ಖಾಲಿ ಜಾಗ') ||
    t.includes('word_clue') ||
    t.includes('counting') ||
    q.includes('_____') ||
    q.includes('-----') ||
    q.includes('ಬಿಟ್ಟ ಸ್ಥಳ') ||
    q.includes('ಖಾಲಿ ಬಿಟ್ಟ')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'fill_blank')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 8. Who said to whom / Reference to context
  if (
    t.includes('who_said') ||
    t.includes('reference_context') ||
    t.includes('speaker') ||
    t.includes('ಯಾರು ಯಾರಿಗೆ') ||
    t.includes('ಸಂದರ್ಭ') ||
    q.includes('ಯಾರು ಯಾರಿಗೆ ಹೇಳಿದರು') ||
    q.includes('ಸಂದರ್ಭ ಸಹಿತ')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'who_said')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 9. Passage / Picture question
  if (
    t.includes('comprehension') ||
    t.includes('picture') ||
    t.includes('ಚಿತ್ರ') ||
    t.includes('ಗದ್ಯಭಾಗ') ||
    t.includes('ಪಠ್ಯ ಓದಿ') ||
    q.includes('ಚಿತ್ರವನ್ನು ಗಮನಿಸಿ') ||
    q.includes('ಗದ್ಯಭಾಗವನ್ನು ಓದಿ') ||
    q.includes('ಪರಿಚ್ಛೇದವನ್ನು ಓದಿ')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'passage_pic')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 10. Grammar section
  if (
    t.includes('grammar') ||
    t.includes('sandhi') ||
    t.includes('synonyms') ||
    t.includes('antonyms') ||
    t.includes('translation') ||
    t.includes('ವ್ಯಾಕರಣ') ||
    t.includes('ಸಂಧಿ') ||
    t.includes('ವಿಭಕ್ತಿ') ||
    t.includes('ಲಿಂಗ') ||
    t.includes('ತತ್ಸಮ') ||
    t.includes('ವಿರುದ್ಧಾರ್ಥಕ')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'grammar_section')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 12. Long answer / Essay / Drawing
  if (
    marks >= 4 ||
    t.includes('essay') ||
    t.includes('quote_memory') ||
    t.includes('ಕಂಠಪಾಠ') ||
    t.includes('ಪ್ರಬಂಧ') ||
    t.includes('ದೀರ್ಘ') ||
    t.includes('ವಿವರಣಾತ್ಮಕ')
  ) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'long_4m')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 11. 3M / 4-6 sentences
  if (marks === 3 || t.includes('problem_solving') || t.includes('೪-೬ ವಾಕ್ಯ') || t.includes('ಮೂರು ಅಥವಾ ನಾಲ್ಕು')) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'short_3m')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 7. 2M / 2-3 sentences
  if (marks === 2 || t.includes('short_answer') || t.includes('೨-೩ ವಾಕ್ಯ') || t.includes('ಎರಡು ಅಥವಾ ಮೂರು')) {
    const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'short_2m')!;
    return { id: fmt.id, name: fmt.name };
  }

  // 6. 1M / One sentence
  const fmt = STANDARD_QUESTION_FORMATS.find(f => f.id === 'one_sentence')!;
  return { id: fmt.id, name: fmt.name };
}

/**
 * Normalizes question object across all 6 subject schemas
 */
function normalizeQuestion(
  raw: Record<string, unknown>,
  chapterName: string,
  chapterId: string,
  chapterNumber: number,
  idx: number,
  fallbackMarks = 1
): QuestionItem {
  const id = String(raw.id || raw.questionId || `${chapterId}_q${idx + 1}`);
  const question = String(
    raw.question || raw.questionText || raw.text || raw.question_name || ''
  ).trim();

  let answer = String(raw.answer || raw.modelAnswerText || raw.solution || raw.answerText || '').trim();
  if (!answer || answer === 'null' || answer === 'undefined') {
    answer = 'ಉತ್ತರ ಲಭ್ಯವಿಲ್ಲ';
  }

  const rawType = String(
    raw.questionType || raw.type || raw.question_type || raw.sectionType || ''
  );

  let marks = Number(raw.marks || raw.marks_per_question || raw.mark || fallbackMarks);
  if (!marks || isNaN(marks) || marks < 1) marks = fallbackMarks;

  const learningOutcome = raw.learningOutcome
    ? String(raw.learningOutcome)
    : raw.learning_outcome
    ? String(raw.learning_outcome)
    : undefined;

  let rawDiff = String(
    raw.difficulty || raw.difficultyLabel || raw.difficultyLevel || raw.level || ''
  ).trim();
  let difficulty = 'ಸಾಧಾರಣ';
  const diffLower = rawDiff.toLowerCase();
  if (
    diffLower.includes('ಸುಲಭ') ||
    diffLower.includes('easy') ||
    diffLower.includes('सरल') ||
    diffLower === '1'
  ) {
    difficulty = 'ಸುಲಭ';
  } else if (
    diffLower.includes('ಕಠಿಣ') ||
    diffLower.includes('difficult') ||
    diffLower.includes('hard') ||
    diffLower.includes('कठिन') ||
    diffLower === '3'
  ) {
    difficulty = 'ಕಠಿಣ';
  } else if (
    diffLower.includes('ಸಾಧಾರಣ') ||
    diffLower.includes('medium') ||
    diffLower.includes('average') ||
    diffLower.includes('सामान्य') ||
    diffLower.includes('ಮಧ್ಯಮ') ||
    diffLower === '2'
  ) {
    difficulty = 'ಸಾಧಾರಣ';
  } else {
    // If not specified in raw JSON, intelligently assign based on question format & marks
    if (marks === 1) {
      difficulty = idx % 3 === 0 ? 'ಸಾಧಾರಣ' : 'ಸುಲಭ';
    } else if (marks === 2) {
      difficulty = idx % 4 === 0 ? 'ಕಠಿಣ' : idx % 2 === 0 ? 'ಸುಲಭ' : 'ಸಾಧಾರಣ';
    } else {
      difficulty = idx % 2 === 0 ? 'ಕಠಿಣ' : 'ಸಾಧಾರಣ';
    }
  }

  // Objective / Bloom's Taxonomy (ಜ್ಞಾನ, ತಿಳುವಳಿಕೆ, ಅನ್ವಯ, ಕೌಶಲ)
  let rawObj = String(
    raw.objective || raw.objectiveName || raw.taxonomy || raw.bloomTaxonomy || ''
  ).trim();
  let objective = 'ಜ್ಞಾನ';
  const objLower = rawObj.toLowerCase();
  if (objLower.includes('ಕೌಶಲ') || objLower.includes('skill')) {
    objective = 'ಕೌಶಲ';
  } else if (objLower.includes('ಅನ್ವಯ') || objLower.includes('apply') || objLower.includes('application')) {
    objective = 'ಅನ್ವಯ';
  } else if (objLower.includes('ತಿಳುವಳಿಕೆ') || objLower.includes('understanding') || objLower.includes('comprehension')) {
    objective = 'ತಿಳುವಳಿಕೆ';
  } else if (objLower.includes('ಜ್ಞಾನ') || objLower.includes('knowledge') || objLower.includes('recall')) {
    objective = 'ಜ್ಞಾನ';
  } else {
    // Intelligently deduce objective from question characteristics
    const qLower = question.toLowerCase();
    if (
      qLower.includes('ಚಿತ್ರ') ||
      qLower.includes('ರೇಖಾಚಿತ್ರ') ||
      qLower.includes('ಗುರುತಿಸಿ') ||
      qLower.includes('ನಕ್ಷೆ') ||
      qLower.includes('ರಚಿಸಿ') ||
      qLower.includes('ಸಾಧಿಸಿ') ||
      qLower.includes('draw') ||
      qLower.includes('diagram') ||
      qLower.includes('map') ||
      qLower.includes('graph')
    ) {
      objective = 'ಕೌಶಲ';
    } else if (
      qLower.includes('ಕಾರಣ') ||
      qLower.includes('ಏಕೆ') ||
      qLower.includes('ಹೇಗೆ') ||
      qLower.includes('ಅನ್ವಯ') ||
      qLower.includes('ಸ್ವಂತ ವಾಕ್ಯ') ||
      qLower.includes('ಬಳಸಿ') ||
      qLower.includes('ವ್ಯತ್ಯಾಸ') ||
      qLower.includes('ಹೋಲಿಸಿ') ||
      marks >= 3
    ) {
      objective = 'ಅನ್ವಯ';
    } else if (
      qLower.includes('ವಿವರಿಸಿ') ||
      qLower.includes('ತಿಳಿಸಿ') ||
      qLower.includes('ವ್ಯಾಖ್ಯಾನಿಸಿ') ||
      qLower.includes('ಲಕ್ಷಣಗಳು') ||
      qLower.includes('ಉದ್ದೇಶ') ||
      qLower.includes('ಪ್ರಯೋಜನ') ||
      marks === 2
    ) {
      objective = 'ತಿಳುವಳಿಕೆ';
    } else {
      // Deterministically cycle [ಜ್ಞಾನ, ತಿಳುವಳಿಕೆ, ಅನ್ವಯ, ಕೌಶಲ] so blueprint always has all 4
      const objCycle = ['ಜ್ಞಾನ', 'ತಿಳುವಳಿಕೆ', 'ಅನ್ವಯ', 'ಕೌಶಲ'];
      objective = objCycle[(idx + chapterNumber) % 4];
    }
  }

  let options: string[] | undefined = undefined;
  if (Array.isArray(raw.options)) {
    options = raw.options.map(opt => (typeof opt === 'string' ? opt : JSON.stringify(opt)));
  } else if (raw.options && typeof raw.options === 'object') {
    options = Object.entries(raw.options as Record<string, string>).map(
      ([k, v]) => `${k}) ${v}`
    );
  }

  let items: Array<{ left: string; right: string }> | undefined = undefined;
  if (Array.isArray(raw.items)) {
    items = raw.items as Array<{ left: string; right: string }>;
  }

  // Categorize into one of 12 standard formats
  const hasOpts = Boolean(options && options.length > 0);
  const hasItms = Boolean(items && items.length > 0);
  const category = categorizeQuestion(rawType, question, marks, hasOpts, hasItms);

  // Synchronize default marks according to format
  const stdDef = STANDARD_QUESTION_FORMATS.find(f => f.id === category.id);
  // Match-the-following questions carry 1 mark per sub-item (e.g. 4 items = 4 marks, 5 items = 5 marks)
  if (category.id === 'match' || (hasItms && items && items.length >= 2)) {
    const itmCount = (items && items.length) ? items.length : 4;
    marks = Math.max(3, itmCount);
  } else if (stdDef && !raw.marks) {
    marks = stdDef.marks;
  }

  return {
    ...raw,
    id,
    question,
    answer,
    questionType: rawType || category.name,
    formatCategoryId: category.id,
    formatCategoryName: category.name,
    marks,
    learningOutcome,
    difficulty,
    objective,
    objectiveName: objective,
    options,
    items,
    chapterId,
    chapterName,
    chapterNumber,
  };
}

/**
 * Extracts normalized numeric grade key from any Kannada/English grade string
 */
export function extractGradeKey(gradeStr: string | undefined | null): string {
  if (!gradeStr) return '6';
  const kannadaDigits = ['೦', '೧', '೨', '೩', '೪', '೫', '೬', '೭', '೮', '೯'];
  let s = String(gradeStr);
  kannadaDigits.forEach((kd, idx) => {
    s = s.replaceAll(kd, String(idx));
  });
  const m = s.match(/\d+/);
  return m ? m[0] : '6';
}

/**
 * Normalizes subject names into official Kannada & English labels.
 * CRITICAL: Social Science (ಸಮಾಜ ವಿಜ್ಞಾನ) MUST be checked BEFORE Science (ವಿಜ್ಞಾನ)
 * because "ಸಮಾಜ ವಿಜ್ಞಾನ" contains the substring "ವಿಜ್ಞಾನ".
 */
export function normalizeSubjectName(subjectStr: string | undefined | null): string {
  if (!subjectStr) return 'ಗಣಿತ (Mathematics)';
  const s = String(subjectStr).replace(/\s*★\s*\(ಉಳಿಸಿದ\)/g, '').replace(/★/g, '').trim();
  const lower = s.toLowerCase();
  if (lower.includes('ಸಮಾಜ') || lower.includes('social')) return 'ಸಮಾಜ ವಿಜ್ಞಾನ (Social Science)';
  if (lower.includes('ವಿಜ್ಞಾನ') || lower.includes('science')) return 'ವಿಜ್ಞಾನ (Science)';
  if (lower.includes('ಗಣಿತ') || lower.includes('math')) return 'ಗಣಿತ (Mathematics)';
  if (lower.includes('ಕನ್ನಡ') || lower.includes('kannada')) return 'ಪ್ರಥಮ ಭಾಷೆ ಕನ್ನಡ (Kannada)';
  if (lower.includes('ಇಂಗ್ಲಿಷ್') || lower.includes('english')) return 'English (Second Language)';
  if (lower.includes('ಹಿಂದಿ') || lower.includes('hindi')) return 'ಹಿಂದಿ (Hindi)';
  return s;
}

/**
 * Deduces standard 3-letter subject code from subject name or code
 */
export function deduceSubjectCode(subjectStr: string | undefined | null): string {
  if (!subjectStr) return 'GEN';
  const s = String(subjectStr).toLowerCase();
  if (s === 'soc' || s.includes('ಸಮಾಜ') || s.includes('social')) return 'SOC';
  if (s === 'sci' || s.includes('ವಿಜ್ಞಾನ') || s.includes('science')) return 'SCI';
  if (s === 'math' || s.includes('ಗಣಿತ') || s.includes('math')) return 'MATH';
  if (s === 'kan' || s.includes('ಕನ್ನಡ') || s.includes('kannada')) return 'KAN';
  if (s === 'eng' || s.includes('ಇಂಗ್ಲಿಷ್') || s.includes('english')) return 'ENG';
  if (s === 'hin' || s.includes('ಹಿಂದಿ') || s.includes('hindi')) return 'HIN';
  return 'GEN';
}

/**
 * Returns canonical Kannada/English display label for a grade key
 */
export function canonicalGradeLabel(gradeKey: string): string {
  switch (gradeKey) {
    case '6':
      return '6 ನೇ ತರಗತಿ (Class 6)';
    case '7':
      return '7 ನೇ ತರಗತಿ (Class 7)';
    case '8':
      return '8 ನೇ ತರಗತಿ (Class 8)';
    case '9':
      return '9 ನೇ ತರಗತಿ (Class 9)';
    case '10':
      return '10 ನೇ ತರಗತಿ (Class 10)';
    default:
      return `${gradeKey} ನೇ ತರಗತಿ (Class ${gradeKey})`;
  }
}

/**
 * Helper to match a file's grade against a selected grade string (handles Kannada numbers and formats)
 */
export function matchesGrade(
  file: { grade?: string; gradeKey?: string } | null | undefined,
  targetGrade: string
): boolean {
  if (!file || !targetGrade) return false;
  const targetKey = extractGradeKey(targetGrade);
  const fileKey = file.gradeKey || extractGradeKey(file.grade);
  return fileKey === targetKey;
}

/**
 * Normalizes chapter object (handling both direct questions and sectioned questions)
 */
function normalizeChapter(
  raw: Record<string, unknown>,
  idx: number,
  totalChapters: number,
  forceEvenSemesterSplit: boolean = false
): Chapter {
  const chapterId = String(raw.chapterId || raw.id || raw.chapter_id || `ch_${idx + 1}`);
  const chapterNumber = raw.chapterNumber
    ? Number(raw.chapterNumber)
    : raw.chapter_number
    ? Number(raw.chapter_number)
    : raw.unit_number
    ? Number(raw.unit_number)
    : idx + 1;

  const chapterName = String(
    raw.chapterName || raw.title || raw.chapter_name || raw.name || `ಅಧ್ಯಾಯ ${chapterNumber}`
  ).trim();

  // Determine semester: if explicit and not forced to split, use provided semester;
  // otherwise split first half = Sem 1, second half = Sem 2
  let semester: 1 | 2;
  const rawSem = Number(raw.semester);
  if (!forceEvenSemesterSplit && (rawSem === 1 || rawSem === 2)) {
    semester = rawSem as 1 | 2;
  } else {
    semester = chapterNumber <= Math.ceil(totalChapters / 2) ? 1 : 2;
  }

  const extractedQuestions: QuestionItem[] = [];

  // Helper: Expands bundled subquestions (e.g. "एक वाक्य में उत्तर लिखिए : 1. ... 2. ... 11. ...")
  // into individual 1-mark questions so each question can be selected and scored individually!
  const expandQuestionIfNeeded = (rawObj: Record<string, unknown>, qIndex: number, fallbackMarks: number) => {
    const qText = String(
      rawObj.question || rawObj.questionText || rawObj.text || rawObj.question_name || ''
    ).trim();
    const ansText = String(rawObj.answer || rawObj.answerText || '').trim();
    const rawType = String(rawObj.questionType || rawObj.type || '').toLowerCase();
    const rawCat = String(rawObj.formatCategoryId || '').toLowerCase();

    // Check if it's already a match or has options/diagram
    const isMatch = rawType.includes('match') || rawType.includes('ಹೊಂದಿಸಿ') || rawType.includes('मिलान') || rawCat === 'match' || Array.isArray(rawObj.items);
    const hasOptions = Array.isArray(rawObj.options) && rawObj.options.length > 0;

    // Pattern to detect numbered sub-questions like "1. ", "2. ", "1) ", "2) "
    const numRegex = /(?:^|\n)\s*(\d{1,2})[\.\)]\s*/g;
    const qMatches = [...qText.matchAll(numRegex)];

    if (!isMatch && !hasOptions && qMatches.length >= 3) {
      // It's a bundle of 3 or more subquestions!
      const pattern = /(?:^|\n)\s*(\d{1,2})[\.\)]\s*/;
      const qParts = qText.split(pattern);
      const mainHeader = qParts[0].trim();

      // Also split answer if formatted with numbered answers
      const aParts = ansText.split(pattern);
      const aMap: Record<string, string> = {};
      for (let i = 1; i < aParts.length; i += 2) {
        aMap[aParts[i]] = (aParts[i + 1] || '').trim();
      }

      let subIdx = 0;
      for (let i = 1; i < qParts.length; i += 2) {
        const subNum = qParts[i];
        const subBody = (qParts[i + 1] || '').trim();
        if (!subBody) continue;

        const subAnswer = aMap[subNum] || ansText || 'ಉತ್ತರ ಲಭ್ಯವಿಲ್ಲ';
        const singleSubQ: Record<string, unknown> = {
          ...rawObj,
          id: `${rawObj.id || chapterId + '_q' + qIndex}_sub${subNum}`,
          question: subBody,
          answer: subAnswer,
          questionType: mainHeader || 'ಒಂದು ವಾಕ್ಯದಲ್ಲಿ ಉತ್ತರಿಸಿ',
          formatCategoryId: 'one_sentence',
          formatCategoryName: '೧. ಒಂದು ವಾಕ್ಯದ ಪ್ರಶ್ನೆ (1M)',
          marks: 1, // Each discrete question gets 1 mark!
        };

        extractedQuestions.push(
          normalizeQuestion(singleSubQ, chapterName, chapterId, chapterNumber, extractedQuestions.length, 1)
        );
        subIdx++;
      }
      if (subIdx > 0) return;
    }

    // Default: Not a bundle, normalize normally
    extractedQuestions.push(
      normalizeQuestion(rawObj, chapterName, chapterId, chapterNumber, extractedQuestions.length, fallbackMarks)
    );
  };

  // Case A: Direct questions array
  if (Array.isArray(raw.questions) && raw.questions.length > 0) {
    raw.questions.forEach((q, qIdx) => {
      expandQuestionIfNeeded(q as Record<string, unknown>, qIdx, 1);
    });
  }

  // Case B: Questions inside sections array
  if (Array.isArray(raw.sections)) {
    for (const sec of raw.sections as Record<string, unknown>[]) {
      const secTitle = String(sec.title || '');
      const secInstructions = String(sec.instructions || '');
      const secMarks = Number(sec.marks_per_question || sec.marks || 1);
      const secQuestions = Array.isArray(sec.questions) ? sec.questions : [];

      secQuestions.forEach((q, qIdx) => {
        const itemObj = {
          ...(q as Record<string, unknown>),
          sectionTitle: secTitle,
          sectionInstructions: secInstructions,
        };
        expandQuestionIfNeeded(itemObj, qIdx, secMarks);
      });
    }
  }

  return {
    chapterId,
    chapterNumber,
    chapterName,
    semester,
    questions: extractedQuestions,
  };
}

/**
 * Normalizes complete question bank
 */
export function normalizeQuestionBank(raw: Record<string, unknown>): QuestionBank {
  const rawMeta = (raw.metadata || raw.meta || {}) as Record<string, unknown>;

  const rawChapters = Array.isArray(raw.chapters) ? raw.chapters : [];
  const totalChapters = rawChapters.length;

  // Check if all chapters share the exact same semester (e.g. all 1 or all undefined)
  const allSameSemester =
    totalChapters > 1 &&
    rawChapters.every(
      c =>
        Number((c as Record<string, unknown>).semester) ===
        Number((rawChapters[0] as Record<string, unknown>).semester)
    );

  const chapters = rawChapters.map((ch, idx) =>
    normalizeChapter(ch as Record<string, unknown>, idx, totalChapters, allSameSemester)
  );

  const rawGrade = String(rawMeta.grade || rawMeta.class || '6 ನೇ ತರಗತಿ (Class 6)');
  const detectedNum = rawGrade.match(/\d+/)?.[0] || '6';

  const metadata = {
    grade: rawGrade,
    gradeKey: rawMeta.gradeKey ? String(rawMeta.gradeKey) : detectedNum,
    subject: String(rawMeta.subject || 'ಗಣಿತ (Mathematics)'),
    medium: String(rawMeta.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)'),
    board: rawMeta.board ? String(rawMeta.board) : 'ಕರ್ನಾಟಕ ರಾಜ್ಯ ಪಠ್ಯಕ್ರಮ (DSERT / KSEEB)',
    academicYear: String(rawMeta.academic_year || rawMeta.academicYear || '2026-27'),
    author: String(rawMeta.author || 'M I Nilaji'),
    totalChapters: chapters.length,
    ...rawMeta,
  };

  return {
    metadata,
    chapters,
  };
}

/**
 * Registers an in-memory or newly generated Question Bank
 */
export function registerCustomBank(bank: QuestionBank, entry: IndexEntry) {
  bankCache.set(entry.id, bank);
  if (entry.path) {
    bankCache.set(entry.path, bank);
  }
}

/**
 * Fetches central data/index.json and user-saved banks from /api/saved-question-banks
 */
export async function fetchBankIndex(): Promise<BankIndex> {
  let combinedFiles = [...FALLBACK_INDEX.files];

  // Try fetching user-saved banks from server API or static file
  try {
    let userData: { files?: IndexEntry[] } | null = null;
    const userRes = await fetch('/api/saved-question-banks');
    if (userRes.ok) {
      userData = await userRes.json();
    } else {
      const staticRes = await fetch('/assets/user_banks/index.json');
      if (staticRes.ok) {
        userData = await staticRes.json();
      }
    }
    if (userData && Array.isArray(userData.files) && userData.files.length > 0) {
      // Avoid duplicate IDs
      const existingIds = new Set(userData.files.map(f => f.id));
      combinedFiles = [...userData.files, ...combinedFiles.filter(f => !existingIds.has(f.id))];
    }
  } catch (e) {
    // Continue
  }

  // Also discover Question Banks stored in Firebase Firestore
  try {
    const fbBanks = await getQuestionBanksFromFirebase();
    for (const fbBank of fbBanks) {
      const bId: string =
        typeof fbBank.metadata.id === 'string' && fbBank.metadata.id
          ? fbBank.metadata.id
          : `fb_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const gKey = extractGradeKey(
        (fbBank.metadata as any).gradeKey || fbBank.metadata.grade || (fbBank.metadata as any).class
      );
      const canonGrade = canonicalGradeLabel(gKey);
      const canonSubject = normalizeSubjectName(fbBank.metadata.subject);
      const sCode = deduceSubjectCode(String(fbBank.metadata.subjectCode || fbBank.metadata.subject || ''));

      const entry: IndexEntry = {
        id: bId,
        path: `firebase://${bId}`,
        grade: canonGrade,
        gradeKey: gKey,
        subject: canonSubject,
        subjectCode: sCode,
        medium: fbBank.metadata.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
        academicYear: String(fbBank.metadata.academicYear || '2026-27'),
        totalChapters: fbBank.chapters.length,
        totalQuestions: fbBank.chapters.reduce((sum, ch) => sum + (ch.questions?.length || 0), 0),
        isUserGenerated: true,
      };
      registerCustomBank(fbBank, entry);
      if (!combinedFiles.some(f => f.id === entry.id)) {
        combinedFiles.unshift(entry);
      }
    }
  } catch (fbErr) {
    console.warn('Firebase question banks query skipped:', fbErr);
  }

  // Deduplicate files strictly by canonical grade key and standardized subject code (e.g. 7_MATH, 7_ENG, 7_SOC)
  const seenSubjectCodes = new Set<string>();
  const uniqueFiles: IndexEntry[] = [];
  for (const f of combinedFiles) {
    const gKey = extractGradeKey(f.gradeKey || f.grade);
    const canonGrade = canonicalGradeLabel(gKey);
    const cleanSub = normalizeSubjectName(f.subject);
    const sCode = deduceSubjectCode(f.subjectCode || f.subject);
    const key = `${gKey}_${sCode}`;
    if (!seenSubjectCodes.has(key)) {
      seenSubjectCodes.add(key);
      uniqueFiles.push({
        ...f,
        grade: canonGrade,
        gradeKey: gKey,
        subject: cleanSub,
        subjectCode: sCode,
      });
    }
  }
  combinedFiles = uniqueFiles;

  return {
    version: '2.0',
    description: 'Karnataka State Syllabus DSERT LBA Official Question Banks',
    files: combinedFiles,
  };
}

/**
 * Loads a Question Bank from a file path or registered ID
 */
export async function loadQuestionBankByPath(filePath: string): Promise<QuestionBank> {
  if (bankCache.has(filePath)) {
    return bankCache.get(filePath)!;
  }

  const safePath =
    filePath.startsWith('http') || filePath.includes('%') ? filePath : encodeURI(filePath);

  if (bankCache.has(safePath)) {
    return bankCache.get(safePath)!;
  }

  if (filePath.startsWith('firebase://')) {
    const banks = await getQuestionBanksFromFirebase();
    const targetId = filePath.replace('firebase://', '');
    const found = banks.find(b => b.metadata.id === targetId);
    if (found) {
      bankCache.set(filePath, found);
      bankCache.set(safePath, found);
      return found;
    }
  }

  try {
    const res = await fetch(safePath);
    if (!res.ok) {
      throw new Error(`ಫೈಲ್ ಲೋಡ್ ಮಾಡಲು ವಿಫಲವಾಗಿದೆ: ${filePath} (${res.status} ${res.statusText})`);
    }
    const rawData = await res.json();
    const bank = normalizeQuestionBank(rawData);
    bankCache.set(filePath, bank);
    bankCache.set(safePath, bank);
    return bank;
  } catch (err) {
    console.error(`Error loading question bank from ${filePath}:`, err);
    throw err;
  }
}

/**
 * Extracts question types available in selected chapters
 */
export function extractAvailableQuestionTypes(chapters: Chapter[], selectedChapterIds: string[]): string[] {
  const filtered = selectedChapterIds.length === 0 
    ? chapters 
    : chapters.filter(c => selectedChapterIds.includes(c.chapterId));
  
  const typeSet = new Set<string>();
  for (const ch of filtered) {
    for (const q of ch.questions) {
      if (q.questionType && q.questionType.trim()) {
        typeSet.add(q.questionType.trim());
      }
    }
  }
  return Array.from(typeSet);
}

/**
 * Extracts learning outcomes in selected chapters
 */
export function extractAvailableLearningOutcomes(chapters: Chapter[], selectedChapterIds: string[]): string[] {
  const filtered = selectedChapterIds.length === 0 
    ? chapters 
    : chapters.filter(c => selectedChapterIds.includes(c.chapterId));
  
  const loSet = new Set<string>();
  for (const ch of filtered) {
    for (const q of ch.questions) {
      if (q.learningOutcome && q.learningOutcome.trim()) {
        loSet.add(q.learningOutcome.trim());
      }
    }
  }
  return Array.from(loSet);
}

/**
 * Extracts difficulty levels in selected chapters
 */
export function extractAvailableDifficulties(chapters: Chapter[], selectedChapterIds: string[]): string[] {
  const filtered = selectedChapterIds.length === 0 
    ? chapters 
    : chapters.filter(c => selectedChapterIds.includes(c.chapterId));
  
  const diffSet = new Set<string>();
  for (const ch of filtered) {
    for (const q of ch.questions) {
      if (q.difficulty && q.difficulty.trim()) {
        diffSet.add(q.difficulty.trim());
      }
    }
  }
  return Array.from(diffSet);
}

