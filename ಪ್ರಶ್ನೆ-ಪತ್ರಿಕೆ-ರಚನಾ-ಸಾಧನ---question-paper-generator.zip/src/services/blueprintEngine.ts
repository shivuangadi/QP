/**
 * Karnataka DSERT 5-Stage Blueprint Engine
 * Recreates the authentic 5-stage blueprint matrix with full interconnectivity and exact tallying across all 5 steps.
 * Step 5 features 4 Objectives (ಜ್ಞಾನ, ತಿಳುವಳಿಕೆ, ಅನ್ವಯ, ಕೌಶಲ), each with 3 sub-columns:
 * ಸುಲಭ (Easy), ಸಾಧಾರಣ (Average), and ಕಠಿಣ (Difficult).
 * Author: M I Nilaji / S R Angadi
 */

import {
  Chapter,
  QuestionBank,
  QuestionItem,
  SectionBlueprint,
  GeneratedPaper,
  STANDARD_QUESTION_FORMATS,
} from '../types/questionBank.ts';

export interface ObjectiveWeightage {
  id: string;
  name: string;
  percentage: number;
  marks: number;
  questionsCount: number;
}

export interface QuestionTypeWeightage {
  id: string;
  name: string;
  percentage: number;
  marks: number;
  questionsCount: number;
  marksPerQuestion: number;
}

export interface DifficultyWeightage {
  id: string;
  name: string;
  marks: number;
  percentage: number;
  questionsCount?: number;
}

export interface ChapterWeightage {
  chapterId: string;
  chapterNumber: number;
  chapterName: string;
  questionsCount: number;
  marks: number;
  percentage: number;
}

export interface ObjectiveDiffCell {
  questionsCount: number;
  marksPerQuestion: number;
  totalMarks: number;
  questionIds?: string[];
}

export interface MasterGridRow {
  chapterId: string;
  chapterNumber?: number;
  chapterName: string;
  // ಜ್ಞಾನ (Knowledge): ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ
  knowledgeEasy: ObjectiveDiffCell | null;
  knowledgeAvg: ObjectiveDiffCell | null;
  knowledgeDiff: ObjectiveDiffCell | null;
  // ತಿಳುವಳಿಕೆ (Understanding): ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ
  understandingEasy: ObjectiveDiffCell | null;
  understandingAvg: ObjectiveDiffCell | null;
  understandingDiff: ObjectiveDiffCell | null;
  // ಅನ್ವಯ (Application): ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ
  applicationEasy: ObjectiveDiffCell | null;
  applicationAvg: ObjectiveDiffCell | null;
  applicationDiff: ObjectiveDiffCell | null;
  // ಕೌಶಲ (Skill): ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ
  skillEasy: ObjectiveDiffCell | null;
  skillAvg: ObjectiveDiffCell | null;
  skillDiff: ObjectiveDiffCell | null;
  // Totals for this chapter
  totalMarks: number;
  totalQuestions: number;
}

export interface CompleteBlueprint {
  title: string;
  grade: string;
  subject: string;
  totalMarks: number;
  totalQuestions: number;
  step1Objectives: ObjectiveWeightage[];
  step2QuestionTypes: QuestionTypeWeightage[];
  step3Difficulty: DifficultyWeightage[];
  step4Chapters: ChapterWeightage[];
  step5MasterGrid: MasterGridRow[];
}

/**
 * Balances percentages across an array of weightages so that the sum is strictly 100%
 * and never exceeds 100% or falls short due to discrete rounding errors.
 */
export function normalizeStepPercentages<T extends { marks: number; percentage: number }>(
  items: T[],
  totalMarks: number
): T[] {
  if (items.length === 0 || totalMarks <= 0) return items;
  let remaining = 100;
  items.forEach((item, idx) => {
    if (idx === items.length - 1) {
      item.percentage = Math.max(0, remaining);
    } else {
      item.percentage = Math.round((item.marks / totalMarks) * 100);
      remaining -= item.percentage;
    }
  });
  return items;
}

/**
 * Suggests the standard Karnataka DSERT recommended question count based on total marks
 */
export function getRecommendedQuestionCount(targetMarks: number): number {
  if (targetMarks <= 20) return 12;
  if (targetMarks <= 25) return 16;
  if (targetMarks <= 35) return 20;
  if (targetMarks <= 40) return 24;
  if (targetMarks <= 50) return 28;
  if (targetMarks <= 60) return 32;
  if (targetMarks <= 80) return 38;
  if (targetMarks <= 100) return 42;
  return Math.max(10, Math.round(targetMarks * 0.45));
}

/**
 * Solves exact integer distribution of question types for given marks and question count
 */
export function solveExactQuestionTypes(
  targetMarks: number,
  targetQuestions: number
): { mcq: number; vsa: number; sa: number; la1: number; la2: number } {
  const diff = targetMarks - targetQuestions;
  let best = {
    q1: Math.round(targetQuestions * 0.4),
    q2: Math.round(targetQuestions * 0.25),
    q3: Math.round(targetQuestions * 0.15),
    q4: Math.round(targetQuestions * 0.2),
  };
  let minCost = Infinity;

  const maxQ4 = Math.floor(diff / 3);
  for (let q4 = Math.max(1, Math.floor(targetQuestions * 0.1)); q4 <= maxQ4; q4++) {
    const maxQ3 = Math.floor((diff - 3 * q4) / 2);
    for (let q3 = Math.max(1, Math.floor(targetQuestions * 0.08)); q3 <= maxQ3; q3++) {
      const q2 = diff - 3 * q4 - 2 * q3;
      const q1 = targetQuestions - q2 - q3 - q4;
      if (q1 >= 2 && q2 >= 1) {
        const cost =
          Math.abs(q1 / targetQuestions - 0.38) +
          Math.abs((q2 * 2) / targetMarks - 0.25) +
          Math.abs((q3 * 3) / targetMarks - 0.15) +
          Math.abs((q4 * 4) / targetMarks - 0.22);

        if (cost < minCost) {
          minCost = cost;
          best = { q1, q2, q3, q4 };
        }
      }
    }
  }

  const mcq = Math.max(2, Math.min(best.q1 - 1, Math.round(best.q1 * 0.35)));
  const vsa = Math.max(1, best.q1 - mcq);

  return {
    mcq,
    vsa,
    sa: Math.max(1, best.q2),
    la1: Math.max(1, best.q3),
    la2: Math.max(1, best.q4),
  };
}

/**
 * Builds the official 5-Step Blue Print matching Karnataka DSERT standards.
 * If paper is provided, derives the exact tallies from the actual chosen questions.
 * Ensures complete interconnectivity across all 5 steps.
 */
export function generateOfficialBlueprint(
  bank: QuestionBank,
  selectedChapterIds: string[],
  targetMarks = 40,
  targetQuestions = 24,
  paper?: GeneratedPaper | null,
  customChapterPercentages?: Record<string, number>
): CompleteBlueprint {
  const activeChapters =
    selectedChapterIds.length === 0
      ? bank.chapters
      : bank.chapters.filter(c => selectedChapterIds.includes(c.chapterId));

  // If a real paper is generated and has questions, derive exact blueprint from the actual paper
  if (paper && paper.sections && paper.sections.length > 0) {
    const allPaperQuestions = paper.sections.flatMap(s => s.questions);
    if (allPaperQuestions.length > 0) {
      // 1. Map questions to (objective, difficulty)
      // Categorize objectives: know, und, app, skill
      // Categorize difficulties: easy, avg, diff
      type ObjKey = 'know' | 'und' | 'app' | 'skill';
      type DiffKey = 'easy' | 'avg' | 'diff';

      const getObjective = (q: any, idx: number): ObjKey => {
        // Direct explicit tag
        const rawObj = (q.objective || q.objectiveName || '').toLowerCase();
        if (rawObj.includes('know') || rawObj.includes('ಜ್ಞಾನ') || rawObj.includes('ಸ್ಮರಣೆ')) return 'know';
        if (rawObj.includes('und') || rawObj.includes('ತಿಳುವಳಿಕೆ') || rawObj.includes('ಗ್ರಹಿಕೆ')) return 'und';
        if (rawObj.includes('app') || rawObj.includes('ಅನ್ವಯ') || rawObj.includes('ಅಭಿವ್ಯಕ್ತಿ')) return 'app';
        if (rawObj.includes('skill') || rawObj.includes('ಕೌಶಲ') || rawObj.includes('ಚಿತ್ರ') || rawObj.includes('ನಕ್ಷೆ')) return 'skill';

        // Check learningOutcome
        const lo = (q.learningOutcome || '').toLowerCase();
        if (lo.includes('ಜ್ಞಾನ') || lo.includes('knowledge') || lo.includes('ಸ್ಮರಣೆ')) return 'know';
        if (lo.includes('ಅನ್ವಯ') || lo.includes('application') || lo.includes('ಅಭಿವ್ಯಕ್ತಿ')) return 'app';
        if (lo.includes('ಕೌಶಲ') || lo.includes('skill') || lo.includes('ಚಿತ್ರ') || lo.includes('ನಕ್ಷೆ') || q.hasDiagram) return 'skill';
        if (lo.includes('ತಿಳುವಳಿಕೆ') || lo.includes('understanding') || lo.includes('ಗ್ರಹಿಕೆ')) return 'und';

        // Check question text content
        const text = (q.question || '').toLowerCase();
        if (text.includes('ಚಿತ್ರ') || text.includes('ರೇಖಾಚಿತ್ರ') || text.includes('ನಕ್ಷೆ') || text.includes('ಗುರುತಿಸಿ') || text.includes('ರಚಿಸಿ') || text.includes('ಡ್ರಾಯಿಂಗ್') || q.hasDiagram) return 'skill';
        if (text.includes('ಲೆಕ್ಕ') || text.includes('ಕಂಡುಹಿಡಿಯಿರಿ') || text.includes('ಬೆಲೆ') || text.includes('ಸಾಧಿಸಿ') || text.includes('ಸಮಸ್ಯೆ') || text.includes('ಅನ್ವಯ') || text.includes('ಪ್ರಯೋಗ')) return 'app';
        if (text.includes('ಕಾರಣ') || text.includes('ವ್ಯತ್ಯಾಸ') || text.includes('ವಿವರಿಸಿ') || text.includes('ಹೋಲಿಸಿ') || text.includes('ಗ್ರಹಿಸಿ') || text.includes('ಏಕೆಂದರೆ')) return 'und';

        // DSERT Standard Objective Proportions Distribution Fallback:
        // ~25% Knowledge (know), ~45% Understanding (und), ~20% Application (app), ~10% Skill (skill)
        const mod = idx % 10;
        if (mod === 9) return 'skill';
        if (mod === 6 || mod === 7) return 'app';
        if (mod >= 2 && mod <= 5) return 'und';
        return 'know';
      };

      const getDifficulty = (q: any, idx: number): DiffKey => {
        const d = (q.difficulty || '').toLowerCase();
        if (d.includes('ಸುಲಭ') || d.includes('easy')) return 'easy';
        if (d.includes('ಕಠಿಣ') || d.includes('hard') || d.includes('diff')) return 'diff';
        if (d.includes('ಸಾಧಾರಣ') || d.includes('medium') || d.includes('avg') || d.includes('ಮಧ್ಯಮ')) return 'avg';

        // DSERT Standard Difficulty Distribution Fallback: 30% easy, 50% avg, 20% diff
        const mod = idx % 10;
        if (mod <= 2) return 'easy';
        if (mod <= 7) return 'avg';
        return 'diff';
      };

      // 2. Build Step 5 rows by Chapter
      const chMap = new Map<string, {
        chapterName: string;
        chapterNumber: number;
        grid: Record<`${ObjKey}_${DiffKey}`, { count: number; totalMarks: number; questionIds: string[] }>;
      }>();

      // Initialize all active chapters
      activeChapters.forEach((ch, idx) => {
        const gridObj: any = {};
        (['know', 'und', 'app', 'skill'] as ObjKey[]).forEach(o => {
          (['easy', 'avg', 'diff'] as DiffKey[]).forEach(d => {
            gridObj[`${o}_${d}`] = { count: 0, totalMarks: 0, questionIds: [] };
          });
        });
        chMap.set(ch.chapterName, {
          chapterName: ch.chapterName,
          chapterNumber: ch.chapterNumber || idx + 1,
          grid: gridObj,
        });
      });

      // Populate from questions
      allPaperQuestions.forEach((q, idx) => {
        const chName = q.chapterName || activeChapters[0]?.chapterName || 'ಸಾಮಾನ್ಯ';
        if (!chMap.has(chName)) {
          const gridObj: any = {};
          (['know', 'und', 'app', 'skill'] as ObjKey[]).forEach(o => {
            (['easy', 'avg', 'diff'] as DiffKey[]).forEach(d => {
              gridObj[`${o}_${d}`] = { count: 0, totalMarks: 0, questionIds: [] };
            });
          });
          chMap.set(chName, {
            chapterName: chName,
            chapterNumber: chMap.size + 1,
            grid: gridObj,
          });
        }

        const entry = chMap.get(chName)!;
        const obj = getObjective(q, idx);
        const diff = getDifficulty(q, idx);
        const cell = entry.grid[`${obj}_${diff}`];
        cell.count += 1;
        cell.totalMarks += q.marks;
        const qId = q.bankQuestionId || q.uid || (q as any).id || `q_${idx}`;
        cell.questionIds.push(qId);

        // Tag back onto question for consistency across views
        q.objective = obj;
        q.objectiveName = obj === 'know' ? 'ಜ್ಞಾನ' : obj === 'und' ? 'ತಿಳುವಳಿಕೆ' : obj === 'app' ? 'ಅನ್ವಯ' : 'ಕೌಶಲ';
        q.difficulty = diff === 'easy' ? 'ಸುಲಭ' : diff === 'diff' ? 'ಕಠಿಣ' : 'ಸಾಧಾರಣ';
      });

      // Build MasterGridRows
      const step5MasterGrid: MasterGridRow[] = Array.from(chMap.entries()).map(([chName, item]) => {
        const mkCell = (k: `${ObjKey}_${DiffKey}`): ObjectiveDiffCell | null => {
          const c = item.grid[k];
          if (c.count === 0) return null;
          const avgMarks = Math.round(c.totalMarks / c.count);
          return {
            questionsCount: c.count,
            marksPerQuestion: avgMarks,
            totalMarks: c.totalMarks,
            questionIds: [...c.questionIds],
          };
        };

        const totalQ = Object.values(item.grid).reduce((s, c) => s + c.count, 0);
        const totalM = Object.values(item.grid).reduce((s, c) => s + c.totalMarks, 0);

        const chObj = activeChapters.find(c => c.chapterName === chName);

        return {
          chapterId: chObj?.chapterId || `ch_${item.chapterNumber}`,
          chapterNumber: item.chapterNumber,
          chapterName: chName,
          knowledgeEasy: mkCell('know_easy'),
          knowledgeAvg: mkCell('know_avg'),
          knowledgeDiff: mkCell('know_diff'),
          understandingEasy: mkCell('und_easy'),
          understandingAvg: mkCell('und_avg'),
          understandingDiff: mkCell('und_diff'),
          applicationEasy: mkCell('app_easy'),
          applicationAvg: mkCell('app_avg'),
          applicationDiff: mkCell('app_diff'),
          skillEasy: mkCell('skill_easy'),
          skillAvg: mkCell('skill_avg'),
          skillDiff: mkCell('skill_diff'),
          totalQuestions: totalQ,
          totalMarks: totalM,
        };
      });

      const paperTotalMarks = allPaperQuestions.reduce((s, q) => s + q.marks, 0);
      const paperTotalQ = allPaperQuestions.length;

      // Step 4 Chapters
      const step4Chapters: ChapterWeightage[] = step5MasterGrid.map((row, idx) => ({
        chapterId: row.chapterId,
        chapterNumber: row.chapterNumber || idx + 1,
        chapterName: row.chapterName,
        questionsCount: row.totalQuestions,
        marks: row.totalMarks,
        percentage: paperTotalMarks > 0 ? Math.round((row.totalMarks / paperTotalMarks) * 100) : 0,
      }));

      // Step 1 Objectives - Exactly Tallying with Step 5 column sums
      const sumGrid = (filterPrefix: string) => {
        let q = 0;
        let m = 0;
        step5MasterGrid.forEach(row => {
          Object.entries(row).forEach(([k, cell]) => {
            if (k.startsWith(filterPrefix) && cell && typeof cell === 'object' && 'questionsCount' in cell) {
              q += (cell as ObjectiveDiffCell).questionsCount;
              m += (cell as ObjectiveDiffCell).totalMarks;
            }
          });
        });
        return { q, m };
      };

      const knowTally = sumGrid('knowledge');
      const undTally = sumGrid('understanding');
      const appTally = sumGrid('application');
      const skillTally = sumGrid('skill');

      const step1Objectives: ObjectiveWeightage[] = [
        {
          id: 'know',
          name: 'ಜ್ಞಾನ / ಸ್ಮರಣೆ (Knowledge)',
          percentage: paperTotalMarks > 0 ? Math.round((knowTally.m / paperTotalMarks) * 100) : 25,
          marks: knowTally.m,
          questionsCount: knowTally.q,
        },
        {
          id: 'und',
          name: 'ಗ್ರಹಿಕೆ / ತಿಳುವಳಿಕೆ (Understanding)',
          percentage: paperTotalMarks > 0 ? Math.round((undTally.m / paperTotalMarks) * 100) : 45,
          marks: undTally.m,
          questionsCount: undTally.q,
        },
        {
          id: 'app',
          name: 'ಅಭಿವ್ಯಕ್ತಿ / ಅನ್ವಯ (Application)',
          percentage: paperTotalMarks > 0 ? Math.round((appTally.m / paperTotalMarks) * 100) : 20,
          marks: appTally.m,
          questionsCount: appTally.q,
        },
        {
          id: 'skill',
          name: 'ಪ್ರಶಂಸೆ / ಕೌಶಲ / ನಕ್ಷೆ (Skill)',
          percentage: paperTotalMarks > 0 ? Math.round((skillTally.m / paperTotalMarks) * 100) : 10,
          marks: skillTally.m,
          questionsCount: skillTally.q,
        },
      ];

      // Step 3 Difficulty - Exactly Tallying with Step 5 sub-columns
      const sumDiff = (diffSuffix: string) => {
        let q = 0;
        let m = 0;
        step5MasterGrid.forEach(row => {
          Object.entries(row).forEach(([k, cell]) => {
            if (k.endsWith(diffSuffix) && cell && typeof cell === 'object' && 'questionsCount' in cell) {
              q += (cell as ObjectiveDiffCell).questionsCount;
              m += (cell as ObjectiveDiffCell).totalMarks;
            }
          });
        });
        return { q, m };
      };

      const easyTally = sumDiff('Easy');
      const avgTally = sumDiff('Avg');
      const diffTally = sumDiff('Diff');

      const step3Difficulty: DifficultyWeightage[] = [
        {
          id: 'easy',
          name: 'ಸುಲಭ (Easy)',
          marks: easyTally.m,
          percentage: paperTotalMarks > 0 ? Math.round((easyTally.m / paperTotalMarks) * 100) : 30,
          questionsCount: easyTally.q,
        },
        {
          id: 'avg',
          name: 'ಸಾಧಾರಣ (Avg)',
          marks: avgTally.m,
          percentage: paperTotalMarks > 0 ? Math.round((avgTally.m / paperTotalMarks) * 100) : 50,
          questionsCount: avgTally.q,
        },
        {
          id: 'diff',
          name: 'ಕಠಿಣ (Diff)',
          marks: diffTally.m,
          percentage: paperTotalMarks > 0 ? Math.round((diffTally.m / paperTotalMarks) * 100) : 20,
          questionsCount: diffTally.q,
        },
      ];

      // Step 2 Question Types - Exactly Tallying from Sections
      const step2QuestionTypes: QuestionTypeWeightage[] = paper.sections.map(sec => {
        const secMarks = sec.questions.reduce((s, q) => s + q.marks, 0);
        const marksPerQ = sec.questions[0]?.marks || sec.blueprint.marksPerQuestion || 1;
        return {
          id: sec.blueprint.formatCategoryId || 'vsa',
          name: sec.blueprint.questionType || sec.blueprint.title,
          percentage: paperTotalMarks > 0 ? Math.round((secMarks / paperTotalMarks) * 100) : 20,
          marks: secMarks,
          questionsCount: sec.questions.length,
          marksPerQuestion: marksPerQ,
        };
      });

      // Strict 100% balancing across all 4 steps so percentages strictly sum to 100% and never exceed 100%
      normalizeStepPercentages(step1Objectives, paperTotalMarks);
      normalizeStepPercentages(step2QuestionTypes, paperTotalMarks);
      normalizeStepPercentages(step3Difficulty, paperTotalMarks);
      normalizeStepPercentages(step4Chapters, paperTotalMarks);

      return {
        title: `${bank.metadata.grade} ${bank.metadata.subject} - ಅಧಿಕೃತ ಪರೀಕ್ಷಾ ನೀಲನಕಾಶೆ (Blue Print)`,
        grade: bank.metadata.grade,
        subject: bank.metadata.subject,
        totalMarks: paperTotalMarks,
        totalQuestions: paperTotalQ,
        step1Objectives,
        step2QuestionTypes,
        step3Difficulty,
        step4Chapters,
        step5MasterGrid,
      };
    }
  }

  // BASELINE BLUEPRINT GENERATION (When paper is not yet generated)
  // Step 4 Chapter Weightages
  const totalCustomWeight = customChapterPercentages
    ? Object.values(customChapterPercentages).reduce((s, p) => s + p, 0)
    : 0;

  const rawChapterAllocations = activeChapters.map((ch, idx) => {
    let weightRatio: number;
    if (customChapterPercentages && customChapterPercentages[ch.chapterId]) {
      weightRatio = (customChapterPercentages[ch.chapterId] || 1) / (totalCustomWeight || 100);
    } else if (ch.weightagePercent && ch.weightagePercent > 0) {
      weightRatio = ch.weightagePercent / 100;
    } else {
      const qInCh = Math.max(5, ch.questions?.length || 10);
      const totalQInAll = activeChapters.reduce(
        (s, c) => s + Math.max(5, c.questions?.length || 10),
        0
      );
      weightRatio = qInCh / (totalQInAll || 1);
    }

    const marks = Math.max(2, Math.round(weightRatio * targetMarks));
    const qCount = Math.max(1, Math.round(weightRatio * targetQuestions));

    return {
      chapterId: ch.chapterId,
      chapterNumber: ch.chapterNumber || idx + 1,
      chapterName: ch.chapterName,
      marks,
      questionsCount: qCount,
      percentage: Math.round(weightRatio * 100),
    };
  });

  // Rebalance to exact targetMarks and targetQuestions
  let marksDiff = targetMarks - rawChapterAllocations.reduce((s, c) => s + c.marks, 0);
  let qDiff = targetQuestions - rawChapterAllocations.reduce((s, c) => s + c.questionsCount, 0);

  const step4Chapters: ChapterWeightage[] = rawChapterAllocations.map(ch => {
    let m = ch.marks;
    let q = ch.questionsCount;
    if (marksDiff !== 0) {
      const step = marksDiff > 0 ? 1 : -1;
      m = Math.max(1, m + step);
      marksDiff -= step;
    }
    if (qDiff !== 0) {
      const step = qDiff > 0 ? 1 : -1;
      q = Math.max(1, q + step);
      qDiff -= step;
    }
    return {
      ...ch,
      marks: m,
      questionsCount: q,
      percentage: Math.round((m / targetMarks) * 100),
    };
  });

  // Step 5 Master 12-Column Grid
  const step5MasterGrid: MasterGridRow[] = step4Chapters.map((ch, idx) => {
    // Distribute ch.questionsCount across 4 objectives and 3 difficulties
    const totalQ = Math.max(1, ch.questionsCount);
    const totalM = Math.max(1, ch.marks);

    // Pedagogical distribution:
    // Knowledge: ~25%, Understanding: ~45%, Application: ~20%, Skill: ~10%
    const qKnow = Math.max(0, Math.round(totalQ * 0.25));
    const qUnd = Math.max(1, Math.round(totalQ * 0.45));
    const qApp = Math.max(0, Math.round(totalQ * 0.20));
    const qSkill = Math.max(0, totalQ - qKnow - qUnd - qApp);

    return {
      chapterId: ch.chapterId,
      chapterNumber: ch.chapterNumber,
      chapterName: ch.chapterName,
      knowledgeEasy: qKnow > 0 ? { questionsCount: qKnow, marksPerQuestion: 1, totalMarks: qKnow, questionIds: [] } : null,
      knowledgeAvg: null,
      knowledgeDiff: null,
      understandingEasy: qUnd > 1 ? { questionsCount: 1, marksPerQuestion: 1, totalMarks: 1, questionIds: [] } : null,
      understandingAvg: qUnd > 0 ? { questionsCount: Math.max(1, qUnd - 1), marksPerQuestion: 2, totalMarks: Math.max(1, qUnd - 1) * 2, questionIds: [] } : null,
      understandingDiff: null,
      applicationEasy: null,
      applicationAvg: qApp > 1 ? { questionsCount: 1, marksPerQuestion: 2, totalMarks: 2, questionIds: [] } : null,
      applicationDiff: qApp > 0 ? { questionsCount: 1, marksPerQuestion: 3, totalMarks: 3, questionIds: [] } : null,
      skillEasy: null,
      skillAvg: qSkill > 0 && idx % 2 === 0 ? { questionsCount: 1, marksPerQuestion: 2, totalMarks: 2, questionIds: [] } : null,
      skillDiff: qSkill > 0 && idx % 2 !== 0 ? { questionsCount: 1, marksPerQuestion: 4, totalMarks: 4, questionIds: [] } : null,
      totalQuestions: ch.questionsCount,
      totalMarks: ch.marks,
    };
  });

  // Calculate exact Step 1 & Step 3 from Grid
  let kM = 0, kQ = 0, uM = 0, uQ = 0, aM = 0, aQ = 0, sM = 0, sQ = 0;
  let eM = 0, eQ = 0, avM = 0, avQ = 0, dM = 0, dQ = 0;

  step5MasterGrid.forEach(r => {
    const cells = [
      { c: r.knowledgeEasy, o: 'k', d: 'e' },
      { c: r.knowledgeAvg, o: 'k', d: 'a' },
      { c: r.knowledgeDiff, o: 'k', d: 'd' },
      { c: r.understandingEasy, o: 'u', d: 'e' },
      { c: r.understandingAvg, o: 'u', d: 'a' },
      { c: r.understandingDiff, o: 'u', d: 'd' },
      { c: r.applicationEasy, o: 'a', d: 'e' },
      { c: r.applicationAvg, o: 'a', d: 'a' },
      { c: r.applicationDiff, o: 'a', d: 'd' },
      { c: r.skillEasy, o: 's', d: 'e' },
      { c: r.skillAvg, o: 's', d: 'a' },
      { c: r.skillDiff, o: 's', d: 'd' },
    ];
    cells.forEach(({ c, o, d }) => {
      if (c) {
        if (o === 'k') { kM += c.totalMarks; kQ += c.questionsCount; }
        if (o === 'u') { uM += c.totalMarks; uQ += c.questionsCount; }
        if (o === 'a') { aM += c.totalMarks; aQ += c.questionsCount; }
        if (o === 's') { sM += c.totalMarks; sQ += c.questionsCount; }

        if (d === 'e') { eM += c.totalMarks; eQ += c.questionsCount; }
        if (d === 'a') { avM += c.totalMarks; avQ += c.questionsCount; }
        if (d === 'd') { dM += c.totalMarks; dQ += c.questionsCount; }
      }
    });
  });

  // Rebalance so sum equals targetMarks
  const mRem = targetMarks - (kM + uM + aM + sM);
  if (mRem !== 0) uM += mRem;
  const qRem = targetQuestions - (kQ + uQ + aQ + sQ);
  if (qRem !== 0) uQ += qRem;

  const step1Objectives: ObjectiveWeightage[] = [
    { id: 'know', name: 'ಜ್ಞಾನ / ಸ್ಮರಣೆ (Knowledge)', percentage: Math.round((kM / targetMarks) * 100), marks: kM, questionsCount: kQ },
    { id: 'und', name: 'ಗ್ರಹಿಕೆ / ತಿಳುವಳಿಕೆ (Understanding)', percentage: Math.round((uM / targetMarks) * 100), marks: uM, questionsCount: uQ },
    { id: 'app', name: 'ಅಭಿವ್ಯಕ್ತಿ / ಅನ್ವಯ (Application)', percentage: Math.round((aM / targetMarks) * 100), marks: aM, questionsCount: aQ },
    { id: 'skill', name: 'ಪ್ರಶಂಸೆ / ಕೌಶಲ / ನಕ್ಷೆ (Skill)', percentage: Math.round((sM / targetMarks) * 100), marks: sM, questionsCount: sQ },
  ];

  const step3Difficulty: DifficultyWeightage[] = [
    { id: 'easy', name: 'ಸುಲಭ (Easy)', marks: eM || Math.round(targetMarks * 0.3), percentage: 30, questionsCount: eQ },
    { id: 'avg', name: 'ಸಾಧಾರಣ (Avg)', marks: avM || Math.round(targetMarks * 0.5), percentage: 50, questionsCount: avQ },
    { id: 'diff', name: 'ಕಠಿಣ (Diff)', marks: dM || Math.round(targetMarks * 0.2), percentage: 20, questionsCount: dQ },
  ];

  const qTypes = solveExactQuestionTypes(targetMarks, targetQuestions);
  const step2QuestionTypes: QuestionTypeWeightage[] = [
    { id: 'mcq', name: 'ವಸ್ತುನಿಷ್ಠ (MCQ)', percentage: Math.round(((qTypes.mcq * 1) / targetMarks) * 100), marks: qTypes.mcq * 1, questionsCount: qTypes.mcq, marksPerQuestion: 1 },
    { id: 'vsa', name: 'ಕಿರು ಉತ್ತರ - 1 (1M)', percentage: Math.round(((qTypes.vsa * 1) / targetMarks) * 100), marks: qTypes.vsa * 1, questionsCount: qTypes.vsa, marksPerQuestion: 1 },
    { id: 'sa', name: 'ಕಿರು ಉತ್ತರ - 2 (2M)', percentage: Math.round(((qTypes.sa * 2) / targetMarks) * 100), marks: qTypes.sa * 2, questionsCount: qTypes.sa, marksPerQuestion: 2 },
    { id: 'la1', name: 'ದೀರ್ಘ ಉತ್ತರ - 1 (3M)', percentage: Math.round(((qTypes.la1 * 3) / targetMarks) * 100), marks: qTypes.la1 * 3, questionsCount: qTypes.la1, marksPerQuestion: 3 },
    { id: 'la2', name: 'ದೀರ್ಘ ಉತ್ತರ - 2 (4M)', percentage: Math.round(((qTypes.la2 * 4) / targetMarks) * 100), marks: qTypes.la2 * 4, questionsCount: qTypes.la2, marksPerQuestion: 4 },
  ];

  normalizeStepPercentages(step1Objectives, targetMarks);
  normalizeStepPercentages(step2QuestionTypes, targetMarks);
  normalizeStepPercentages(step3Difficulty, targetMarks);
  normalizeStepPercentages(step4Chapters, targetMarks);

  return {
    title: `${bank.metadata.grade} ${bank.metadata.subject} - ಅಧಿಕೃತ ಪರೀಕ್ಷಾ ನೀಲನಕಾಶೆ (Blue Print)`,
    grade: bank.metadata.grade,
    subject: bank.metadata.subject,
    totalMarks: targetMarks,
    totalQuestions: targetQuestions,
    step1Objectives,
    step2QuestionTypes,
    step3Difficulty,
    step4Chapters,
    step5MasterGrid,
  };
}

/**
 * Generates section blueprints matching the official Karnataka blueprint format
 */
export function buildSectionsFromBlueprint(
  bank: QuestionBank,
  selectedChapterIds: string[],
  targetMarks = 40,
  targetQuestions = 24
): SectionBlueprint[] {
  const bp = generateOfficialBlueprint(bank, selectedChapterIds, targetMarks, targetQuestions);
  const romanMap = ['I', 'II', 'III', 'IV', 'V'];

  return bp.step2QuestionTypes.map((t, idx) => {
    let fmtCat = 'mcq';
    let instruction = 'ಸರಿಯಾದ ಉತ್ತರವನ್ನು ಆರಿಸಿ ಬರೆಯಿರಿ:';

    if (t.id === 'mcq') {
      fmtCat = 'mcq';
      instruction = 'ಕೆಳಗಿನ ಪ್ರಶ್ನೆಗಳಿಗೆ ನಾಲ್ಕು ಆಯ್ಕೆಗಳನ್ನು ನೀಡಲಾಗಿದೆ. ಸರಿಯಾದ ಉತ್ತರವನ್ನು ಆರಿಸಿ ಬರೆಯಿರಿ:';
    } else if (t.id === 'vsa') {
      fmtCat = 'one_sentence';
      instruction = 'ಕೆಳಗಿನ ಪ್ರಶ್ನೆಗಳಿಗೆ ಒಂದು ವಾಕ್ಯದಲ್ಲಿ ಉತ್ತರಿಸಿ / ಬಿಟ್ಟ ಸ್ಥಳ ತುಂಬಿರಿ:';
    } else if (t.id === 'sa') {
      fmtCat = 'short_2m';
      instruction = 'ಕೆಳಗಿನ ಪ್ರಶ್ನೆಗಳಿಗೆ ಎರಡು ಅಥವಾ ಮೂರು ವಾಕ್ಯಗಳಲ್ಲಿ ಉತ್ತರಿಸಿ:';
    } else if (t.id === 'la1') {
      fmtCat = 'short_3m';
      instruction = 'ಕೆಳಗಿನ ಪ್ರಶ್ನೆಗಳಿಗೆ ವಿವರವಾಗಿ ಉತ್ತರಿಸಿ:';
    } else if (t.id === 'la2') {
      fmtCat = 'long_4m';
      instruction = 'ಕೆಳಗಿನ ಪ್ರಶ್ನೆಗಳಿಗೆ ಸಮಗ್ರವಾಗಿ ಉತ್ತರಿಸಿ / ಚಿತ್ರ ರಚಿಸಿ:';
    }

    return {
      id: `sec_${t.id}_${Date.now()}_${idx}`,
      sectionRoman: romanMap[idx] || `${idx + 1}`,
      title: `ವಿಭಾಗ - ${romanMap[idx] || idx + 1} : ${t.name}`,
      instructionText: instruction,
      questionType: t.name,
      formatCategoryId: fmtCat,
      selectedChapterIds,
      selectedLearningOutcomes: ['all'],
      difficulty: 'all',
      marksPerQuestion: t.marksPerQuestion,
      questionCount: t.questionsCount,
    };
  });
}
