/**
 * Main Application Component: ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ರಚನಾ ಸಾಧನ (QUESTION PAPER GENERATOR BY S R ANGADI)
 * Designed for Karnataka State Syllabus Question Papers and Answer Keys
 * Author: M I Nilaji / S R Angadi
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  IndexEntry,
  QuestionBank,
  Chapter,
  PaperHeader,
  GeneratedPaper,
  SectionBlueprint,
  STANDARD_QUESTION_FORMATS,
  getAvailableFormatsForSubject,
} from './types/questionBank.ts';
import {
  fetchBankIndex,
  loadQuestionBankByPath,
  registerCustomBank,
  matchesGrade,
  canonicalGradeLabel,
  extractGradeKey,
  deduceSubjectCode,
} from './services/dataLoader.ts';
import { generateQuestionPaper, buildBlueprintsFromSelectedFormats } from './services/paperGenerator.ts';
import { generateOfficialBlueprint } from './services/blueprintEngine.ts';

import { TopBar } from './components/TopBar.tsx';
import { SetupPanel } from './components/SetupPanel.tsx';
import { ChapterSelectionPanel } from './components/ChapterSelectionPanel.tsx';
import { QuestionFormatsPanel } from './components/QuestionFormatsPanel.tsx';
import { PaperPreview } from './components/PaperPreview.tsx';
import { AnswerKeyPreview } from './components/AnswerKeyPreview.tsx';
import { QuestionBankExplorer } from './components/QuestionBankExplorer.tsx';
import { BluePrintView } from './components/BluePrintView.tsx';
import { JsonGuideModal } from './components/JsonGuideModal.tsx';
import { SectionConfigModal } from './components/SectionConfigModal.tsx';
import { AiJsonGenerator } from './components/AiJsonGenerator.tsx';

import {
  AlertTriangle,
  ArrowLeft,
  Printer,
  RotateCcw,
  RefreshCw,
  FileText,
  FileCheck,
  Layers,
} from 'lucide-react';

export default function App() {
  // Navigation view state: 'setup' (default dashboard) | 'preview' (generated paper) | 'explorer' | 'blueprint' | 'ai_generator'
  const [activeView, setActiveView] = useState<'setup' | 'preview' | 'explorer' | 'blueprint' | 'ai_generator'>('setup');

  // JSON Guide Modal state
  const [isJsonGuideOpen, setIsJsonGuideOpen] = useState<boolean>(false);

  // Preview sub-mode: 'paper' (Question Paper only) | 'answers' (Answer key only) | 'both'
  const [previewSubMode, setPreviewSubMode] = useState<'paper' | 'answers' | 'both'>('paper');

  // Central Index and question bank files
  const [availableFiles, setAvailableFiles] = useState<IndexEntry[]>([]);
  const [selectedFileId, setSelectedFileId] = useState<string>('maths_class6');

  // Form states matching screenshot
  const [schoolName, setSchoolName] = useState<string>('GOVT KHPS NINGYANATTI');
  const [medium, setMedium] = useState<string>('ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)');
  const [grade, setGrade] = useState<string>('6 ನೇ ತರಗತಿ (Class 6)');
  const [semesterPart, setSemesterPart] = useState<'sem1' | 'sem2' | 'all'>('sem2');
  const [paperModel, setPaperModel] = useState<'paper' | 'answers' | 'both'>('paper');
  const [examType, setExamType] = useState<string>('ಸಂಕಲನಾತ್ಮಕ ಮೌಲ್ಯಮಾಪನ-1 (SA-1 ಮಧ್ಯವಾರ್ಷಿಕ)');
  const [targetMarks, setTargetMarks] = useState<number>(40);
  const [targetQuestionsCount, setTargetQuestionsCount] = useState<number>(24);
  const [examDateOrYear, setExamDateOrYear] = useState<string>('2026-27');

  // Active loaded Question Bank
  const [currentBank, setCurrentBank] = useState<QuestionBank | null>(null);
  const [isLoadingBank, setIsLoadingBank] = useState<boolean>(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Selected Chapters
  const [selectedChapterIds, setSelectedChapterIds] = useState<string[]>([]);

  // Selected Question Formats (defaults to all 12 standard formats as in screenshot)
  const [selectedFormatIds, setSelectedFormatIds] = useState<string[]>(
    STANDARD_QUESTION_FORMATS.map(f => f.id)
  );

  // Generated Paper State
  const [generatedPaper, setGeneratedPaper] = useState<GeneratedPaper | null>(null);
  const [initialGeneratedPaper, setInitialGeneratedPaper] = useState<GeneratedPaper | null>(null);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Section Configuration Modal State (vibhagavaru prashnegalannu hondisuva option)
  const [isSectionConfigOpen, setIsSectionConfigOpen] = useState<boolean>(false);
  const [customSections, setCustomSections] = useState<SectionBlueprint[] | null>(null);

  // 1. Initial Load: Fetch Index and initial Question Bank (Maths Class 6 by default as in screenshot)
  useEffect(() => {
    async function init() {
      try {
        setIsLoadingBank(true);
        const index = await fetchBankIndex();
        setAvailableFiles(index.files);

        // Find maths_class6 or first
        const initialFile = index.files.find(f => f.id === 'maths_class6') || index.files[0];
        if (initialFile) {
          setSelectedFileId(initialFile.id);
          const bank = await loadQuestionBankByPath(initialFile.path);
          setCurrentBank(bank);

          // For Maths, default to Semester 2 chapters (chapters 6 to 10) as in user's screenshot
          const sem2Chapters = bank.chapters.filter(c => c.semester === 2);
          const initialChs = sem2Chapters.length > 0 ? sem2Chapters : bank.chapters;
          setSelectedChapterIds(initialChs.map(c => c.chapterId));
        }
      } catch (err) {
        console.error('Initialization error:', err);
        setLoadError('ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ ಲೋಡ್ ಮಾಡುವಲ್ಲಿ ದೋಷ ಕಂಡುಬಂದಿದೆ.');
      } finally {
        setIsLoadingBank(false);
      }
    }
    init();
  }, []);

  // 2. When Subject / File Changes
  const handleSelectFile = useCallback(
    async (fileId: string) => {
      const fileEntry = availableFiles.find(f => f.id === fileId);
      if (!fileEntry) return;

      try {
        setIsLoadingBank(true);
        setSelectedFileId(fileId);

        // Also sync Grade if the fileEntry specifies a different grade
        if (fileEntry.grade && !matchesGrade({ grade }, fileEntry.grade)) {
          setGrade(canonicalGradeLabel(extractGradeKey(fileEntry.grade)));
        }

        const bank = await loadQuestionBankByPath(fileEntry.path);
        setCurrentBank(bank);

        // Select chapters according to current semesterPart (fallback to all if semester subset is empty)
        let chs = bank.chapters;
        if (semesterPart === 'sem1') {
          const filtered = bank.chapters.filter(c => c.semester === 1);
          if (filtered.length > 0) chs = filtered;
        } else if (semesterPart === 'sem2') {
          const filtered = bank.chapters.filter(c => c.semester === 2);
          if (filtered.length > 0) chs = filtered;
        }
        setSelectedChapterIds(chs.map(c => c.chapterId));

        // Auto-select valid question formats for this subject (hiding language formats for core subjects)
        const availFmts = getAvailableFormatsForSubject(
          fileEntry.subjectCode || fileEntry.subject || bank.metadata.subject
        );
        setSelectedFormatIds(availFmts.map(f => f.id));

        // Reset paper for new subject
        setGeneratedPaper(null);
        setInitialGeneratedPaper(null);
        setGenerationError(null);
      } catch (err) {
        console.error('Error changing question bank:', err);
        setLoadError('ಆಯ್ದ ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ ಲೋಡ್ ಮಾಡಲು ಸಾಧ್ಯವಾಗಿಲ್ಲ.');
      } finally {
        setIsLoadingBank(false);
      }
    },
    [availableFiles, semesterPart, grade]
  );

  // 3. When Grade changes from dropdown, switch grade and automatically select matching question bank
  const handleGradeChange = useCallback(
    (newGrade: string) => {
      const canon = canonicalGradeLabel(extractGradeKey(newGrade));
      setGrade(canon);

      // Find files matching the new grade
      const matchingFiles = availableFiles.filter(f => matchesGrade(f, canon));
      if (matchingFiles.length > 0) {
        const currentFile = availableFiles.find(f => f.id === selectedFileId);
        // Try to match the same subject or subjectCode
        const sameSubject = matchingFiles.find(
          f =>
            (currentFile && f.subjectCode === currentFile.subjectCode) ||
            (currentFile && f.subject.toLowerCase() === currentFile.subject.toLowerCase())
        );
        const target = sameSubject || matchingFiles[0];
        handleSelectFile(target.id);
      }
    },
    [availableFiles, selectedFileId, handleSelectFile]
  );

  // 4. When Semester Part changes, auto-filter/select matching chapters
  const handleSemesterPartChange = useCallback(
    (part: 'sem1' | 'sem2' | 'all') => {
      setSemesterPart(part);
      if (!currentBank) return;

      let chs = currentBank.chapters;
      if (part === 'sem1') {
        const filtered = currentBank.chapters.filter(c => c.semester === 1);
        if (filtered.length > 0) chs = filtered;
      } else if (part === 'sem2') {
        const filtered = currentBank.chapters.filter(c => c.semester === 2);
        if (filtered.length > 0) chs = filtered;
      }
      setSelectedChapterIds(chs.map(c => c.chapterId));
    },
    [currentBank]
  );

  // When Exam Type changes, automatically synchronize semester part (e.g. SA-2 -> sem2, SA-1 -> sem1)
  const handleExamTypeChange = useCallback(
    (newExamType: string) => {
      setExamType(newExamType);
      if (!currentBank) return;

      let newPart: 'sem1' | 'sem2' | 'all' = semesterPart;
      if (
        newExamType.includes('SA-2') ||
        newExamType.includes('FA-3') ||
        newExamType.includes('FA-4')
      ) {
        newPart = 'sem2';
      } else if (
        newExamType.includes('SA-1') ||
        newExamType.includes('FA-1') ||
        newExamType.includes('FA-2')
      ) {
        newPart = 'sem1';
      }

      setSemesterPart(newPart);

      let chs = currentBank.chapters;
      if (newPart === 'sem1') {
        const filtered = currentBank.chapters.filter(c => c.semester === 1);
        if (filtered.length > 0) chs = filtered;
      } else if (newPart === 'sem2') {
        const filtered = currentBank.chapters.filter(c => c.semester === 2);
        if (filtered.length > 0) chs = filtered;
      }
      setSelectedChapterIds(chs.map(c => c.chapterId));
    },
    [currentBank, semesterPart]
  );

  // Chapters to display based on semester part (with resilient fallback so never empty)
  const visibleChapters = useMemo(() => {
    if (!currentBank) return [];
    let list: Chapter[] = [];
    if (semesterPart === 'sem1') {
      list = currentBank.chapters.filter(c => c.semester === 1);
    } else if (semesterPart === 'sem2') {
      list = currentBank.chapters.filter(c => c.semester === 2);
    } else {
      list = currentBank.chapters;
    }

    // Resilience: if filtered semester has 0 chapters, fall back to all chapters
    if (list.length === 0 && currentBank.chapters.length > 0) {
      return currentBank.chapters;
    }
    return list;
  }, [currentBank, semesterPart]);

  // Available question counts per format for the selected subject and chapters
  const formatCounts = useMemo(() => {
    if (!currentBank) return {};
    const filteredChs =
      selectedChapterIds.length === 0
        ? currentBank.chapters
        : currentBank.chapters.filter(c => selectedChapterIds.includes(c.chapterId));

    const counts: Record<string, number> = {};
    for (const ch of filteredChs) {
      for (const q of ch.questions) {
        counts[q.formatCategoryId] = (counts[q.formatCategoryId] || 0) + 1;
      }
    }
    return counts;
  }, [currentBank, selectedChapterIds]);

  // Official 5-Stage Blueprint with complete tallying and interconnectivity
  const activeBlueprint = useMemo(() => {
    if (!currentBank) return null;
    return generateOfficialBlueprint(
      currentBank,
      selectedChapterIds,
      targetMarks,
      targetQuestionsCount,
      generatedPaper
    );
  }, [currentBank, selectedChapterIds, targetMarks, targetQuestionsCount, generatedPaper]);

  // Generate Paper Trigger: "Instant 0.01s"
  const handleGeneratePaper = useCallback((targetView: 'preview' | 'blueprint' = 'preview') => {
    if (!currentBank) return;

    if (selectedChapterIds.length === 0) {
      setGenerationError('ದಯವಿಟ್ಟು ಕನಿಷ್ಠ ಒಂದು ಅಧ್ಯಾಯವನ್ನು ಆಯ್ಕೆಮಾಡಿ (Please select at least one chapter).');
      return;
    }

    if (selectedFormatIds.length === 0) {
      setGenerationError('ದಯವಿಟ್ಟು ಕನಿಷ್ಠ ಒಂದು ಪ್ರಶ್ನೆ ಪ್ರಕಾರವನ್ನು ಆಯ್ಕೆಮಾಡಿ (Please select at least one question format).');
      return;
    }

    setIsGenerating(true);
    setGenerationError(null);

    try {
      // Use custom configured sections if set by user, otherwise auto-generate from blueprint/formats
      let blueprints: SectionBlueprint[];
      if (customSections && customSections.length > 0) {
        blueprints = customSections.map(s => ({
          ...s,
          selectedChapterIds: selectedChapterIds.length > 0 ? selectedChapterIds : s.selectedChapterIds,
        }));
      } else {
        blueprints = buildBlueprintsFromSelectedFormats(
          currentBank,
          selectedFormatIds,
          selectedChapterIds,
          targetMarks,
          targetQuestionsCount
        );
      }

      const paperHeader: PaperHeader = {
        schoolName,
        examName: examType,
        academicYear: examDateOrYear,
        grade,
        subject: currentBank.metadata.subject,
        medium,
        date: examDateOrYear,
        time: '೨ ಗಂಟೆ ೩೦ ನಿಮಿಷಗಳು',
        maxMarks: targetMarks,
        generalInstructions: [
          'ಎಲ್ಲಾ ಪ್ರಶ್ನೆಗಳಿಗೂ ಉತ್ತರಿಸುವುದು ಕಡ್ಡಾಯವಾಗಿದೆ.',
          'ಪ್ರಶ್ನೆಗಳಿಗೆ ನಿಗದಿಪಡಿಸಿದ ಅಂಕಗಳನ್ನು ಬಲಭಾಗದಲ್ಲಿ ನೀಡಲಾಗಿದೆ.',
          'ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆಯನ್ನು ಎಚ್ಚರಿಕೆಯಿಂದ ಓದಿ ಉತ್ತರಿಸಿ.',
        ],
      };

      const paper = generateQuestionPaper(currentBank, paperHeader, blueprints);
      setGeneratedPaper(paper);
      setInitialGeneratedPaper(JSON.parse(JSON.stringify(paper)));
      setPreviewSubMode(paperModel);
      if (targetView === 'blueprint') {
        setActiveView('blueprint');
      } else {
        setActiveView('preview');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ರಚನೆಯಲ್ಲಿ ದೋಷ ಸಂಭವಿಸಿದೆ.';
      setGenerationError(msg);
    } finally {
      setIsGenerating(false);
    }
  }, [
    currentBank,
    selectedChapterIds,
    selectedFormatIds,
    customSections,
    targetMarks,
    targetQuestionsCount,
    schoolName,
    examType,
    examDateOrYear,
    grade,
    medium,
    paperModel,
  ]);

  // Regenerate with same settings
  const handleRegenerate = useCallback(() => {
    handleGeneratePaper('preview');
  }, [handleGeneratePaper]);

  // Reset to initial generated version
  const handleResetToGenerated = useCallback(() => {
    if (initialGeneratedPaper) {
      setGeneratedPaper(JSON.parse(JSON.stringify(initialGeneratedPaper)));
    }
  }, [initialGeneratedPaper]);

  // Open Blueprint view, ensuring a paper is generated so unit question counts & swap work seamlessly
  const handleOpenBlueprint = useCallback(() => {
    if (!generatedPaper && currentBank && selectedChapterIds.length > 0) {
      handleGeneratePaper('blueprint');
    }
    setActiveView('blueprint');
  }, [generatedPaper, currentBank, selectedChapterIds, handleGeneratePaper]);

  // Ensure paper is auto-generated whenever blueprint view is opened from TopBar or any navigation
  useEffect(() => {
    if (activeView === 'blueprint' && !generatedPaper && currentBank && selectedChapterIds.length > 0 && !isGenerating) {
      handleGeneratePaper('blueprint');
    }
  }, [activeView, generatedPaper, currentBank, selectedChapterIds, isGenerating, handleGeneratePaper]);

  // Handle loading newly generated Question Bank from AI Generator
  const handleLoadGeneratedBank = useCallback((bank: QuestionBank, entry: IndexEntry) => {
    registerCustomBank(bank, entry);
    const newGradeKey = extractGradeKey(entry.gradeKey || entry.grade);
    const newSubCode = deduceSubjectCode(entry.subjectCode || entry.subject);
    setAvailableFiles(prev => [
      entry,
      ...prev.filter(f => {
        if (f.id === entry.id) return false;
        const fGrade = extractGradeKey(f.gradeKey || f.grade);
        const fSub = deduceSubjectCode(f.subjectCode || f.subject);
        return !(fGrade === newGradeKey && fSub === newSubCode);
      }),
    ]);
    if (bank.metadata.grade) {
      setGrade(canonicalGradeLabel(extractGradeKey(bank.metadata.grade)));
    }
    setSemesterPart('all');
    setSelectedFileId(entry.id);
    setCurrentBank(bank);
    setSelectedChapterIds(bank.chapters.map(c => c.chapterId));
    setActiveView('setup');
  }, []);

  return (
    <div className="min-h-screen bg-[#f0f2f7] flex flex-col font-kannada antialiased text-slate-900">
      
      {/* Exact TopBar matching the screenshot */}
      <TopBar
        schoolName={schoolName}
        validityDate="2026-11-02"
        activeView={activeView}
        setActiveView={setActiveView}
        hasGeneratedPaper={Boolean(generatedPaper)}
        onOpenJsonGuide={() => setIsJsonGuideOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5">
        
        {/* Error Notification */}
        {generationError && (
          <div className="mb-5 p-4 bg-rose-50 border border-rose-300 rounded-2xl text-rose-900 shadow-xs flex items-start gap-3 no-print">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1 text-xs sm:text-sm">
              <strong className="font-bold block mb-1">ಪ್ರಶ್ನೆಗಳ ಕೊರತೆ (Notice):</strong>
              <div className="whitespace-pre-line text-rose-800 leading-relaxed">{generationError}</div>
            </div>
            <button
              onClick={() => setGenerationError(null)}
              className="text-rose-500 hover:text-rose-800 text-xs font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {loadError && (
          <div className="mb-5 p-4 bg-amber-50 border border-amber-300 rounded-2xl text-amber-900 shadow-xs flex items-start gap-3 no-print">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="flex-1 text-xs sm:text-sm font-semibold">{loadError}</div>
          </div>
        )}

        {/* VIEW 1: Generator Setup Dashboard (Exact 2-Column layout from screenshot) */}
        {activeView === 'setup' && (
          <div className="space-y-4">
            {/* Custom Sections Active Banner */}
            {customSections && customSections.length > 0 && (
              <div className="p-3 bg-linear-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs font-bold text-indigo-900 shadow-2xs">
                <div className="flex items-center gap-2">
                  <span className="text-base">⚙️</span>
                  <span>
                    ವಿಶೇಷ ವಿಭಾಗಗಳ ಹೊಂದಾಣಿಕೆ ಸಕ್ರಿಯವಾಗಿದೆ (Custom Sections Active):{' '}
                    <span className="text-indigo-700 font-extrabold">{customSections.length} ವಿಭಾಗಗಳು</span> •{' '}
                    <span className="text-indigo-700 font-extrabold">{targetQuestionsCount} ಪ್ರಶ್ನೆಗಳು</span> •{' '}
                    <span className="text-emerald-700 font-extrabold">{targetMarks} ಅಂಕಗಳು</span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsSectionConfigOpen(true)}
                    className="px-2.5 py-1 bg-white hover:bg-indigo-100 text-indigo-800 rounded-lg border border-indigo-200 transition-colors cursor-pointer"
                  >
                    ಬದಲಾಯಿಸಿ (Edit)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCustomSections(null);
                      setTargetMarks(40);
                      setTargetQuestionsCount(24);
                    }}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
                  >
                    ಪೂರ್ವನಿಯೋಜಿತಕ್ಕೆ ಮರುಹೊಂದಿಸಿ (Reset)
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: 1. ಪರೀಕ್ಷಾ ವಿವರಗಳು (Setup) */}
              <div className="lg:col-span-4">
                <SetupPanel
                  schoolName={schoolName}
                  setSchoolName={setSchoolName}
                  medium={medium}
                  setMedium={setMedium}
                  grade={grade}
                  setGrade={handleGradeChange}
                  selectedFileId={selectedFileId}
                  setSelectedFileId={handleSelectFile}
                  availableFiles={availableFiles}
                  semesterPart={semesterPart}
                  setSemesterPart={handleSemesterPartChange}
                  paperModel={paperModel}
                  setPaperModel={setPaperModel}
                  examType={examType}
                  setExamType={handleExamTypeChange}
                  targetMarks={targetMarks}
                  setTargetMarks={setTargetMarks}
                  targetQuestionsCount={targetQuestionsCount}
                  setTargetQuestionsCount={setTargetQuestionsCount}
                  examDateOrYear={examDateOrYear}
                  setExamDateOrYear={setExamDateOrYear}
                  onGenerate={handleGeneratePaper}
                  onFreshSet={handleGeneratePaper}
                  isGenerating={isGenerating}
                  onViewBlueprint={handleOpenBlueprint}
                  onOpenJsonGuide={() => setIsJsonGuideOpen(true)}
                  onOpenSectionConfig={() => setIsSectionConfigOpen(true)}
                  onOpenAiGenerator={() => setActiveView('ai_generator')}
                />
              </div>

              {/* Right Column: 2. ಪಾಠಗಳ ಆಯ್ಕೆ + 3. ಪ್ರಶ್ನೆ ಪ್ರಕಾರಗಳು */}
              <div className="lg:col-span-8 space-y-6">
                {/* Card 2: 2. ಪಾಠಗಳ ಆಯ್ಕೆ (Select Chapters) */}
                <ChapterSelectionPanel
                  chapters={visibleChapters}
                  selectedChapterIds={selectedChapterIds}
                  onChangeSelectedChapters={setSelectedChapterIds}
                />

                {/* Card 3: 3. ಪ್ರಶ್ನೆ ಪ್ರಕಾರಗಳು (Question Formats) */}
                <QuestionFormatsPanel
                  selectedFormatIds={selectedFormatIds}
                  onChangeSelectedFormats={setSelectedFormatIds}
                  formatQuestionCounts={formatCounts}
                  onOpenSectionConfig={() => setIsSectionConfigOpen(true)}
                  subject={currentBank?.metadata.subject}
                  subjectCode={currentBank?.metadata.subjectCode as string}
                />
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2: Generated Question Paper & Answer Key Preview */}
        {activeView === 'preview' && generatedPaper && currentBank && (
          <div className="space-y-6">
            
            {/* Top Toolbar for Preview */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs flex flex-wrap items-center justify-between gap-4 no-print font-kannada">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveView('setup')}
                  className="px-3.5 py-1.5 rounded-xl font-bold text-xs bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors flex items-center gap-1.5 shadow-2xs"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← ಸೆಟಪ್‌ಗೆ ಹಿಂತಿರುಗಿ (Back to Setup)</span>
                </button>

                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => setPreviewSubMode('paper')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      previewSubMode === 'paper' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ಮಾತ್ರ
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewSubMode('answers')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      previewSubMode === 'answers' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    ಉತ್ತರ ಪತ್ರಿಕೆ ಮಾತ್ರ
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewSubMode('both')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      previewSubMode === 'both' ? 'bg-white text-purple-700 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    ಎರಡೂ (Both)
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleRegenerate}
                  className="px-3.5 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>ಹೊಸ ಸಂಯೋಜನೆ (Regenerate)</span>
                </button>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" />
                  <span>ಮುದ್ರಣ / PDF</span>
                </button>
              </div>
            </div>

            {/* Paper Preview Render */}
            {(previewSubMode === 'paper' || previewSubMode === 'both') && (
              <div className="space-y-4">
                {previewSubMode === 'both' && (
                  <div className="font-bold text-sm text-slate-800 pb-2 border-b border-slate-300 no-print">
                    ೧. ವಿದ್ಯಾರ್ಥಿಗಳ ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ (Student Question Paper)
                  </div>
                )}
                <PaperPreview
                  paper={generatedPaper}
                  bank={currentBank}
                  onUpdatePaper={setGeneratedPaper}
                  onRegenerate={handleRegenerate}
                  onResetToGenerated={handleResetToGenerated}
                  onBackToSetup={() => setActiveView('setup')}
                />
              </div>
            )}

            {/* Answer Key Render */}
            {(previewSubMode === 'answers' || previewSubMode === 'both') && (
              <div className={`space-y-4 ${previewSubMode === 'both' ? 'mt-12 pt-8 border-t-2 border-slate-300' : ''}`}>
                {previewSubMode === 'both' && (
                  <div className="font-bold text-sm text-emerald-800 pb-2 border-b border-emerald-300 no-print">
                    ೨. ಅಧಿಕೃತ ಕೀಲಿ ಉತ್ತರ ಮತ್ತು ಮೌಲ್ಯಮಾಪನ ಸೂಚಿ (Official Answer Key)
                  </div>
                )}
                <AnswerKeyPreview paper={generatedPaper} />
              </div>
            )}

          </div>
        )}

        {/* VIEW 3: Question Bank Explorer */}
        {activeView === 'explorer' && currentBank && (
          <div className="space-y-4">
            <div className="no-print">
              <button
                type="button"
                onClick={() => setActiveView('setup')}
                className="px-3.5 py-1.5 rounded-xl font-bold text-xs bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 transition-colors flex items-center gap-1.5 shadow-2xs mb-4"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>← ಸೆಟಪ್‌ಗೆ ಹಿಂತಿರುಗಿ (Back to Setup)</span>
              </button>
            </div>
            <QuestionBankExplorer
              bank={currentBank}
              availableFiles={availableFiles}
              grade={grade}
              setGrade={handleGradeChange}
              medium={medium}
              setMedium={setMedium}
              selectedFileId={selectedFileId}
              onSelectFile={handleSelectFile}
            />
          </div>
        )}

        {/* VIEW 4: Official 5-Stage Blue Print View (Matching image_4dffbf52.png) */}
        {activeView === 'blueprint' && activeBlueprint && (
          <BluePrintView
            blueprint={activeBlueprint}
            bank={currentBank}
            paper={generatedPaper}
            onUpdatePaper={setGeneratedPaper}
            onBackToSetup={() => setActiveView('setup')}
            onViewPaper={generatedPaper ? () => setActiveView('preview') : undefined}
          />
        )}

        {/* VIEW 5: AI-Powered JSON Question Bank Generator (Preserve mounted state across windows) */}
        <div style={{ display: activeView === 'ai_generator' ? 'block' : 'none' }}>
          <AiJsonGenerator
            onBackToApp={() => setActiveView('setup')}
            onLoadGeneratedBank={handleLoadGeneratedBank}
          />
        </div>

      </main>

      {/* JSON File Model & Creation Guide Modal */}
      <JsonGuideModal
        isOpen={isJsonGuideOpen}
        onClose={() => setIsJsonGuideOpen(false)}
      />

      {/* Section Configurator Modal (vibhagavaru prashnegalannu hondisuva option) */}
      <SectionConfigModal
        isOpen={isSectionConfigOpen}
        onClose={() => setIsSectionConfigOpen(false)}
        sections={
          customSections ||
          (currentBank
            ? buildBlueprintsFromSelectedFormats(
                currentBank,
                selectedFormatIds,
                selectedChapterIds,
                targetMarks,
                targetQuestionsCount
              )
            : [])
        }
        targetMarks={targetMarks}
        targetQuestionsCount={targetQuestionsCount}
        onApplySections={(newSections, updatedMarks, updatedCount) => {
          setCustomSections(newSections);
          setTargetMarks(updatedMarks);
          setTargetQuestionsCount(updatedCount);
        }}
      />

      {/* Footer */}
      <footer className="no-print mt-10 py-5 border-t border-slate-200/80 bg-white/60 text-center text-xs text-slate-500 font-kannada">
        <p className="font-bold text-slate-700">
          ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ರಚನಾ ಸಾಧನ · QUESTION PAPER GENERATOR BY S R ANGADI
        </p>
        <p className="text-2xs text-slate-400 mt-1">
          GOVT KHPS NINGYANATTI · Karnataka DSERT LBA Official Question Banks (Class 6)
        </p>
      </footer>
    </div>
  );
}
