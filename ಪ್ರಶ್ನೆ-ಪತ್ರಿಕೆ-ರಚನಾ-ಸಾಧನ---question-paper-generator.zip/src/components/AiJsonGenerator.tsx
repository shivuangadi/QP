/**
 * AI-Powered JSON Question Bank Generator Component
 * Extracts Kannada text, questions, and answers from Karnataka DSERT LBA PDFs using Gemini multimodal OCR.
 * Author: S R Angadi / M I Nilaji
 */

import React, { useState } from 'react';
import {
  Upload,
  FileText,
  FileJson,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Download,
  Database,
  ArrowRight,
  RefreshCw,
  Search,
  Filter,
  Eye,
  Code,
  Check,
  ChevronDown,
  ChevronUp,
  Sliders,
  Layers,
  BookOpen,
  Cpu,
  Cloud,
  RotateCcw,
} from 'lucide-react';
import { QuestionBank, Chapter, QuestionItem, IndexEntry } from '../types/questionBank.ts';
import {
  saveQuestionBankToFirebase,
  saveUploadedPdfToFirebase,
  getUploadedPdfsFromFirebase,
  UploadedPdfRecord,
} from '../services/firebase.ts';
import {
  parsePageRangeString,
  slicePdfPages,
  getTocSlice,
} from '../utils/pdfHelper.ts';

interface AiJsonGeneratorProps {
  onBackToApp: () => void;
  onLoadGeneratedBank: (bank: QuestionBank, entry: IndexEntry) => void;
}

interface DetectedChapter {
  chapterNumber: number;
  chapterId: string;
  chapterName: string;
  sectionType?: string;
  semester?: number;
  printedPages?: string;
  questionPages: string;
  answerPages: string;
  status: 'pending' | 'processing' | 'done' | 'error';
  extractedCount?: number;
  errorMessage?: string;
}

interface DetectedDoc {
  metadata: {
    title: string;
    grade: string;
    gradeKey: string;
    subject: string;
    subjectCode: string;
    medium: string;
    academicYear: string;
    department: string;
    institution: string;
    prelimOffset?: number;
    globalAnswerPages?: string;
  };
  learningOutcomes: Array<{ code: string; title: string }>;
  chapters: DetectedChapter[];
}

export const AiJsonGenerator: React.FC<AiJsonGeneratorProps> = ({
  onBackToApp,
  onLoadGeneratedBank,
}) => {
  // Wizard steps: 1: upload & scan, 2: chapters & process, 3: verify & download
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // File state
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileBuffer, setFileBuffer] = useState<ArrayBuffer | null>(null);
  const [totalPages, setTotalPages] = useState<number>(0);
  const [scanPageRange, setScanPageRange] = useState<string>('1-12');
  const [fileName, setFileName] = useState<string>('');
  const [fileSizeMB, setFileSizeMB] = useState<string>('0');

  // Scanning & Extraction state
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanError, setScanError] = useState<string | null>(null);
  const [detectedDoc, setDetectedDoc] = useState<DetectedDoc | null>(null);

  // Physical PDF Page Offset & Global Answer Key
  const [pageOffset, setPageOffset] = useState<number>(0);
  const [globalAnswerKeyRange, setGlobalAnswerKeyRange] = useState<string>('');

  // Chapter Execution Mode: 'single' (recommended chapter-by-chapter) or 'batch' (table view)
  const [activeChapterMode, setActiveChapterMode] = useState<'single' | 'batch'>('single');
  const [selectedSingleChapterId, setSelectedSingleChapterId] = useState<string>('');

  // Chapter processing state
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [extractionLog, setExtractionLog] = useState<string[]>([]);
  const [currentProcessingChapter, setCurrentProcessingChapter] = useState<string>('');

  // Final Generated Bank
  const [generatedBank, setGeneratedBank] = useState<QuestionBank | null>(null);
  const [rawJsonString, setRawJsonString] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'preview' | 'json' | 'stats'>('preview');

  // Preview filtering
  const [previewChapterFilter, setPreviewChapterFilter] = useState<string>('all');
  const [previewFormatFilter, setPreviewFormatFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedQuestionId, setExpandedQuestionId] = useState<string | null>(null);

  // Saving state
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  // Extracted Chapters Cache (preserves chapters already completed)
  const [extractedChaptersCache, setExtractedChaptersCache] = useState<Record<string, Chapter>>({});

  // Reset confirmation modal state
  const [showResetConfirmModal, setShowResetConfirmModal] = useState<boolean>(false);

  // Saved PDFs in Database (Firestore)
  const [savedPdfs, setSavedPdfs] = useState<UploadedPdfRecord[]>([]);

  // Load Saved PDFs on mount
  React.useEffect(() => {
    getUploadedPdfsFromFirebase()
      .then(list => setSavedPdfs(list))
      .catch(err => console.warn('Could not fetch saved PDFs:', err));

    // Restore draft and extracted chapters if available
    try {
      const savedDraft = localStorage.getItem('ai_json_gen_draft');
      if (savedDraft) {
        const parsed = JSON.parse(savedDraft);
        if (parsed.detectedDoc) {
          setDetectedDoc(parsed.detectedDoc);
          if (parsed.step) setStep(parsed.step);
          if (parsed.fileName) setFileName(parsed.fileName);
          if (parsed.totalPages) setTotalPages(parsed.totalPages);
          if (parsed.fileSizeMB) setFileSizeMB(parsed.fileSizeMB);
          if (parsed.pageOffset) setPageOffset(parsed.pageOffset);
          if (parsed.globalAnswerKeyRange) setGlobalAnswerKeyRange(parsed.globalAnswerKeyRange);
        }
      }

      const savedCache = localStorage.getItem('ai_json_gen_extracted_cache');
      if (savedCache) {
        const parsedCache = JSON.parse(savedCache);
        if (parsedCache && typeof parsedCache === 'object' && Object.keys(parsedCache).length > 0) {
          setExtractedChaptersCache(parsedCache);
        }
      }

      const savedBank = localStorage.getItem('ai_json_gen_bank');
      if (savedBank) {
        const parsedBank = JSON.parse(savedBank);
        if (parsedBank && parsedBank.metadata && parsedBank.chapters) {
          setGeneratedBank(parsedBank);
          setRawJsonString(JSON.stringify(parsedBank, null, 2));
        }
      }
    } catch (e) {
      // ignore
    }
  }, []);

  // Persist draft to localStorage on changes
  React.useEffect(() => {
    if (detectedDoc) {
      try {
        localStorage.setItem(
          'ai_json_gen_draft',
          JSON.stringify({
            step,
            detectedDoc,
            fileName,
            totalPages,
            fileSizeMB,
            pageOffset,
            globalAnswerKeyRange,
          })
        );
      } catch (e) {
        // ignore quota
      }
    }
  }, [step, detectedDoc, fileName, totalPages, fileSizeMB, pageOffset, globalAnswerKeyRange]);

  // Persist extracted chapters cache whenever chapters are added or updated
  React.useEffect(() => {
    if (extractedChaptersCache && Object.keys(extractedChaptersCache).length > 0) {
      try {
        localStorage.setItem(
          'ai_json_gen_extracted_cache',
          JSON.stringify(extractedChaptersCache)
        );
      } catch (e) {
        // ignore quota
      }
    }
  }, [extractedChaptersCache]);

  // Persist generatedBank whenever ready
  React.useEffect(() => {
    if (generatedBank) {
      try {
        localStorage.setItem('ai_json_gen_bank', JSON.stringify(generatedBank));
      } catch (e) {
        // ignore quota
      }
    }
  }, [generatedBank]);

  // 1. Handle PDF Selection
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') {
      alert('ದಯವಿಟ್ಟು ಕೇವಲ PDF ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ (Please upload a valid PDF file).');
      return;
    }

    setSelectedFile(file);
    setFileName(file.name);
    setFileSizeMB((file.size / (1024 * 1024)).toFixed(2));
    setScanError(null);

    try {
      const buffer = await file.arrayBuffer();
      setFileBuffer(buffer);

      // Fast inspection using pdf-lib
      const { PDFDocument } = await import('pdf-lib');
      const doc = await PDFDocument.load(buffer, { ignoreEncryption: true });
      const pages = doc.getPageCount();
      setTotalPages(pages);
      setScanPageRange(`1-${Math.min(12, pages)}`);
    } catch (err: any) {
      console.warn('Could not inspect PDF page count:', err);
      setTotalPages(0);
    }
  };

  // Direct JSON Bank File Loader (with Question Deduplication)
  const handleDirectJsonUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = reader.result as string;
        const parsed = JSON.parse(text);
        if (!parsed.metadata || !parsed.chapters) {
          alert('ಅಮಾನ್ಯ ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ JSON (metadata ಅಥವಾ chapters ರಚನೆ ಲಭ್ಯವಿಲ್ಲ).');
          return;
        }

        // Deduplicate questions in each chapter to eliminate duplicate questions
        if (Array.isArray(parsed.chapters)) {
          parsed.chapters.forEach((ch: any) => {
            if (Array.isArray(ch.questions)) {
              const seenText = new Set<string>();
              ch.questions = ch.questions.filter((q: any) => {
                const normText = String(q.question || q.questionText || q.text || '').trim().toLowerCase();
                if (!normText || seenText.has(normText)) return false;
                seenText.add(normText);
                return true;
              });
            }
          });
        }

        // Populate extracted chapters cache
        const newCache: Record<string, Chapter> = {};
        parsed.chapters.forEach((ch: Chapter) => {
          newCache[ch.chapterId] = ch;
        });
        setExtractedChaptersCache(newCache);

        // Populate detectedDoc so all views have metadata
        setDetectedDoc({
          metadata: {
            title: parsed.metadata.title || file.name.replace('.json', ''),
            grade: parsed.metadata.grade || '7 ನೇ ತರಗತಿ (Class 7)',
            gradeKey: String(parsed.metadata.gradeKey || '7'),
            subject: parsed.metadata.subject || 'ವಿಷಯ',
            subjectCode: String(parsed.metadata.subjectCode || 'GEN'),
            medium: parsed.metadata.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
            academicYear: String(parsed.metadata.academicYear || '2026-27'),
            department: parsed.metadata.department || 'ಕರ್ನಾಟಕ ಸರ್ಕಾರ, ಶಾಲಾ ಶಿಕ್ಷಣ ಮತ್ತು ಸಾಕ್ಷರತಾ ಇಲಾಖೆ',
            institution: parsed.metadata.institution || 'DSERT ಬೆಂಗಳೂರು',
          },
          learningOutcomes: [],
          chapters: parsed.chapters.map((ch: Chapter, idx: number) => ({
            chapterNumber: ch.chapterNumber || idx + 1,
            chapterId: ch.chapterId || `ch-${idx + 1}`,
            chapterName: ch.chapterName,
            semester: ch.semester || 1,
            questionPages: '',
            answerPages: '',
            status: 'done' as const,
            extractedCount: ch.questions?.length || 0,
          })),
        });

        setFileName(file.name);
        setGeneratedBank(parsed);
        setRawJsonString(JSON.stringify(parsed, null, 2));
        setStep(3);
        setSaveSuccessMessage(`"${file.name}" ಪ್ರಶ್ನೆಕೋಶ ಯಶಸ್ವಿಯಾಗಿ ಅಪ್‌ಲೋಡ್ ಆಗಿದೆ! (${parsed.chapters.length} ಅಧ್ಯಾಯಗಳು)`);
        setTimeout(() => setSaveSuccessMessage(null), 5000);
      } catch (err: any) {
        alert('JSON ಫೈಲ್ ಓದುವಲ್ಲಿ ದೋಷ: ' + (err.message || 'ದೋಷ ಕಂಡುಬಂದಿದೆ'));
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Upload Another PDF / Reset and Start Again
  const handleResetAndStartNewPdf = () => {
    const hasProgress = Boolean(detectedDoc || generatedBank || Object.keys(extractedChaptersCache).length > 0 || selectedFile);
    if (hasProgress) {
      setShowResetConfirmModal(true);
      return;
    }
    executeResetAndStartNewPdf();
  };

  const executeResetAndStartNewPdf = () => {
    setShowResetConfirmModal(false);
    setSelectedFile(null);
    setFileBuffer(null);
    setDetectedDoc(null);
    setExtractedChaptersCache({});
    setGeneratedBank(null);
    setRawJsonString('');
    setFileName('');
    setTotalPages(0);
    setFileSizeMB('0');
    setScanError(null);
    setExtractionLog([]);
    setStep(1);
    try {
      localStorage.removeItem('ai_json_gen_draft');
      localStorage.removeItem('ai_json_gen_extracted_cache');
      localStorage.removeItem('ai_json_gen_bank');
    } catch (e) {
      // ignore
    }
  };

  // Re-attach PDF buffer if page was refreshed in Step 2 or Step 3
  const handleReattachPdf = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const buffer = await file.arrayBuffer();
      setSelectedFile(file);
      setFileBuffer(buffer);
      setFileName(file.name);
      setFileSizeMB((file.size / (1024 * 1024)).toFixed(2));
      const { PDFDocument } = await import('pdf-lib');
      const doc = await PDFDocument.load(buffer, { ignoreEncryption: true });
      const pages = doc.getPageCount();
      setTotalPages(pages);
      setSaveSuccessMessage('✅ PDF ಫೈಲ್ ಯಶಸ್ವಿಯಾಗಿ ಮೆಮೊರಿಗೆ ಮರು-ಜೋಡಣೆಯಾಗಿದೆ! ಈಗ 4 ನೇ ಅಥವಾ ಯಾವುದೇ ಅಧ್ಯಾಯದ ಪ್ರಶ್ನೆಗಳನ್ನು ಹೊರತೆಗೆಯಬಹುದು.');
      setTimeout(() => setSaveSuccessMessage(null), 6000);
    } catch (err: any) {
      setScanError('PDF ಲೋಡ್ ಮಾಡುವಲ್ಲಿ ದೋಷ: ' + err.message);
    }
    e.target.value = '';
  };

  // 2. Scan PDF Structure with Gemini (Lightweight TOC Slice)
  const handleScanPdf = async () => {
    if (!selectedFile && !fileBuffer) {
      alert('ದಯವಿಟ್ಟು ಮೊದಲು PDF ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ.');
      return;
    }

    setIsScanning(true);
    setScanError(null);

    try {
      let buffer = fileBuffer;
      if (!buffer && selectedFile) {
        buffer = await selectedFile.arrayBuffer();
        setFileBuffer(buffer);
      }

      if (!buffer) {
        throw new Error('PDF ಡೇಟಾ ಲೋಡ್ ಮಾಡಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.');
      }

      // Generate lightweight slice of Table of Contents / Syllabus (under 500KB)
      let sliceBase64 = '';
      if (totalPages > 0) {
        const pageIndices = parsePageRangeString(scanPageRange, totalPages);
        if (pageIndices.length > 0) {
          const sliceRes = await slicePdfPages(buffer, pageIndices);
          sliceBase64 = sliceRes.base64;
        } else {
          const toc = await getTocSlice(buffer, 12);
          sliceBase64 = toc.base64;
        }
      } else {
        const toc = await getTocSlice(buffer, 12);
        sliceBase64 = toc.base64;
      }

      const response = await fetch('/api/ai/scan-lba-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base64Pdf: sliceBase64, fileName }),
      });

      if (!response.ok) {
        let errText = '';
        try {
          const errJson = await response.json();
          errText = errJson.error;
        } catch {
          errText = `HTTP Error ${response.status}: ${response.statusText}`;
        }
        throw new Error(errText || 'PDF ಸ್ಕ್ಯಾನ್ ಮಾಡುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ.');
      }

      const resData = await response.json();
      if (!resData.success) {
        throw new Error(resData.error || 'PDF ಸ್ಕ್ಯಾನ್ ಮಾಡುವಲ್ಲಿ ವಿಫಲವಾಗಿದೆ.');
      }

      const scanned = resData.data;
      const detectedOffset = typeof scanned.metadata?.prelimOffset === 'number' ? scanned.metadata.prelimOffset : 0;
      const detectedAnswerKey = scanned.metadata?.globalAnswerPages || '';
      setPageOffset(detectedOffset);
      setGlobalAnswerKeyRange(detectedAnswerKey);

      const chs: DetectedChapter[] = (scanned.chapters || []).map((c: any, idx: number) => ({
        chapterNumber: c.chapterNumber || idx + 1,
        chapterId: c.chapterId || `ch-${idx + 1}`,
        chapterName: c.chapterName || `ಅಧ್ಯಾಯ ${idx + 1}`,
        sectionType: c.sectionType || 'ಸಾಮಾನ್ಯ',
        semester: c.semester || (idx + 1 > 5 ? 2 : 1),
        printedPages: c.printedPages || c.questionPages || '',
        questionPages: c.questionPages || '',
        answerPages: c.answerPages || '',
        status: 'pending',
      }));

      if (chs.length > 0) {
        setSelectedSingleChapterId(chs[0].chapterId);
      }

      const doc: DetectedDoc = {
        metadata: {
          title: scanned.metadata?.title || 'ಕಲಿಕಾಫಲ ಆಧಾರಿತ ಮೌಲ್ಯಾಂಕನ ಪ್ರಶ್ನೋತ್ತರ ಬ್ಯಾಂಕ್',
          grade: scanned.metadata?.grade || '6ನೇ ತರಗತಿ (Class 6)',
          gradeKey: scanned.metadata?.gradeKey || '6',
          subject: scanned.metadata?.subject || 'ವಿಷಯ',
          subjectCode: scanned.metadata?.subjectCode || 'GEN',
          medium: scanned.metadata?.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
          academicYear: scanned.metadata?.academicYear || '2026-27',
          department: scanned.metadata?.department || 'ಕರ್ನಾಟಕ ಸರ್ಕಾರ, ಶಾಲಾ ಶಿಕ್ಷಣ ಮತ್ತು ಸಾಕ್ಷರತಾ ಇಲಾಖೆ',
          institution: scanned.metadata?.institution || 'DSERT ಬೆಂಗಳೂರು',
          prelimOffset: detectedOffset,
          globalAnswerPages: detectedAnswerKey,
        },
        learningOutcomes: scanned.learningOutcomes || [],
        chapters: chs,
      };

      setDetectedDoc(doc);
      setStep(2);

      // Save uploaded PDF record to Firebase Firestore for later re-selection
      saveUploadedPdfToFirebase({
        id: `pdf_${Date.now()}`,
        fileName: fileName || 'uploaded_lba.pdf',
        fileSizeMB: fileSizeMB,
        totalPages: totalPages,
        grade: doc.metadata.grade,
        subject: doc.metadata.subject,
        detectedDoc: doc,
        uploadedAt: new Date().toISOString(),
      })
        .then(() => getUploadedPdfsFromFirebase().then(list => setSavedPdfs(list)))
        .catch(e => console.warn('Could not save PDF record to Firestore:', e));
    } catch (err: any) {
      console.error('Scan error:', err);
      const isFetchErr = err.name === 'TypeError' || String(err).includes('Failed to fetch');
      const msg = isFetchErr
        ? 'ಸರ್ವರ್ ಸಂಪರ್ಕ ವಿಫಲವಾಗಿದೆ (Connection/Fetch Failed). ದಯವಿಟ್ಟು ಸ್ಕ್ಯಾನ್ ಪುಟ ವ್ಯಾಪ್ತಿಯನ್ನು (ಉದಾ. 1-6) ಚಿಕ್ಕದಾಗಿಸಿ ಪುನಃ ಪ್ರಯತ್ನಿಸಿ.'
        : err.message || 'PDF ವಿಶ್ಲೇಷಣೆಯಲ್ಲಿ ದೋಷ ಸಂಭವಿಸಿದೆ.';
      setScanError(msg);
    } finally {
      setIsScanning(false);
    }
  };

  // Update chapter page numbers manually
  const handleUpdateChapterPages = (
    chapterId: string,
    field: 'questionPages' | 'answerPages',
    val: string
  ) => {
    if (!detectedDoc) return;
    const chapters = detectedDoc.chapters.map(c =>
      c.chapterId === chapterId ? { ...c, [field]: val } : c
    );
    setDetectedDoc({ ...detectedDoc, chapters });
  };

  // Shift printed pages by offset to convert to physical PDF page numbers
  const handleApplyOffsetToAll = (offsetToAdd: number) => {
    if (!detectedDoc) return;
    const shiftRangeStr = (rangeStr: string, shift: number) => {
      if (!rangeStr || !rangeStr.trim()) return '';
      return rangeStr.replace(/\b(\d+)\b/g, m => {
        const n = parseInt(m, 10);
        return String(Math.max(1, n + shift));
      });
    };

    const chapters = detectedDoc.chapters.map(c => {
      const base = c.printedPages || c.questionPages;
      return {
        ...c,
        questionPages: shiftRangeStr(base, offsetToAdd),
      };
    });
    setDetectedDoc({ ...detectedDoc, chapters });
  };

  // Helper to extract a single chapter with retry
  const extractSingleChapterCore = async (
    ch: DetectedChapter,
    buffer: ArrayBuffer
  ): Promise<Chapter> => {
    let chapterSliceBase64 = '';
    const effectiveAnswerPages = ch.answerPages?.trim() || globalAnswerKeyRange.trim();

    if (totalPages > 0) {
      try {
        const combinedRanges = `${ch.questionPages || ''}, ${effectiveAnswerPages}`.trim();
        const pageIndices = parsePageRangeString(combinedRanges, totalPages);
        if (pageIndices.length > 0) {
          const slice = await slicePdfPages(buffer, pageIndices);
          chapterSliceBase64 = slice.base64;
        }
      } catch (sliceErr) {
        console.warn('Could not slice chapter pages:', sliceErr);
      }
    }

    // Fallback slice if no specific pages
    if (!chapterSliceBase64) {
      const fallbackIndices = Array.from(
        { length: Math.min(8, totalPages || 8) },
        (_, idx) => Math.min(ch.chapterNumber * 5 + idx, Math.max(0, (totalPages || 10) - 1))
      );
      const slice = await slicePdfPages(buffer, fallbackIndices);
      chapterSliceBase64 = slice.base64;
    }

    const payload = JSON.stringify({
      base64Pdf: chapterSliceBase64,
      chapterName: ch.chapterName,
      chapterNumber: ch.chapterNumber,
      questionPages: ch.questionPages,
      answerPages: effectiveAnswerPages,
      metadata: detectedDoc?.metadata,
    });

    let lastError: any = null;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const response = await fetch('/api/ai/extract-chapter', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: payload,
        });

        if (!response.ok) {
          let errText = '';
          try {
            const errJson = await response.json();
            errText = errJson.error;
          } catch {
            errText = `HTTP Error ${response.status}: ${response.statusText}`;
          }
          throw new Error(errText || 'ಅಧ್ಯಾಯದ ಪ್ರಶ್ನೆಗಳನ್ನು ಹೊರತೆಗೆಯಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.');
        }

        const resData = await response.json();
        if (!resData.success) {
          throw new Error(resData.error || 'ಅಧ್ಯಾಯದ ಪ್ರಶ್ನೆಗಳನ್ನು ಹೊರತೆಗೆಯಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.');
        }

        const chData = resData.data;
        const rawQList: QuestionItem[] = [];
        (chData.questions || []).forEach((q: any, qIdx: number) => {
          const rawItems = Array.isArray(q.items) ? q.items : undefined;
          const isMatch = q.formatCategoryId === 'match' || q.type === 'match' || (rawItems && rawItems.length >= 2);
          
          if (isMatch) {
            const itmCount = rawItems ? rawItems.length : (q.marks || 4);
            rawQList.push({
              id: q.id || `q-${ch.chapterNumber}-${qIdx + 1}`,
              question: q.question || 'ಹೊಂದಿಸಿ ಬರೆಯಿರಿ :',
              answer: q.answer || '',
              questionType: q.questionType || 'ಹೊಂದಿಸಿ ಬರೆಯಿರಿ',
              formatCategoryId: 'match',
              formatCategoryName: `೫. ಹೊಂದಿಸಿ ಬರೆಯಿರಿ (${itmCount}M)`,
              marks: Math.max(3, itmCount),
              difficulty: q.difficulty || 'ಸಾಧಾರಣ',
              objective: q.objective || 'ಜ್ಞಾನ',
              objectiveName: q.objective || 'ಜ್ಞಾನ',
              learningOutcome: q.learning_outcome || q.learningOutcome || `LO ${ch.chapterNumber}`,
              options: undefined,
              items: rawItems,
              chapterId: ch.chapterId,
              chapterName: ch.chapterName,
              chapterNumber: ch.chapterNumber,
            });
            return;
          }

          // Check if it's a bundled question with multiple numbered sub-questions
          const qText = String(q.question || '').trim();
          const ansText = String(q.answer || '').trim();
          const numRegex = /(?:^|\n)\s*(\d{1,2})[\.\)]\s*/g;
          const qMatches = [...qText.matchAll(numRegex)];

          if (qMatches.length >= 3 && !q.options?.length) {
            const pattern = /(?:^|\n)\s*(\d{1,2})[\.\)]\s*/;
            const qParts = qText.split(pattern);
            const mainHeader = qParts[0].trim();
            const aParts = ansText.split(pattern);
            const aMap: Record<string, string> = {};
            for (let i = 1; i < aParts.length; i += 2) {
              aMap[aParts[i]] = (aParts[i + 1] || '').trim();
            }

            for (let i = 1; i < qParts.length; i += 2) {
              const subNum = qParts[i];
              const subBody = (qParts[i + 1] || '').trim();
              if (!subBody) continue;
              rawQList.push({
                id: `${q.id || `q-${ch.chapterNumber}-${qIdx + 1}`}_sub${subNum}`,
                question: subBody,
                answer: aMap[subNum] || ansText || 'ಉತ್ತರ ಲಭ್ಯವಿಲ್ಲ',
                questionType: mainHeader || 'ಒಂದು ವಾಕ್ಯದಲ್ಲಿ ಉತ್ತರಿಸಿ',
                formatCategoryId: 'one_sentence',
                formatCategoryName: '೧. ಒಂದು ವಾಕ್ಯದ ಪ್ರಶ್ನೆ (1M)',
                marks: 1,
                difficulty: q.difficulty || 'ಸುಲಭ',
                objective: q.objective || 'ಜ್ಞಾನ',
                objectiveName: q.objective || 'ಜ್ಞಾನ',
                learningOutcome: q.learning_outcome || q.learningOutcome || `LO ${ch.chapterNumber}`,
                options: undefined,
                items: undefined,
                chapterId: ch.chapterId,
                chapterName: ch.chapterName,
                chapterNumber: ch.chapterNumber,
              });
            }
            return;
          }

          // Single question
          rawQList.push({
            id: q.id || `q-${ch.chapterNumber}-${qIdx + 1}`,
            question: q.question || '',
            answer: q.answer || 'ಉತ್ತರ ಲಭ್ಯವಿಲ್ಲ',
            questionType: q.questionType || q.type || 'ಸಾಮಾನ್ಯ ಪ್ರಶ್ನೆ',
            formatCategoryId: q.formatCategoryId || 'one_sentence',
            formatCategoryName: q.formatCategoryName || '೧. ಒಂದು ವಾಕ್ಯದ ಪ್ರಶ್ನೆ (1M)',
            marks: q.marks || 1,
            difficulty: q.difficulty || 'ಸಾಧಾರಣ',
            objective: q.objective || (qIdx % 4 === 0 ? 'know' : qIdx % 4 === 1 ? 'und' : qIdx % 4 === 2 ? 'app' : 'skill'),
            objectiveName: q.objective || (qIdx % 4 === 0 ? 'ಜ್ಞಾನ' : qIdx % 4 === 1 ? 'ತಿಳುವಳಿಕೆ' : qIdx % 4 === 2 ? 'ಅನ್ವಯ' : 'ಕೌಶಲ'),
            learningOutcome: q.learning_outcome || q.learningOutcome || `LO ${ch.chapterNumber}`,
            options: q.options || undefined,
            items: q.items || undefined,
            chapterId: ch.chapterId,
            chapterName: ch.chapterName,
            chapterNumber: ch.chapterNumber,
          });
        });

        // Deduplicate questions by question text to prevent duplicates
        const seenTexts = new Set<string>();
        const qList: QuestionItem[] = [];
        for (const item of rawQList) {
          const norm = item.question.replace(/\s+/g, ' ').trim().toLowerCase();
          if (norm && !seenTexts.has(norm)) {
            seenTexts.add(norm);
            qList.push(item);
          }
        }

        return {
          chapterId: ch.chapterId,
          chapterNumber: ch.chapterNumber,
          chapterName: ch.chapterName,
          semester: (ch.semester as 1 | 2) || (ch.chapterNumber > 5 ? 2 : 1),
          questions: qList,
        };
      } catch (err: any) {
        lastError = err;
        const isFetchErr = err.name === 'TypeError' || String(err).includes('Failed to fetch');
        if (isFetchErr && attempt === 1) {
          console.log(`Fetch error on chapter ${ch.chapterNumber}, waiting 2s before retry...`);
          await new Promise(r => setTimeout(r, 2000));
          continue;
        }
        break;
      }
    }

    throw lastError || new Error('ಅಧ್ಯಾಯ ಹೊರತೆಗೆಯಲು ವಿಫಲವಾಗಿದೆ.');
  };

  // Extract or Retry a single chapter
  const handleExtractSingleChapter = async (targetCh: DetectedChapter) => {
    if (!detectedDoc) return;

    let buffer = fileBuffer;
    if (!buffer && selectedFile) {
      buffer = await selectedFile.arrayBuffer();
      setFileBuffer(buffer);
    }
    if (!buffer) {
      alert(
        '⚠️ PDF ಫೈಲ್ ಮೆಮೊರಿಯಿಂದ ತೆರವುಗೊಂಡಿದೆ (ಪುಟ ರೀಲೋಡ್ ಆದ ಕಾರಣ).\nದಯವಿಟ್ಟು ಮೇಲೆ ಕಾಣುವ "ಅದೇ PDF ಫೈಲ್ ಮರು-ಆಯ್ಕೆಮಾಡಿ" ಬಟನ್ ಮೂಲಕ ನಿಮ್ಮ PDF ಅನ್ನು ಆಯ್ಕೆ ಮಾಡಿ.'
      );
      return;
    }

    const chapters = detectedDoc.chapters.map(c =>
      c.chapterId === targetCh.chapterId ? { ...c, status: 'processing' as const, errorMessage: undefined } : c
    );
    setDetectedDoc({ ...detectedDoc, chapters });
    setCurrentProcessingChapter(`ಅಧ್ಯಾಯ ${targetCh.chapterNumber}: ${targetCh.chapterName}`);

    setExtractionLog(prev => [
      ...prev,
      `⏳ ಅಧ್ಯಾಯ ${targetCh.chapterNumber}: "${targetCh.chapterName}" ನ ಪ್ರಶ್ನೋತ್ತರ ಹೊರತೆಗೆಯಲಾಗುತ್ತಿದೆ...`,
    ]);

    try {
      const extractedCh = await extractSingleChapterCore(targetCh, buffer);
      setExtractedChaptersCache(prev => ({ ...prev, [targetCh.chapterId]: extractedCh }));

      const updatedChs = detectedDoc.chapters.map(c =>
        c.chapterId === targetCh.chapterId
          ? { ...c, status: 'done' as const, extractedCount: extractedCh.questions.length }
          : c
      );
      setDetectedDoc({ ...detectedDoc, chapters: updatedChs });

      setExtractionLog(prev => [
        ...prev,
        `✅ ಅಧ್ಯಾಯ ${targetCh.chapterNumber} ಪೂರ್ಣಗೊಂಡಿದೆ: ${extractedCh.questions.length} ಪ್ರಶ್ನೆಗಳು ಸೇರ್ಪಡೆಯಾಗಿವೆ.`,
      ]);
    } catch (err: any) {
      console.error(`Error in chapter ${targetCh.chapterNumber}:`, err);
      const updatedChs = detectedDoc.chapters.map(c =>
        c.chapterId === targetCh.chapterId
          ? { ...c, status: 'error' as const, errorMessage: err.message || 'ದೋಷ ಕಂಡುಬಂದಿದೆ' }
          : c
      );
      setDetectedDoc({ ...detectedDoc, chapters: updatedChs });
      setExtractionLog(prev => [
        ...prev,
        `❌ ಅಧ್ಯಾಯ ${targetCh.chapterNumber} ದೋಷ: ${err.message || 'ದೋಷ ಸಂಭವಿಸಿದೆ'}`,
      ]);
    } finally {
      setCurrentProcessingChapter('');
    }
  };

  // 3. Process All (or remaining) Chapters Step-by-Step with Safe Delays
  const handleStartExtraction = async (onlyFailed = false) => {
    if (!detectedDoc) return;

    let buffer = fileBuffer;
    if (!buffer && selectedFile) {
      buffer = await selectedFile.arrayBuffer();
      setFileBuffer(buffer);
    }
    if (!buffer) {
      alert(
        '⚠️ PDF ಫೈಲ್ ಮೆಮೊರಿಯಿಂದ ತೆರವುಗೊಂಡಿದೆ (ಪುಟ ರೀಲೋಡ್ ಆದ ಕಾರಣ).\nದಯವಿಟ್ಟು ಮೇಲೆ ಕಾಣುವ "ಅದೇ PDF ಫೈಲ್ ಮರು-ಆಯ್ಕೆಮಾಡಿ" ಬಟನ್ ಮೂಲಕ ನಿಮ್ಮ PDF ಅನ್ನು ಆಯ್ಕೆ ಮಾಡಿ.'
      );
      return;
    }

    setIsExtracting(true);
    setExtractionLog([]);

    const chapters = [...detectedDoc.chapters];
    const newCache = { ...extractedChaptersCache };

    for (let i = 0; i < chapters.length; i++) {
      const ch = chapters[i];

      // If only retrying failed, skip non-failed
      if (onlyFailed && ch.status !== 'error') {
        continue;
      }

      // If already done, preserve and skip
      if (!onlyFailed && ch.status === 'done' && newCache[ch.chapterId]) {
        continue;
      }

      setCurrentProcessingChapter(`ಅಧ್ಯಾಯ ${ch.chapterNumber}: ${ch.chapterName}`);
      ch.status = 'processing';
      setDetectedDoc({ ...detectedDoc, chapters: [...chapters] });

      setExtractionLog(prev => [
        ...prev,
        `⏳ ಅಧ್ಯಾಯ ${ch.chapterNumber}: "${ch.chapterName}" (ಪುಟಗಳು: ${ch.questionPages || 'ಸ್ವಯಂ'})`,
      ]);

      try {
        const extractedCh = await extractSingleChapterCore(ch, buffer);
        newCache[ch.chapterId] = extractedCh;
        setExtractedChaptersCache({ ...newCache });

        ch.status = 'done';
        ch.extractedCount = extractedCh.questions.length;
        ch.errorMessage = undefined;

        setExtractionLog(prev => [
          ...prev,
          `✅ ಅಧ್ಯಾಯ ${ch.chapterNumber} ಪೂರ್ಣಗೊಂಡಿದೆ: ${extractedCh.questions.length} ಪ್ರಶ್ನೆಗಳು ಮತ್ತು ಅಧಿಕೃತ ಉತ್ತರಗಳು ಹೊಂದಿಕೆಯಾಗಿವೆ.`,
        ]);
      } catch (err: any) {
        console.error(`Error in chapter ${ch.chapterNumber}:`, err);
        ch.status = 'error';
        ch.errorMessage = err.message || 'ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ ದೋಷ';
        setExtractionLog(prev => [
          ...prev,
          `❌ ಅಧ್ಯಾಯ ${ch.chapterNumber} ದೋಷ: ${err.message || 'ದೋಷ ಸಂಭವಿಸಿದೆ'}`,
        ]);
      }

      setDetectedDoc({ ...detectedDoc, chapters: [...chapters] });

      // Polite pause between chapters to prevent rate-limit bursts
      await new Promise(r => setTimeout(r, 1200));
    }

    setIsExtracting(false);
    setCurrentProcessingChapter('');

    // Check if at least some chapters succeeded
    const completedList = Object.values(newCache);
    if (completedList.length > 0) {
      assembleFinalBank(completedList);
    }
  };

  // Assemble complete QuestionBank JSON
  const assembleFinalBank = (chapterList: Chapter[]) => {
    if (!detectedDoc) return;

    const totalQuestionsCount = chapterList.reduce((sum, c) => sum + (c.questions?.length || 0), 0);
    const totalChapters = chapterList.length;
    const allSameSemester =
      totalChapters > 1 && chapterList.every(c => c.semester === chapterList[0]?.semester);

    const sortedChapters = chapterList
      .sort((a, b) => (a.chapterNumber ?? 0) - (b.chapterNumber ?? 0))
      .map((ch, idx) => {
        let sem: 1 | 2 = ch.semester as 1 | 2;
        if (allSameSemester || !sem) {
          const chNum = ch.chapterNumber ?? idx + 1;
          sem = chNum <= Math.ceil(totalChapters / 2) ? 1 : 2;
        }
        return {
          ...ch,
          semester: sem,
        };
      });

    const finalBank: QuestionBank = {
      metadata: {
        title: detectedDoc.metadata.title,
        grade: detectedDoc.metadata.grade,
        gradeKey: detectedDoc.metadata.gradeKey,
        subject: detectedDoc.metadata.subject,
        subjectCode: detectedDoc.metadata.subjectCode,
        medium: detectedDoc.metadata.medium,
        academicYear: detectedDoc.metadata.academicYear,
        department: detectedDoc.metadata.department,
        institution: detectedDoc.metadata.institution,
        totalChapters: sortedChapters.length,
        totalQuestions: totalQuestionsCount,
        verified: true,
        no_ai_generated_questions: true,
        source_pdf: fileName,
      },
      chapters: sortedChapters,
    };

    setGeneratedBank(finalBank);
    setRawJsonString(JSON.stringify(finalBank, null, 2));
  };

  // Move directly to review step with completed chapters
  const handleProceedToReview = () => {
    const completedList = Object.values(extractedChaptersCache);
    if (completedList.length === 0) {
      alert('ದಯವಿಟ್ಟು ಕನಿಷ್ಠ ಒಂದು ಅಧ್ಯಾಯದ ಪ್ರಶ್ನೆಗಳನ್ನು ಹೊರತೆಗೆಯಿರಿ.');
      return;
    }
    assembleFinalBank(completedList);
    setStep(3);
  };

  // Save an individual chapter directly (Chapter-wise saving)
  const handleSaveSingleChapter = async (chapterId: string) => {
    const ch = extractedChaptersCache[chapterId];
    if (!ch) {
      alert('ಈ ಪಾಠದ ಪ್ರಶ್ನೋತ್ತರಗಳನ್ನು ಮೊದಲು ಹೊರತೆಗೆಯಿರಿ.');
      return;
    }

    const singleBank: QuestionBank = {
      metadata: {
        title: `${detectedDoc?.metadata.title || 'LBA Bank'} - ${ch.chapterName}`,
        grade: detectedDoc?.metadata.grade || '6 ನೇ ತರಗತಿ',
        gradeKey: detectedDoc?.metadata.gradeKey || '6',
        subject: detectedDoc?.metadata.subject || 'ವಿಷಯ',
        subjectCode: detectedDoc?.metadata.subjectCode || 'GEN',
        medium: detectedDoc?.metadata.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
        academicYear: detectedDoc?.metadata.academicYear || '2026-27',
        totalChapters: 1,
        totalQuestions: ch.questions.length,
        verified: true,
        source_pdf: fileName,
      },
      chapters: [ch],
    };

    // Download JSON for this single chapter
    const jsonBlob = new Blob([JSON.stringify(singleBank, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const downloadUrl = URL.createObjectURL(jsonBlob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `${ch.chapterName.replace(/\s+/g, '_')}_QA_Bank.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(downloadUrl);

    // Also persist to Firebase Firestore
    try {
      await saveQuestionBankToFirebase(singleBank);
    } catch (fbErr) {
      console.warn('Firebase single chapter save error:', fbErr);
    }

    setSaveSuccessMessage(`"${ch.chapterName}" ಪಾಠವನ್ನು JSON ಆಗಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡಲಾಗಿದೆ ಮತ್ತು Firebase ಡೇಟಾಬೇಸ್‌ಗೆ ಉಳಿಸಲಾಗಿದೆ!`);
    setTimeout(() => setSaveSuccessMessage(null), 5000);
  };

  // 4. Download Actual .json File
  const handleDownloadJson = () => {
    if (!generatedBank) return;

    const jsonBlob = new Blob([rawJsonString], { type: 'application/json;charset=utf-8' });
    const downloadUrl = URL.createObjectURL(jsonBlob);
    const link = document.createElement('a');

    const sub = (generatedBank.metadata.subject || 'Subject').replace(/\s+/g, '_');
    const gr = (generatedBank.metadata.grade || 'Class').replace(/\s+/g, '_');
    link.href = downloadUrl;
    link.download = `${gr}_${sub}_LBA_Question_Bank.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(downloadUrl);
  };

  // 5. Save to Server Database & Firebase Cloud
  const handleSaveToDatabase = async () => {
    if (!generatedBank) return;

    setIsSaving(true);
    setSaveSuccessMessage(null);

    try {
      const response = await fetch('/api/save-question-bank', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ questionBank: generatedBank }),
      });

      const resData = await response.json();
      if (!response.ok || !resData.success) {
        throw new Error(resData.error || 'ಉಳಿಸಲು ವಿಫಲವಾಗಿದೆ.');
      }

      // Also sync to Firebase Firestore
      try {
        await saveQuestionBankToFirebase(generatedBank);
        setSaveSuccessMessage('ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ ಯಶಸ್ವಿಯಾಗಿ ಸರ್ವರ್ ಮತ್ತು Firebase ಕ್ಲೌಡ್‌ಗೆ ಉಳಿಸಲಾಗಿದೆ!');
      } catch (fbErr) {
        setSaveSuccessMessage('ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ ಯಶಸ್ವಿಯಾಗಿ ಸರ್ವರ್ ಡೇಟಾಬೇಸ್‌ಗೆ ಉಳಿಸಲಾಗಿದೆ!');
      }

      // Automatically register the saved entry into active applet so it appears in the dropdown
      if (resData.entry) {
        onLoadGeneratedBank(generatedBank, resData.entry);
      }
    } catch (err: any) {
      alert(err.message || 'ಡೇಟಾಬೇಸ್‌ಗೆ ಉಳಿಸುವಲ್ಲಿ ದೋಷ ಕಂಡುಬಂದಿದೆ.');
    } finally {
      setIsSaving(false);
    }
  };

  // Save to Firebase Firestore Cloud
  const handleSaveToFirebaseOnly = async () => {
    if (!generatedBank) return;

    setIsSaving(true);
    setSaveSuccessMessage(null);

    try {
      const bankId = await saveQuestionBankToFirebase(generatedBank);
      setSaveSuccessMessage(`ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ Firebase Firestore ಕ್ಲೌಡ್‌ಗೆ ಯಶಸ್ವಿಯಾಗಿ ಉಳಿಸಲಾಗಿದೆ!`);

      const entry: IndexEntry = {
        id: bankId,
        path: `firebase://${bankId}`,
        grade: generatedBank.metadata.grade,
        gradeKey: String(generatedBank.metadata.gradeKey || '6'),
        subject: generatedBank.metadata.subject,
        subjectCode: String(generatedBank.metadata.subjectCode || 'MATH'),
        medium: generatedBank.metadata.medium || 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
        academicYear: String(generatedBank.metadata.academicYear || '2026-27'),
        totalChapters: generatedBank.chapters.length,
        totalQuestions: generatedBank.chapters.reduce((sum, ch) => sum + (ch.questions?.length || 0), 0),
        isUserGenerated: true,
      };

      onLoadGeneratedBank(generatedBank, entry);
    } catch (err: any) {
      alert('Firebase ಗೆ ಉಳಿಸುವಲ್ಲಿ ದೋಷ: ' + (err.message || String(err)));
    } finally {
      setIsSaving(false);
    }
  };

  // 6. Open Immediately in Question Paper Generator
  const handleLoadInQPGenerator = () => {
    if (!generatedBank) return;

    const entry: IndexEntry = {
      id: `generated_${Date.now()}`,
      path: '',
      grade: generatedBank.metadata.grade,
      gradeKey: String(generatedBank.metadata.gradeKey || '6'),
      subject: generatedBank.metadata.subject,
      subjectCode: String(generatedBank.metadata.subjectCode || 'GEN'),
      medium: generatedBank.metadata.medium,
      academicYear: String(generatedBank.metadata.academicYear || '2026-27'),
    };

    onLoadGeneratedBank(generatedBank, entry);
    onBackToApp();
  };

  // Filtered Questions for Preview
  const allQuestions = generatedBank?.chapters.flatMap(c => c.questions) || [];
  const filteredQuestions = allQuestions.filter(q => {
    if (previewChapterFilter !== 'all' && q.chapterId !== previewChapterFilter) return false;
    if (previewFormatFilter !== 'all' && q.formatCategoryId !== previewFormatFilter) return false;
    if (searchQuery.trim()) {
      const sq = searchQuery.toLowerCase();
      return (
        q.question.toLowerCase().includes(sq) ||
        q.answer.toLowerCase().includes(sq) ||
        (q.options && q.options.some(o => o.toLowerCase().includes(sq)))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 font-kannada">
      
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-linear-to-tr from-purple-600 via-indigo-600 to-blue-600 text-white flex items-center justify-center shadow-md">
            <Cpu className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                AI ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ ಜನರೇಟರ್ (AI JSON Question Bank Generator)
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-2xs font-extrabold bg-purple-100 text-purple-800 border border-purple-200">
                Gemini OCR
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              ಕರ್ನಾಟಕ DSERT LBA ಪಿಡಿಎಫ್‌ಗಳಿಂದ ಪ್ರಶ್ನೋತ್ತರಗಳನ್ನು ಅಕ್ಷರಶಃ ಹೊರತೆಗೆದು ಅಧಿಕೃತ QPG JSON ಮಾದರಿಯನ್ನು ರಚಿಸಿ.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Start New PDF / Reset Button */}
          {(step > 1 || selectedFile || detectedDoc || generatedBank) && (
            <button
              type="button"
              onClick={handleResetAndStartNewPdf}
              className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 font-extrabold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
              title="ಹೊಸ PDF ಅಪ್‌ಲೋಡ್ ಮಾಡಿ ಅಥವಾ ಮೊದಲಿನಿಂದ ಪ್ರಾರಂಭಿಸಿ"
            >
              <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
              <span>ಹೊಸ PDF / ಮೊದಲಿನಿಂದ ಪ್ರಾರಂಭಿಸಿ</span>
            </button>
          )}

          {/* Quick JSON Bank Uploader */}
          <div className="relative">
            <input
              type="file"
              accept=".json,application/json"
              onChange={handleDirectJsonUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <button
              type="button"
              className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-extrabold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
              title="ಸಿದ್ಧವಿರುವ JSON ಪ್ರಶ್ನೆಕೋಶ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ"
            >
              <FileJson className="w-3.5 h-3.5 text-amber-700" />
              <span>JSON ಅಪ್‌ಲೋಡ್ (.json)</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onBackToApp}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <span>← ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ರಚನಾ ಸಾಧನ</span>
          </button>
        </div>
      </div>

      {/* Step Stepper Indicator */}
      <div className="grid grid-cols-3 gap-3">
        <div
          className={`p-3 rounded-xl border flex items-center gap-2.5 transition-all ${
            step === 1
              ? 'bg-white border-indigo-600 shadow-xs ring-1 ring-indigo-500/30'
              : step > 1
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : 'bg-white border-slate-200 text-slate-400'
          }`}
        >
          <div
            className={`w-6 h-6 rounded-full font-black text-xs flex items-center justify-center ${
              step === 1
                ? 'bg-indigo-600 text-white'
                : step > 1
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-200 text-slate-600'
            }`}
          >
            {step > 1 ? <Check className="w-3.5 h-3.5" /> : '1'}
          </div>
          <div>
            <span className="text-xs font-black block">ಹಂತ ೧: PDF ಅಥವಾ JSON ಆಯ್ಕೆ</span>
            <span className="text-2xs text-slate-500">ಪಿಡಿಎಫ್ ಸ್ಕ್ಯಾನ್ / JSON ಅಪ್‌ಲೋಡ್</span>
          </div>
        </div>

        <div
          className={`p-3 rounded-xl border flex items-center gap-2.5 transition-all ${
            step === 2
              ? 'bg-white border-indigo-600 shadow-xs ring-1 ring-indigo-500/30'
              : step > 2
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : 'bg-white border-slate-200 text-slate-400'
          }`}
        >
          <div
            className={`w-6 h-6 rounded-full font-black text-xs flex items-center justify-center ${
              step === 2
                ? 'bg-indigo-600 text-white'
                : step > 2
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-200 text-slate-600'
            }`}
          >
            {step > 2 ? <Check className="w-3.5 h-3.5" /> : '2'}
          </div>
          <div>
            <span className="text-xs font-black block">ಹಂತ ೨: ಅಧ್ಯಾಯವಾರು ಸಂಸ್ಕರಣೆ</span>
            <span className="text-2xs text-slate-500">ಪ್ರಶ್ನೆ & ಉತ್ತರ ಹೊಂದಾಣಿಕೆ</span>
          </div>
        </div>

        <div
          className={`p-3 rounded-xl border flex items-center gap-2.5 transition-all ${
            step === 3
              ? 'bg-white border-indigo-600 shadow-xs ring-1 ring-indigo-500/30'
              : 'bg-white border-slate-200 text-slate-400'
          }`}
        >
          <div
            className={`w-6 h-6 rounded-full font-black text-xs flex items-center justify-center ${
              step === 3 ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'
            }`}
          >
            3
          </div>
          <div>
            <span className="text-xs font-black block">ಹಂತ ೩: ಪರಿಶೀಲನೆ & ಉಳಿಸುವಿಕೆ</span>
            <span className="text-2xs text-slate-500">Firebase & Database ಸಂಗ್ರಹ</span>
          </div>
        </div>
      </div>

      {/* STEP 1: Two Clear Options: (A) Upload PDF or (B) Upload JSON */}
      {step === 1 && (
        <div className="space-y-6">
          {/* Saved PDFs in Database Quick Selector (if any) */}
          {savedPdfs.length > 0 && (
            <div className="bg-gradient-to-r from-indigo-50 via-purple-50 to-blue-50 border border-indigo-200 rounded-2xl p-4 space-y-2">
              <label className="block text-xs font-bold text-indigo-950 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-indigo-600" />
                  <span>ಡೇಟಾಬೇಸ್‌ನಲ್ಲಿರುವ ಉಳಿಸಿದ PDF ಗಳು (Saved PDFs in Database):</span>
                </span>
                <span className="text-2xs font-extrabold text-indigo-700 bg-white px-2 py-0.5 rounded-full border border-indigo-200">
                  {savedPdfs.length} ಲಭ್ಯ
                </span>
              </label>
              <select
                className="w-full bg-white border border-indigo-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-1 focus:ring-indigo-600 focus:outline-hidden cursor-pointer shadow-xs"
                onChange={e => {
                  const found = savedPdfs.find(p => p.id === e.target.value);
                  if (found && found.detectedDoc) {
                    setDetectedDoc(found.detectedDoc);
                    setFileName(found.fileName);
                    setTotalPages(found.totalPages);
                    setFileSizeMB(found.fileSizeMB);
                    setStep(2);
                  }
                }}
                defaultValue=""
              >
                <option value="" disabled>
                  -- ಈ ಹಿಂದೆ ಅಪ್‌ಲೋಡ್ ಮಾಡಿದ PDF ಅನ್ನು ಆರಿಸಿ (Select previously uploaded PDF) --
                </option>
                {savedPdfs.map(p => (
                  <option key={p.id} value={p.id}>
                    📄 {p.fileName} ({p.grade || ''} {p.subject ? `· ${p.subject}` : ''} · {p.totalPages} ಪುಟಗಳು)
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* DUAL OPTIONS CARDS: Card 1 (PDF) & Card 2 (Direct JSON) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Card 1: Upload Karnataka LBA / Textbook PDF */}
            <div className="bg-white rounded-2xl border border-indigo-200 p-6 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full text-2xs font-extrabold bg-indigo-100 text-indigo-800 border border-indigo-200">
                    ಆಯ್ಕೆ ೧: PDF ನಿಂದ ಪ್ರಶ್ನೆಕೋಶ ರಚನೆ
                  </span>
                  <span className="text-2xs font-bold text-indigo-600 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Gemini AI OCR</span>
                  </span>
                </div>
                <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-600" />
                  <span>Karnataka LBA / Textbook PDF ಅಪ್‌ಲೋಡ್</span>
                </h2>
                <p className="text-xs text-slate-500 leading-relaxed">
                  6ನೇ, 7ನೇ, 8ನೇ, 9ನೇ ಅಥವಾ 10ನೇ ತರಗತಿಯ DSERT LBA ಪಿಡಿಎಫ್ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ, ಜೆಮಿನಿ AI ಮೂಲಕ ಪಾಠಗಳು & ಅಧಿಕೃತ ಪ್ರಶ್ನೋತ್ತರಗಳನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಹೊರತೆಗೆಯಿರಿ.
                </p>
              </div>

              {/* Upload Dropzone */}
              <div className="border-2 border-dashed border-indigo-300 hover:border-indigo-600 rounded-2xl p-6 bg-indigo-50/20 text-center transition-all cursor-pointer relative">
                <input
                  type="file"
                  accept=".pdf,application/pdf"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="space-y-2">
                  <div className="w-12 h-12 mx-auto rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
                    <Upload className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-extrabold text-slate-800 block">
                    {selectedFile ? selectedFile.name : 'PDF ಆಯ್ಕೆಮಾಡಿ ಅಥವಾ ಇಲ್ಲಿಗೆ ಎಳೆಯಿರಿ'}
                  </span>
                  <span className="text-3xs text-slate-400">
                    {selectedFile
                      ? `${fileSizeMB} MB · ${totalPages > 0 ? `${totalPages} ಪುಟಗಳು` : 'ಲೋಡ್ ಆಗಿದೆ'}`
                      : 'ಕರ್ನಾಟಕ DSERT LBA PDF (ಗರಿಷ್ಠ 50MB)'}
                  </span>
                </div>
              </div>

              {/* TOC Scan Range if file selected */}
              {selectedFile && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-2 text-xs">
                  <span className="font-bold text-slate-700">ಪರಿವಿಡಿ ಸ್ಕ್ಯಾನ್ ಪುಟ ವ್ಯಾಪ್ತಿ:</span>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      value={scanPageRange}
                      onChange={e => setScanPageRange(e.target.value)}
                      placeholder="1-12"
                      className="w-20 px-2 py-1 bg-white border border-slate-300 rounded font-mono font-bold text-center text-xs"
                    />
                    <span className="text-3xs text-slate-400">/ {totalPages || '..'}</span>
                  </div>
                </div>
              )}

              {scanError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-medium">
                  {scanError}
                </div>
              )}

              <button
                type="button"
                disabled={!selectedFile || isScanning}
                onClick={handleScanPdf}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {isScanning ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>AI ಮೂಲಕ PDF ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>PDF ಸ್ಕ್ಯಾನ್ ಮಾಡಿ & ಅಧ್ಯಾಯಗಳನ್ನು ಗುರುತಿಸಿ</span>
                  </>
                )}
              </button>
            </div>

            {/* Card 2: Direct Upload of Existing JSON Question Bank */}
            <div className="bg-white rounded-2xl border border-amber-300 p-6 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full text-2xs font-extrabold bg-amber-100 text-amber-900 border border-amber-300">
                    ಆಯ್ಕೆ ೨: ಸಿದ್ಧವಿರುವ JSON ಅಪ್‌ಲೋಡ್
                  </span>
                  <span className="text-2xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                    ⚡ ನೇರ ಪ್ರವೇಶ
                  </span>
                </div>
                <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <FileJson className="w-5 h-5 text-amber-600" />
                  <span>ಸಿದ್ಧವಿರುವ JSON ಪ್ರಶ್ನೆಕೋಶ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ (.json)</span>
                </h2>
                <p className="text-xs text-slate-500 leading-relaxed">
                  ಈ ಹಿಂದೆ ಸೇವ್ ಮಾಡಿದ ಅಥವಾ ನಿಮ್ಮ ಬಳಿ ಇರುವ ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ JSON ಫೈಲ್ ಅನ್ನು ನೇರವಾಗಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ. ಪ್ರಶ್ನೆಗಳು, ಉತ್ತರಗಳು, ಅಂಕಗಳು ಮತ್ತು ಉದ್ದಿಷ್ಟಗಳನ್ನು ವೀಕ್ಷಿಸಿ ಮತ್ತು Firebase ಗೆ ಉಳಿಸಿ.
                </p>
              </div>

              {/* Direct JSON Upload Dropzone */}
              <div className="border-2 border-dashed border-amber-300 hover:border-amber-500 rounded-2xl p-6 bg-amber-50/20 text-center transition-all cursor-pointer relative">
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleDirectJsonUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="space-y-2">
                  <div className="w-12 h-12 mx-auto rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                    <FileJson className="w-6 h-6 text-amber-700" />
                  </div>
                  <span className="text-xs font-extrabold text-slate-800 block">
                    JSON ಫೈಲ್ (.json) ಆಯ್ಕೆಮಾಡಿ ಅಥವಾ ಇಲ್ಲಿಗೆ ಎಳೆಯಿರಿ
                  </span>
                  <span className="text-3xs text-slate-400">
                    Question Bank JSON ಫೈಲ್
                  </span>
                </div>
              </div>

              <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200/80 text-2xs text-amber-900 space-y-1">
                <span className="font-bold block">💡 ಮುಖ್ಯ ವೈಶಿಷ್ಟ್ಯಗಳು:</span>
                <ul className="list-disc list-inside text-amber-800 space-y-0.5">
                  <li>ನಕಲಿ (Duplicate) ಪ್ರಶ್ನೆಗಳನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ.</li>
                  <li>ಜ್ಞಾನ, ತಿಳುವಳಿಕೆ, ಅನ್ವಯ, ಕೌಶಲ ಉದ್ದೇಶಗಳು ಲಭ್ಯವಿರುತ್ತವೆ.</li>
                  <li>ನೇರವಾಗಿ Firebase ಮತ್ತು ಶಾಶ್ವತ ಡೇಟಾಬೇಸ್‌ಗೆ ಉಳಿಸಬಹುದು.</li>
                </ul>
              </div>

              <div className="relative">
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleDirectJsonUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <button
                  type="button"
                  className="w-full py-3 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>JSON ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ & ಪರಿಶೀಲನೆಗೆ ತೆರಳಿ</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* STEP 2: Review Chapters & Step-by-Step Batch Extraction */}
      {step === 2 && detectedDoc && (
        <div className="space-y-6">
          {/* PDF Memory Lost Reattach Banner (if user refreshed or reloaded) */}
          {!fileBuffer && !selectedFile && (
            <div className="p-4 bg-amber-50 border-2 border-amber-400 rounded-2xl shadow-sm flex flex-wrap items-center justify-between gap-4 text-amber-950">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />
                <div>
                  <h4 className="text-xs font-black text-amber-900">
                    ⚠️ PDF ಫೈಲ್ ಮೆಮೊರಿಯಿಂದ ತೆರವುಗೊಂಡಿದೆ (ಪುಟ ರೀಲೋಡ್ ಆದ ಕಾರಣ)
                  </h4>
                  <p className="text-2xs text-amber-800 mt-0.5">
                    ಈಗಾಗಲೇ ಹೊರತೆಗೆಯಲಾದ {Object.keys(extractedChaptersCache).length} ಅಧ್ಯಾಯಗಳು ಸುರಕ್ಷಿತವಾಗಿವೆ! 4 ನೇ ಅಧ್ಯಾಯ ಅಥವಾ ಮುಂದಿನ ಅಧ್ಯಾಯಗಳನ್ನು ಹೊರತೆಗೆಯಲು ದಯವಿಟ್ಟು ಅದೇ PDF ಅನ್ನು ಇಲ್ಲಿ ಮರು-ಆಯ್ಕೆ ಮಾಡಿ.
                  </p>
                </div>
              </div>
              <div className="relative">
                <input
                  type="file"
                  accept=".pdf,application/pdf"
                  onChange={handleReattachPdf}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <button
                  type="button"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>📂 ಅದೇ PDF ಫೈಲ್ ಮರು-ಆಯ್ಕೆಮಾಡಿ</span>
                </button>
              </div>
            </div>
          )}

          {/* Metadata Card with Quick Action Buttons */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-3">
            <div className="flex flex-wrap items-center justify-between border-b border-slate-100 pb-2.5 gap-2">
              <div>
                <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <span>📘 ದಾಖಲೆಯ ವಿವರಗಳು (Detected Document Metadata)</span>
                </h2>
                <span className="text-2xs font-bold text-slate-500">
                  ಒಟ್ಟು {detectedDoc.chapters.length} ಅಧ್ಯಾಯಗಳು ಪತ್ತೆಯಾಗಿವೆ ({Object.keys(extractedChaptersCache).length} ಪೂರ್ಣಗೊಂಡಿವೆ)
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {Object.keys(extractedChaptersCache).length > 0 && (
                  <button
                    type="button"
                    onClick={handleProceedToReview}
                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                    title="ಈಗಾಗಲೇ ತಯಾರಾದ ಅಧ್ಯಾಯಗಳನ್ನು ವೀಕ್ಷಿಸಿ ಮತ್ತು Firebase ಗೆ ಉಳಿಸಿ"
                  >
                    <span>💾 ಸಿದ್ಧವಿರುವ {Object.keys(extractedChaptersCache).length} ಪಾಠಗಳನ್ನು ಉಳಿಸಿ</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleResetAndStartNewPdf}
                  className="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 font-extrabold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
                  title="ಬೇರೆ PDF ಅಪ್‌ಲೋಡ್ ಮಾಡಿ ಮೊದಲಿನಿಂದ ಪ್ರಾರಂಭಿಸಿ"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
                  <span>ಹೊಸ PDF ಅಪ್‌ಲೋಡ್ ಮಾಡಿ</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/60">
                <span className="text-2xs text-slate-500 font-bold block uppercase">ತರಗತಿ</span>
                <span className="font-extrabold text-slate-900">{detectedDoc.metadata.grade}</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/60">
                <span className="text-2xs text-slate-500 font-bold block uppercase">ವಿಷಯ</span>
                <span className="font-extrabold text-indigo-700">{detectedDoc.metadata.subject}</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/60">
                <span className="text-2xs text-slate-500 font-bold block uppercase">ಬೋಧನಾ ಮಾಧ್ಯಮ</span>
                <span className="font-extrabold text-slate-900">{detectedDoc.metadata.medium}</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/60">
                <span className="text-2xs text-slate-500 font-bold block uppercase">ಶೈಕ್ಷಣಿಕ ವರ್ಷ</span>
                <span className="font-extrabold text-slate-900">{detectedDoc.metadata.academicYear}</span>
              </div>
            </div>
          </div>

          {/* Page Number Offset & Global Answer Key Configuration */}
          <div className="bg-white rounded-2xl border border-indigo-100 p-5 shadow-xs space-y-4">
            <div className="border-b border-slate-100 pb-2.5 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-600" />
                <h3 className="text-xs font-extrabold text-slate-900">
                  ಪುಟ ಸಂಖ್ಯೆ ಹೊಂದಾಣಿಕೆ & ಉತ್ತರ ಸೂಚಿ (Page Offset & Answer Key Auto-Detection)
                </h3>
              </div>
              <span className="text-3xs font-bold text-indigo-800 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-200">
                PDF ಒಟ್ಟು: {totalPages} ಪುಟಗಳು
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {/* Printed to Physical Page Offset */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200/70 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-slate-800">
                    ಪುಸ್ತಕದ ಮುದ್ರಿತ ಪುಟ ಸಂಖ್ಯೆ → PDF ಭೌತಿಕ ಪುಟ ಆಫ್‌ಸೆಟ್:
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setPageOffset(prev => Math.max(0, prev - 1))}
                      className="w-6 h-6 rounded bg-slate-200 hover:bg-slate-300 font-bold text-slate-700 flex items-center justify-center cursor-pointer"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      value={pageOffset}
                      onChange={e => setPageOffset(parseInt(e.target.value, 10) || 0)}
                      className="w-14 px-2 py-1 bg-white border border-slate-300 rounded text-center font-mono font-bold text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => setPageOffset(prev => prev + 1)}
                      className="w-6 h-6 rounded bg-slate-200 hover:bg-slate-300 font-bold text-slate-700 flex items-center justify-center cursor-pointer"
                    >
                      +
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyOffsetToAll(pageOffset)}
                      className="ml-1 px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-2xs rounded-lg transition-colors cursor-pointer"
                      title="ಎಲ್ಲಾ ಪಾಠಗಳಿಗೂ ಈ ಆಫ್‌ಸೆಟ್ ಅನ್ವಯಿಸಿ"
                    >
                      ಅನ್ವಯಿಸಿ
                    </button>
                  </div>
                </div>
                <p className="text-3xs text-slate-500 leading-relaxed">
                  ಪುಸ್ತಕದ ಪರಿವಿಡಿಯಲ್ಲಿ ಮುದ್ರಿತ ಪುಟ ಸಂಖ್ಯೆ (ಪುಟ 1) ಮತ್ತು PDF ವೀಕ್ಷಕದ ಭೌತಿಕ ಪುಟ ಸಂಖ್ಯೆ (ಪುಟ {1 + pageOffset}) ನಡುವಿನ ವ್ಯತ್ಯಾಸ.
                </p>
              </div>

              {/* Global Answer Key Range */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200/70 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-extrabold text-slate-800">
                    ಜಾಗತಿಕ ಉತ್ತರ ಸೂಚಿ ಪುಟ ವ್ಯಾಪ್ತಿ (Global Answer Pages):
                  </span>
                  <input
                    type="text"
                    value={globalAnswerKeyRange}
                    onChange={e => setGlobalAnswerKeyRange(e.target.value)}
                    placeholder="ಉದಾ: 85-110"
                    className="w-32 px-3 py-1 bg-white border border-slate-300 rounded-lg text-center font-mono font-bold text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
                <p className="text-3xs text-slate-500 leading-relaxed">
                  ಪುಸ್ತಕದ ಕೊನೆಯಲ್ಲಿರುವ ಅಧಿಕೃತ ಉತ್ತರ ಸೂಚಿ ಪುಟಗಳು. ಪ್ರತ್ಯೇಕ ಅಧ್ಯಾಯದಲ್ಲಿ ಉತ್ತರ ಪುಟ ನಮೂದಿಸದಿದ್ದರೆ ಈ ಪುಟಗಳಿಂದ ಉತ್ತರ ಹೊಂದಾಣಿಕೆ ಮಾಡಲಾಗುತ್ತದೆ.
                </p>
              </div>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center justify-between gap-3 border-b border-slate-200 pb-1">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveChapterMode('single')}
                className={`px-4 py-2 font-extrabold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
                  activeChapterMode === 'single'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <span>🎯 ಒಂದೊಂದೇ ಅಧ್ಯಾಯ ಹೊರತೆಗೆಯಿರಿ (Chapter-by-Chapter Mode)</span>
                <span className="px-1.5 py-0.2 rounded-full text-3xs bg-indigo-500/30 text-white">
                  ಶಿಫಾರಸು
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveChapterMode('batch')}
                className={`px-4 py-2 font-extrabold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
                  activeChapterMode === 'batch'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <span>📋 ಎಲ್ಲಾ ಅಧ್ಯಾಯಗಳ ಕೋಷ್ಟಕ (Batch Table View)</span>
              </button>
            </div>

            {detectedDoc.chapters.some(c => c.status === 'done') && (
              <button
                type="button"
                onClick={handleProceedToReview}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <span>
                  ಪೂರ್ಣಗೊಂಡ {detectedDoc.chapters.filter(c => c.status === 'done').length} ಅಧ್ಯಾಯಗಳೊಂದಿಗೆ ಮುಂದುವರಿಯಿರಿ
                </span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* MODE 1: Dedicated Chapter-by-Chapter Extraction Workspace */}
          {activeChapterMode === 'single' && (
            <div className="space-y-4">
              {(() => {
                const currentCh =
                  detectedDoc.chapters.find(c => c.chapterId === selectedSingleChapterId) ||
                  detectedDoc.chapters[0];
                if (!currentCh) return null;
                const currentChIndex = detectedDoc.chapters.findIndex(c => c.chapterId === currentCh.chapterId);
                const cachedCh = extractedChaptersCache[currentCh.chapterId];

                return (
                  <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-5">
                    {/* Chapter Carousel Selector Header */}
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={currentChIndex <= 0}
                          onClick={() => setSelectedSingleChapterId(detectedDoc.chapters[currentChIndex - 1].chapterId)}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-800 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                        >
                          ← ಹಿಂದಿನ ಅಧ್ಯಾಯ
                        </button>
                        <select
                          value={currentCh.chapterId}
                          onChange={e => setSelectedSingleChapterId(e.target.value)}
                          className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-800 cursor-pointer focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        >
                          {detectedDoc.chapters.map(ch => (
                            <option key={ch.chapterId} value={ch.chapterId}>
                              ಅಧ್ಯಾಯ {ch.chapterNumber}: {ch.chapterName} {ch.status === 'done' ? '✓' : ''}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          disabled={currentChIndex >= detectedDoc.chapters.length - 1}
                          onClick={() => setSelectedSingleChapterId(detectedDoc.chapters[currentChIndex + 1].chapterId)}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-800 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                        >
                          ಮುಂದಿನ ಅಧ್ಯಾಯ →
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        {currentCh.status === 'done' && (
                          <div className="flex items-center gap-2">
                            <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-800 flex items-center gap-1.5">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                              <span>ಹೊರತೆಗೆಯಲಾಗಿದೆ ({currentCh.extractedCount} ಪ್ರಶ್ನೆಗಳು)</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => handleSaveSingleChapter(currentCh.chapterId)}
                              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                              title="ಈ ಪಾಠದ ಪ್ರಶ್ನೆಗಳನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ಡೌನ್‌ಲೋಡ್ / ಸೇವ್ ಮಾಡಿ"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>💾 ಈ ಪಾಠ ಉಳಿಸಿ (Save Chapter)</span>
                            </button>
                          </div>
                        )}
                        {currentCh.status === 'processing' && (
                          <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-indigo-100 text-indigo-800 flex items-center gap-1.5 animate-pulse">
                            <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
                            <span>ಸಂಸ್ಕರಿಸಲಾಗುತ್ತಿದೆ...</span>
                          </span>
                        )}
                        {currentCh.status === 'error' && (
                          <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-rose-100 text-rose-800 flex items-center gap-1.5">
                            <AlertTriangle className="w-4 h-4 text-rose-600" />
                            <span>ದೋಷ ಕಂಡುಬಂದಿದೆ</span>
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Chapter Page Controls & Extraction Button */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50/70 p-4 rounded-xl border border-slate-200/80">
                      <div>
                        <label className="text-2xs font-extrabold text-slate-700 block uppercase mb-1">
                          ಪ್ರಶ್ನೆಗಳ PDF ಪುಟ ವ್ಯಾಪ್ತಿ (Question Pages):
                        </label>
                        <input
                          type="text"
                          value={currentCh.questionPages}
                          onChange={e => handleUpdateChapterPages(currentCh.chapterId, 'questionPages', e.target.value)}
                          placeholder="ಉದಾ: 7-14"
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        />
                        <span className="text-3xs text-slate-400 mt-1 block">
                          ಮುದ್ರಿತ ಪುಟ: {currentCh.printedPages || currentCh.questionPages || '-'}
                        </span>
                      </div>

                      <div>
                        <label className="text-2xs font-extrabold text-slate-700 block uppercase mb-1">
                          ಉತ್ತರ ಸೂಚಿ PDF ಪುಟ ವ್ಯಾಪ್ತಿ (Answer Pages):
                        </label>
                        <input
                          type="text"
                          value={currentCh.answerPages}
                          onChange={e => handleUpdateChapterPages(currentCh.chapterId, 'answerPages', e.target.value)}
                          placeholder={globalAnswerKeyRange ? `${globalAnswerKeyRange} (ಜಾಗತಿಕ)` : 'ಉದಾ: 85-88'}
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        />
                        <span className="text-3xs text-slate-400 mt-1 block">
                          {currentCh.answerPages ? 'ನಿರ್ದಿಷ್ಟ ಉತ್ತರ ಪುಟಗಳು' : `ಜಾಗತಿಕ ಉತ್ತರ ಸೂಚಿ ಬಳಸಲಾಗುತ್ತದೆ (${globalAnswerKeyRange || 'ಸ್ವಯಂ'})`}
                        </span>
                      </div>

                      <div className="flex items-end">
                        <button
                          type="button"
                          disabled={isExtracting || currentCh.status === 'processing'}
                          onClick={() => handleExtractSingleChapter(currentCh)}
                          className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                        >
                          {currentCh.status === 'processing' ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              <span>ಹೊರತೆಗೆಯಲಾಗುತ್ತಿದೆ...</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>ಈ ಅಧ್ಯಾಯ {currentCh.chapterNumber} ರ ಪ್ರಶ್ನೋತ್ತರ ಹೊರತೆಗೆಯಿರಿ</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Extracted Questions Live Preview for this Chapter */}
                    {cachedCh && cachedCh.questions && cachedCh.questions.length > 0 && (
                      <div className="space-y-3 pt-2">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                          <h4 className="text-xs font-black text-slate-900 flex items-center gap-2">
                            <span>✅ ಹೊರತೆಗೆದ ಪ್ರಶ್ನೋತ್ತರಗಳ ಮುನ್ನೋಟ ({cachedCh.questions.length} ಪ್ರಶ್ನೆಗಳು)</span>
                          </h4>
                          {currentChIndex < detectedDoc.chapters.length - 1 && (
                            <button
                              type="button"
                              onClick={() => setSelectedSingleChapterId(detectedDoc.chapters[currentChIndex + 1].chapterId)}
                              className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold text-2xs rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <span>ಮುಂದಿನ ಅಧ್ಯಾಯಕ್ಕೆ ತೆರಳಿ</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>

                        <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                          {cachedCh.questions.map((q, idx) => (
                            <div
                              key={q.id || idx}
                              className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/70 text-xs space-y-2"
                            >
                              <div className="flex flex-wrap items-center justify-between gap-1 text-2xs">
                                <div className="flex items-center gap-1.5">
                                  <span className="w-5 h-5 rounded-md bg-indigo-600 text-white font-black flex items-center justify-center">
                                    {idx + 1}
                                  </span>
                                  <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 font-bold">
                                    {q.formatCategoryName || q.questionType}
                                  </span>
                                </div>
                                <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-black">
                                  {q.marks} ಅಂಕ ({q.marks}M)
                                </span>
                              </div>

                              <p className="font-extrabold text-slate-900 text-xs leading-relaxed">
                                {q.question}
                              </p>

                              {q.options && q.options.length > 0 && (
                                <div className="grid grid-cols-2 gap-1.5 pt-1">
                                  {q.options.map((opt, oIdx) => (
                                    <div
                                      key={oIdx}
                                      className={`p-2 rounded-lg text-2xs font-medium border ${
                                        q.answer && q.answer.includes(opt.slice(0, 2))
                                          ? 'bg-emerald-50 border-emerald-300 font-bold text-emerald-900'
                                          : 'bg-white border-slate-200 text-slate-700'
                                      }`}
                                    >
                                      {opt}
                                    </div>
                                  ))}
                                </div>
                              )}

                              <div className="p-2.5 bg-emerald-50/90 border border-emerald-200 rounded-lg text-2xs flex items-start gap-1.5">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                                <div>
                                  <span className="font-bold text-emerald-950 block">ಅಧಿಕೃತ ಉತ್ತರ:</span>
                                  <span className="text-emerald-900 font-medium">{q.answer}</span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}

          {/* MODE 2: All Chapters Batch Table View with Inline Editable Pages */}
          {activeChapterMode === 'batch' && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    ೨. ಎಲ್ಲಾ ಅಧ್ಯಾಯಗಳ ಕೋಷ್ಟಕ (All Chapters Batch Table)
                  </h3>
                  <p className="text-2xs text-slate-500">
                    ಪುಟ ಸಂಖ್ಯೆಗಳನ್ನು ನೇರವಾಗಿ ಟೈಪ್ ಮಾಡಿ ತಿದ್ದಬಹುದು. &apos;ಹೊರತೆಗೆಯಿರಿ&apos; ಕ್ಲಿಕ್ ಮಾಡಿ ಆಯಾ ಅಧ್ಯಾಯದ ಪ್ರಶ್ನೆಗಳನ್ನು ಪಡೆಯಿರಿ.
                  </p>
                </div>

                {!isExtracting && (
                  <div className="flex flex-wrap items-center gap-2">
                    {detectedDoc.chapters.some(c => c.status === 'error') && (
                      <button
                        type="button"
                        onClick={() => handleStartExtraction(true)}
                        className="px-4 py-2 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>
                          ವಿಫಲವಾದ {detectedDoc.chapters.filter(c => c.status === 'error').length} ಅಧ್ಯಾಯಗಳನ್ನು ಪುನಃ ಪ್ರಯತ್ನಿಸಿ
                        </span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => handleStartExtraction(false)}
                      className="px-4 py-2 bg-[#009b5a] hover:bg-[#00874e] text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Cpu className="w-3.5 h-3.5 fill-white" />
                      <span>ಎಲ್ಲಾ ಅಧ್ಯಾಯಗಳ ಪ್ರಶ್ನೋತ್ತರ ಹೊರತೆಗೆಯಿರಿ</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Processing Banner */}
              {isExtracting && (
                <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-indigo-900">
                    <span className="flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
                      <span>{currentProcessingChapter}</span>
                    </span>
                    <span>ಪ್ರಕ್ರಿಯೆ ಪ್ರಗತಿಯಲ್ಲಿದೆ...</span>
                  </div>
                  <div className="w-full bg-indigo-200/60 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-indigo-600 h-full transition-all duration-300"
                      style={{
                        width: `${
                          (detectedDoc.chapters.filter(c => c.status === 'done').length /
                            detectedDoc.chapters.length) *
                          100
                        }%`,
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Editable Chapters Table */}
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3 w-12 text-center">ಕ್ರ.ಸಂ.</th>
                      <th className="py-2.5 px-3">ಪಾಠದ ಹೆಸರು</th>
                      <th className="py-2.5 px-3">ವಿಭಾಗ</th>
                      <th className="py-2.5 px-3">ಪ್ರಶ್ನೆಗಳ PDF ಪುಟ (Editable)</th>
                      <th className="py-2.5 px-3">ಉತ್ತರಗಳ PDF ಪುಟ (Editable)</th>
                      <th className="py-2.5 px-3 text-center">ಸ್ಥಿತಿ (Status)</th>
                      <th className="py-2.5 px-3 text-center">ಪ್ರಶ್ನೆಗಳು</th>
                      <th className="py-2.5 px-3 text-center">ಕ್ರಿಯೆ (Action)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {detectedDoc.chapters.map(ch => (
                      <tr key={ch.chapterId} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3 text-center font-bold text-slate-600">
                          {ch.chapterNumber}
                        </td>
                        <td className="py-2.5 px-3 font-bold text-slate-900">{ch.chapterName}</td>
                        <td className="py-2.5 px-3 text-slate-600">{ch.sectionType || '-'}</td>
                        <td className="py-2.5 px-3">
                          <div className="space-y-1">
                            <input
                              type="text"
                              value={ch.questionPages}
                              onChange={e => handleUpdateChapterPages(ch.chapterId, 'questionPages', e.target.value)}
                              placeholder="ಉದಾ: 7-12"
                              className="w-24 px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                              title="PDF ವೀಕ್ಷಕದಲ್ಲಿ ಈ ಪಾಠದ ಪ್ರಶ್ನೆಗಳಿರುವ ಪುಟ ಸಂಖ್ಯೆ"
                            />
                            {ch.questionPages ? (
                              <span className="text-3xs text-emerald-700 font-bold block">✓ ಸ್ವಯಂ ಪತ್ತೆಯಾಗಿದೆ</span>
                            ) : (
                              <span className="text-3xs text-amber-700 font-bold block">⚠️ ಪುಟ ನಮೂದಿಸಿ</span>
                            )}
                          </div>
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="space-y-1">
                            <input
                              type="text"
                              value={ch.answerPages}
                              onChange={e => handleUpdateChapterPages(ch.chapterId, 'answerPages', e.target.value)}
                              placeholder={globalAnswerKeyRange || 'ಜಾಗತಿಕ'}
                              className="w-24 px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                              title="PDF ವೀಕ್ಷಕದಲ್ಲಿ ಈ ಪಾಠದ ಉತ್ತರಗಳಿರುವ ಪುಟ ಸಂಖ್ಯೆ"
                            />
                            <span className="text-3xs text-slate-400 block">
                              {ch.answerPages ? 'ಪ್ರತ್ಯೇಕ' : 'ಜಾಗತಿಕ ಕೀ'}
                            </span>
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          {ch.status === 'pending' && (
                            <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-slate-100 text-slate-600">
                              ನಿರೀಕ್ಷೆಯಲ್ಲಿದೆ
                            </span>
                          )}
                          {ch.status === 'processing' && (
                            <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-indigo-100 text-indigo-700 animate-pulse flex items-center gap-1 justify-center">
                              <RefreshCw className="w-3 h-3 animate-spin" />
                              <span>ಹೊರತೆಗೆಯಲಾಗುತ್ತಿದೆ</span>
                            </span>
                          )}
                          {ch.status === 'done' && (
                            <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1 justify-center">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>ಪೂರ್ಣಗೊಂಡಿದೆ</span>
                            </span>
                          )}
                          {ch.status === 'error' && (
                            <div className="flex flex-col items-center gap-0.5">
                              <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-rose-100 text-rose-800">
                                ❌ ದೋಷ
                              </span>
                              {ch.errorMessage && (
                                <span className="text-3xs text-rose-600 max-w-xs truncate" title={ch.errorMessage}>
                                  {ch.errorMessage}
                                </span>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center font-black text-indigo-700">
                          {ch.extractedCount !== undefined ? `${ch.extractedCount} ಪ್ರಶ್ನೆಗಳು` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {ch.status === 'done' && (
                              <button
                                type="button"
                                onClick={() => handleSaveSingleChapter(ch.chapterId)}
                                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-2xs font-extrabold transition-all cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                                title="ಈ ಪಾಠದ ಪ್ರಶ್ನೆಗಳನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ಡೌನ್‌ಲೋಡ್ / ಸೇವ್ ಮಾಡಿ"
                              >
                                <Download className="w-3 h-3 text-emerald-600" />
                                <span>ಉಳಿಸಿ</span>
                              </button>
                            )}
                            <button
                              type="button"
                              disabled={isExtracting || ch.status === 'processing'}
                              onClick={() => handleExtractSingleChapter(ch)}
                              className={`px-2.5 py-1 rounded-lg text-2xs font-extrabold transition-all cursor-pointer inline-flex items-center gap-1 disabled:opacity-50 ${
                                ch.status === 'error'
                                  ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-xs'
                                  : ch.status === 'done'
                                  ? 'bg-slate-100 hover:bg-indigo-50 text-indigo-700 border border-slate-200'
                                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                              }`}
                              title="ಈ ಅಧ್ಯಾಯದ ಪ್ರಶ್ನೋತ್ತರಗಳನ್ನು ಹೊರತೆಗೆಯಿರಿ ಅಥವಾ ಪುನಃ ಪ್ರಯತ್ನಿಸಿ"
                            >
                              <RefreshCw className="w-2.5 h-2.5" />
                              <span>{ch.status === 'done' ? 'ಮರುಹೊರತೆಗೆಯಿರಿ' : ch.status === 'error' ? 'ಪುನಃ ಪ್ರಯತ್ನಿಸಿ' : 'ಹೊರತೆಗೆಯಿರಿ'}</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
            {/* Live Progress Logs Console */}
            {extractionLog.length > 0 && (
              <div className="bg-slate-900 text-slate-200 p-4 rounded-xl font-mono text-2xs max-h-48 overflow-y-auto space-y-1">
                {extractionLog.map((log, i) => (
                  <div key={i} className="leading-relaxed">
                    {log}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      {/* STEP 3: Verification, Validation Dashboard & Download JSON */}
      {step === 3 && generatedBank && (
        <div className="space-y-6">
          {/* Success Banner */}
          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-emerald-900">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-black">
                  🎉 ಅಧಿಕೃತ JSON ಪ್ರಶ್ನೆ ಬ್ಯಾಂಕ್ ಯಶಸ್ವಿಯಾಗಿ ರಚನೆಯಾಗಿದೆ!
                </h3>
                <p className="text-2xs text-emerald-800 font-medium">
                  {generatedBank.chapters.length} ಅಧ್ಯಾಯಗಳು · {String(generatedBank.metadata.totalQuestions || allQuestions.length)} ಪ್ರಶ್ನೆಗಳು ಹಾಗೂ ಅಧಿಕೃತ ಉತ್ತರಗಳು ಸಿದ್ಧವಾಗಿವೆ.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleSaveToDatabase}
                disabled={isSaving}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                title="Firebase Firestore ಕ್ಲೌಡ್ ಮತ್ತು ಸರ್ವರ್ ಡೇಟಾಬೇಸ್‌ಗೆ ಖಾಯಂ ಆಗಿ ಉಳಿಸಿ"
              >
                <Cloud className="w-4 h-4" />
                <span>{isSaving ? 'ಉಳಿಸಲಾಗುತ್ತಿದೆ...' : '🔥 Firebase & Database ಗೆ ಖಾಯಂ ಉಳಿಸಿ'}</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadJson}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                title="JSON ಫೈಲ್ ಅನ್ನು ನಿಮ್ಮ ಸಾಧನಕ್ಕೆ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ"
              >
                <Download className="w-4 h-4" />
                <span>ಡೌನ್‌ಲೋಡ್ JSON ಫೈಲ್ (.json)</span>
              </button>

              <button
                type="button"
                onClick={handleLoadInQPGenerator}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                title="ಈಗಲೇ ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ರಚಿಸಲು ಮುಂದುವರಿಯಿರಿ"
              >
                <BookOpen className="w-4 h-4" />
                <span>ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ರಚನೆಯಲ್ಲಿ ಬಳಸಿ</span>
              </button>

              <button
                type="button"
                onClick={handleResetAndStartNewPdf}
                className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 font-extrabold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                title="ಬೇರೆ PDF ಅಪ್‌ಲೋಡ್ ಮಾಡಿ ಹೊಸದಾಗಿ ಪ್ರಾರಂಭಿಸಿ"
              >
                <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
                <span>ಹೊಸ PDF ಅಪ್‌ಲೋಡ್ ಮಾಡಿ</span>
              </button>
            </div>
          </div>

          {saveSuccessMessage && (
            <div className="p-3 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl text-xs font-bold">
              {saveSuccessMessage}
            </div>
          )}

          {/* Verification Navigation Tabs */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('preview')}
                  className={`px-4 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                    activeTab === 'preview'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5 inline mr-1" />
                  <span>ಪ್ರಶ್ನೆ & ಉತ್ತರಗಳ ಪರಿಶೀಲನೆ ({allQuestions.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('json')}
                  className={`px-4 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                    activeTab === 'json'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <Code className="w-3.5 h-3.5 inline mr-1" />
                  <span>ಕಚ್ಚಾ JSON ವೀಕ್ಷಣೆ (Raw JSON)</span>
                </button>
              </div>

              {/* Filters for Preview */}
              {activeTab === 'preview' && (
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={previewChapterFilter}
                    onChange={e => setPreviewChapterFilter(e.target.value)}
                    className="text-xs font-bold bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-hidden"
                  >
                    <option value="all">ಎಲ್ಲಾ ಅಧ್ಯಾಯಗಳು</option>
                    {generatedBank.chapters.map(c => (
                      <option key={c.chapterId} value={c.chapterId}>
                        {c.chapterNumber}. {c.chapterName} ({c.questions.length})
                      </option>
                    ))}
                  </select>

                  <div className="relative">
                    <input
                      type="text"
                      placeholder="ಪ್ರಶ್ನೆ ಹುಡುಕಿ..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="text-xs bg-slate-50 border border-slate-200 rounded-lg pl-7 pr-2.5 py-1.5 focus:outline-hidden w-44"
                    />
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2 pointer-events-none" />
                  </div>
                </div>
              )}
            </div>

            {/* TAB 1: Verified Questions & Answers Card View */}
            {activeTab === 'preview' && (
              <div className="space-y-3">
                <div className="text-2xs font-bold text-slate-500">
                  ತೋರಿಸಲಾಗುತ್ತಿರುವ ಪ್ರಶ್ನೆಗಳು: {filteredQuestions.length} / {allQuestions.length}
                </div>

                <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
                  {filteredQuestions.map((q, idx) => {
                    const isExpanded = expandedQuestionId === q.id;

                    return (
                      <div
                        key={q.id || idx}
                        className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl hover:border-indigo-300 transition-all space-y-2 text-xs"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-2.5 flex-1">
                            <span className="w-6 h-6 rounded-md bg-indigo-100 text-indigo-900 font-black text-2xs flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <div className="space-y-1 flex-1">
                              <div className="flex flex-wrap items-center gap-1.5 text-2xs">
                                <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200/60">
                                  {q.chapterName}
                                </span>
                                <span className="font-medium text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                                  {q.formatCategoryName}
                                </span>
                                <span className="font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded-md border border-amber-200">
                                  {q.marks} ಅಂಕ
                                </span>
                              </div>
                              <p className="font-bold text-slate-900 leading-relaxed text-xs sm:text-sm">
                                {q.question}
                              </p>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => setExpandedQuestionId(isExpanded ? null : q.id)}
                            className="text-slate-400 hover:text-slate-700 p-1"
                          >
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                        </div>

                        {/* Options if MCQ */}
                        {q.options && q.options.length > 0 && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-8 pt-1">
                            {q.options.map((opt, oIdx) => (
                              <div
                                key={oIdx}
                                className="bg-white px-2.5 py-1.5 rounded-lg border border-slate-200 text-2xs text-slate-700 font-medium"
                              >
                                {opt}
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Matched Answer Key */}
                        <div className="pl-8 pt-1">
                          <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-950 text-xs">
                            <span className="font-extrabold text-emerald-800 block text-2xs uppercase mb-0.5">
                              ✓ ಅಧಿಕೃತ ಉತ್ತರ (Matched Answer):
                            </span>
                            <div className="font-semibold leading-relaxed whitespace-pre-line">
                              {q.answer}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: Raw JSON Preview */}
            {activeTab === 'json' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-2xs font-bold text-slate-500">
                    QPG Standard Schema JSON (UTF-8 Kannada Unicode)
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(rawJsonString);
                      setSaveSuccessMessage('✅ JSON ಕ್ಲಿಪ್‌ಬೋರ್ಡ್‌ಗೆ ನಕಲಿಸಲಾಗಿದೆ (Copied to Clipboard)!');
                      setTimeout(() => setSaveSuccessMessage(null), 3000);
                    }}
                    className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                  >
                    ನಕಲಿಸಿ (Copy JSON)
                  </button>
                </div>
                <pre className="bg-slate-900 text-emerald-400 p-4 rounded-xl font-mono text-2xs max-h-[500px] overflow-y-auto leading-relaxed selection:bg-emerald-800">
                  {rawJsonString}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* In-App Confirmation Modal for "Upload Another PDF / Reset and Start Over" */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-rose-600 mb-3">
              <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center shrink-0">
                <RotateCcw className="w-5 h-5" />
              </div>
              <h3 className="text-base font-extrabold text-slate-900">
                ಹೊಸ PDF / ಮೊದಲಿನಿಂದ ಪ್ರಾರಂಭಿಸಿ?
              </h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-6">
              ಹೊಸ PDF ಅಪ್‌ಲೋಡ್ ಮಾಡಲು ಅಥವಾ ಮೊದಲಿನಿಂದ ಪ್ರಾರಂಭಿಸಲು ಬಯಸುವಿರಾ? ಈಗಾಗಲೇ ಸಿದ್ಧಪಡಿಸಿದ ಪ್ರಶ್ನೆಗಳು ತೆರವುಗೊಳ್ಳುತ್ತವೆ (ಅಗತ್ಯವಿದ್ದರೆ ಮೊದಲು JSON ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ ಅಥವಾ ಸೇವ್ ಮಾಡಿಕೊಳ್ಳಿ).
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                ರದ್ದುಗೊಳಿಸಿ (Cancel)
              </button>
              <button
                type="button"
                onClick={executeResetAndStartNewPdf}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>ಹೌದು, ಮೊದಲಿನಿಂದ ಪ್ರಾರಂಭಿಸಿ</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
