/**
 * Official Karnataka DSERT 5-Stage Blueprint View
 * Recreates the exact 5-stage blueprint matrix with:
 * 1. Step 5 Master Grid: 4 Objectives (ಜ್ಞಾನ, ತಿಳುವಳಿಕೆ, ಅನ್ವಯ, ಕೌಶಲ), each with 3 sub-columns (ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ).
 * 2. Standard Karnataka notation: Q(M) e.g. 2(2) = 2 questions of 2 marks. If 0, '-' is shown.
 * 3. Step 4: Editable percentage (%) with automatic marks and questions recalculation (capped at 100%).
 * 4. Exact tallies between Step 1, Step 3, Step 4, and Step 5 columns/rows.
 * 5. Drill-down inspection showing ONLY questions used in the question paper, with instant same-mark swapping.
 * Author: M I Nilaji / S R Angadi
 */

import React, { useState, useMemo } from 'react';
import {
  CompleteBlueprint,
  ObjectiveDiffCell,
  MasterGridRow,
} from '../services/blueprintEngine.ts';
import {
  QuestionBank,
  QuestionItem,
  GeneratedPaper,
  GeneratedQuestionItem,
} from '../types/questionBank.ts';
import {
  Printer,
  ArrowLeft,
  Layers,
  HelpCircle,
  X,
  Search,
  CheckCircle2,
  BookOpen,
  Tag,
  Info,
  RefreshCw,
  Check,
  Percent,
  Sliders,
  AlertTriangle,
} from 'lucide-react';
import { matchesDifficulty } from './QuestionBankExplorer.tsx';

interface CleanNumberInputProps {
  value: number;
  onChange: (val: number) => void;
  min?: number;
  max?: number;
  className?: string;
  title?: string;
  suffix?: string;
  disabled?: boolean;
}

/**
 * Clean numeric input that allows users to completely backspace without forcing an initial 0,
 * and seamlessly converts typed text to number on blur or valid change.
 */
export const CleanNumberInput: React.FC<CleanNumberInputProps> = ({
  value,
  onChange,
  min = 0,
  max,
  className = '',
  title,
  suffix,
  disabled = false,
}) => {
  const [localStr, setLocalStr] = useState<string>(() => (value === 0 ? '0' : String(value)));
  const isTypingRef = React.useRef<boolean>(false);

  React.useEffect(() => {
    if (!isTypingRef.current) {
      setLocalStr(value === 0 ? '0' : String(value));
    }
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const text = e.target.value;
    setLocalStr(text);
    isTypingRef.current = true;
    if (text.trim() === '') {
      // Allows user to backspace everything cleanly without prepending 0!
      onChange(0);
      return;
    }
    const parsed = parseFloat(text);
    if (!isNaN(parsed)) {
      let clamped = parsed;
      if (min !== undefined && clamped < min) clamped = min;
      if (max !== undefined && clamped > max) clamped = max;
      onChange(clamped);
    }
  };

  const handleBlur = () => {
    isTypingRef.current = false;
    if (localStr.trim() === '') {
      setLocalStr('0');
      onChange(0);
    } else {
      const parsed = parseFloat(localStr);
      if (isNaN(parsed)) {
        setLocalStr('0');
        onChange(0);
      } else {
        let clamped = parsed;
        if (min !== undefined && clamped < min) clamped = min;
        if (max !== undefined && clamped > max) clamped = max;
        setLocalStr(String(clamped));
        onChange(clamped);
      }
    }
  };

  return (
    <div className="inline-flex items-center justify-center gap-0.5">
      <input
        type="text"
        inputMode="decimal"
        value={localStr}
        onChange={handleChange}
        onBlur={handleBlur}
        disabled={disabled}
        className={className}
        title={title}
      />
      {suffix && <span className="text-slate-500 font-bold text-xs">{suffix}</span>}
    </div>
  );
};

interface BluePrintViewProps {
  blueprint: CompleteBlueprint;
  bank?: QuestionBank | null;
  paper?: GeneratedPaper | null;
  onUpdatePaper?: (paper: GeneratedPaper) => void;
  onBackToSetup: () => void;
  onViewPaper?: () => void;
}

interface DrillDownState {
  title: string;
  subtitle: string;
  badge: string;
  questions: QuestionItem[];
}

export const BluePrintView: React.FC<BluePrintViewProps> = ({
  blueprint,
  bank,
  paper,
  onUpdatePaper,
  onBackToSetup,
  onViewPaper,
}) => {
  const [drillDown, setDrillDown] = useState<DrillDownState | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Step 1: Editable Objectives State (Percentage, Marks, Questions)
  const [step1Items, setStep1Items] = useState(() =>
    blueprint.step1Objectives.map(o => ({
      ...o,
      percentage: o.percentage,
      marks: o.marks,
      questionsCount: o.questionsCount,
    }))
  );

  React.useEffect(() => {
    setStep1Items(
      blueprint.step1Objectives.map(o => ({
        ...o,
        percentage: o.percentage,
        marks: o.marks,
        questionsCount: o.questionsCount,
      }))
    );
  }, [blueprint.step1Objectives]);

  // Step 2: Editable Question Types State (ಕ್ರ.ಸಂ., ಪ್ರಶ್ನೆ ಪ್ರಕಾರ, ಪ್ರತಿಶತ, ಪ್ರಶ್ನೆಗಳ ಸಂಖ್ಯೆ, ಅಂಕ)
  const [step2Items, setStep2Items] = useState(() =>
    blueprint.step2QuestionTypes.map(t => {
      const pct =
        blueprint.totalMarks > 0
          ? Math.round((t.marks / blueprint.totalMarks) * 1000) / 10
          : 0;
      return {
        ...t,
        percentage: pct,
        questionsCount: t.questionsCount,
        marks: t.marks,
      };
    })
  );

  React.useEffect(() => {
    setStep2Items(
      blueprint.step2QuestionTypes.map(t => {
        const pct =
          blueprint.totalMarks > 0
            ? Math.round((t.marks / blueprint.totalMarks) * 1000) / 10
            : 0;
        return {
          ...t,
          percentage: pct,
          questionsCount: t.questionsCount,
          marks: t.marks,
        };
      })
    );
  }, [blueprint.step2QuestionTypes, blueprint.totalMarks]);

  // Step 3: Difficulty Levels State (ಸುಲಭ 30%, ಸಾಧಾರಣ 50%, ಕಠಿಣ 20% fixed standard percentages, whole integer marks & questions)
  const [step3Items, setStep3Items] = useState(() => {
    const M = blueprint.totalMarks || 40;
    const Q = blueprint.totalQuestions || 24;
    const easyM = Math.round(M * 0.3);
    const avgM = Math.round(M * 0.5);
    const diffM = Math.max(0, M - (easyM + avgM));

    const easyQ = Math.round(Q * 0.3);
    const avgQ = Math.round(Q * 0.5);
    const diffQ = Math.max(0, Q - (easyQ + avgQ));

    return [
      { id: 'easy', name: 'ಸುಲಭ (Easy)', percentage: 30, questionsCount: easyQ, marks: easyM },
      { id: 'avg', name: 'ಸಾಧಾರಣ (Average)', percentage: 50, questionsCount: avgQ, marks: avgM },
      { id: 'diff', name: 'ಕಠಿಣ (Difficult)', percentage: 20, questionsCount: diffQ, marks: diffM },
    ];
  });

  React.useEffect(() => {
    const M = blueprint.totalMarks || 40;
    const Q = blueprint.totalQuestions || 24;
    const easyM = Math.round(M * 0.3);
    const avgM = Math.round(M * 0.5);
    const diffM = Math.max(0, M - (easyM + avgM));

    const easyQ = Math.round(Q * 0.3);
    const avgQ = Math.round(Q * 0.5);
    const diffQ = Math.max(0, Q - (easyQ + avgQ));

    setStep3Items([
      { id: 'easy', name: 'ಸುಲಭ (Easy)', percentage: 30, questionsCount: easyQ, marks: easyM },
      { id: 'avg', name: 'ಸಾಧಾರಣ (Average)', percentage: 50, questionsCount: avgQ, marks: avgM },
      { id: 'diff', name: 'ಕಠಿಣ (Difficult)', percentage: 20, questionsCount: diffQ, marks: diffM },
    ]);
  }, [blueprint.totalMarks, blueprint.totalQuestions]);

  // Step 4: Editable Chapter Weightage State (Marks editable as integer, % auto-adjusting)
  const [step4Items, setStep4Items] = useState(() =>
    blueprint.step4Chapters.map(c => {
      const initialMarks = Math.max(1, Math.round((blueprint.totalMarks * c.percentage) / 100));
      const initialPct =
        blueprint.totalMarks > 0
          ? Math.round((initialMarks / blueprint.totalMarks) * 1000) / 10
          : c.percentage;
      const initialQ = Math.max(1, Math.round((blueprint.totalQuestions * c.percentage) / 100));
      return {
        ...c,
        percentage: initialPct,
        questionsCount: initialQ,
        marks: initialMarks,
      };
    })
  );

  React.useEffect(() => {
    setStep4Items(
      blueprint.step4Chapters.map(c => {
        const initialMarks = Math.max(1, Math.round((blueprint.totalMarks * c.percentage) / 100));
        const initialPct =
          blueprint.totalMarks > 0
            ? Math.round((initialMarks / blueprint.totalMarks) * 1000) / 10
            : c.percentage;
        const initialQ = Math.max(1, Math.round((blueprint.totalQuestions * c.percentage) / 100));
        return {
          ...c,
          percentage: initialPct,
          questionsCount: initialQ,
          marks: initialMarks,
        };
      })
    );
  }, [blueprint.step4Chapters, blueprint.totalMarks, blueprint.totalQuestions]);

  // Question Swap State (allowing user to change a question without altering blueprint)
  const [swappingQuestion, setSwappingQuestion] = useState<QuestionItem | null>(null);
  const [swapTab, setSwapTab] = useState<'same_chapter' | 'other_chapters'>('same_chapter');
  const [swapSearchQuery, setSwapSearchQuery] = useState<string>('');
  const [swapSuccessMessage, setSwapSuccessMessage] = useState<string | null>(null);

  // Extract all questions across all chapters in the bank
  const allBankQuestions = useMemo(() => {
    if (!bank) return [];
    return bank.chapters.flatMap(ch => ch.questions);
  }, [bank]);

  // Questions actually used in the question paper
  const usedPaperQuestions = useMemo(() => {
    if (!paper) return [];
    return paper.sections.flatMap(s => s.questions);
  }, [paper]);

  // Set of currently used question IDs in the paper
  const currentlyUsedIds = useMemo(() => {
    return new Set(usedPaperQuestions.map(q => q.bankQuestionId));
  }, [usedPaperQuestions]);

  // Fuzzy chapter matching helper to prevent string mismatches between index and blueprint
  const cleanCh = (s: string) =>
    (s || '')
      .replace(/^[0-9೦-೯\.\s\-–_:]+/, '')
      .replace(/\s+/g, '')
      .toLowerCase();

  const isChMatch = (c1: string | undefined | null, c2: string | undefined | null) => {
    if (!c1 || !c2) return false;
    const k1 = cleanCh(c1);
    const k2 = cleanCh(c2);
    return k1 === k2 || k1.includes(k2) || k2.includes(k1);
  };

  // Candidates for swap matching EXACT SAME MARKS so blueprint is NOT altered
  const swapCandidates = useMemo(() => {
    if (!swappingQuestion) return [];
    const targetMarks = swappingQuestion.marks;
    const targetChId = swappingQuestion.chapterId;
    const targetChName = swappingQuestion.chapterName;

    let candidates = allBankQuestions.filter(q => {
      // STRICT CONSTRAINT: Marks must match exactly so the blueprint is NOT altered!
      if (q.marks !== targetMarks) return false;
      // Must not already be used in paper
      if (currentlyUsedIds.has(q.id) || q.id === swappingQuestion.id) return false;

      const isSameChapter = q.chapterId === targetChId || q.chapterName === targetChName;
      if (swapTab === 'same_chapter') {
        return isSameChapter;
      } else {
        return !isSameChapter;
      }
    });

    if (swapSearchQuery.trim()) {
      const sq = swapSearchQuery.toLowerCase().trim();
      candidates = candidates.filter(
        c =>
          c.question.toLowerCase().includes(sq) ||
          c.answer.toLowerCase().includes(sq) ||
          (c.chapterName && c.chapterName.toLowerCase().includes(sq))
      );
    }

    return candidates;
  }, [swappingQuestion, swapTab, swapSearchQuery, allBankQuestions, currentlyUsedIds]);

  const handleApplySwap = (candidate: QuestionItem) => {
    if (!swappingQuestion) return;

    // 1. Update in paper if paper and onUpdatePaper exist
    if (paper && onUpdatePaper) {
      const updatedSections = paper.sections.map(sec => ({
        ...sec,
        questions: sec.questions.map(q => {
          if (q.bankQuestionId === swappingQuestion.id || q.question === swappingQuestion.question) {
            return {
              ...q,
              bankQuestionId: candidate.id,
              question: candidate.question,
              answer: candidate.answer,
              questionType: candidate.questionType,
              formatCategoryId: candidate.formatCategoryId,
              formatCategoryName: candidate.formatCategoryName,
              options: candidate.options ? [...candidate.options] : undefined,
              items: candidate.items ? [...candidate.items] : undefined,
              chapterName: candidate.chapterName || q.chapterName,
              learningOutcome: candidate.learningOutcome,
              difficulty: candidate.difficulty,
              imageUrl: candidate.imageUrl,
              diagramSvg: candidate.diagramSvg,
              hasDiagram: candidate.hasDiagram,
              diagramDescription: candidate.diagramDescription,
            };
          }
          return q;
        }),
      }));
      onUpdatePaper({
        ...paper,
        sections: updatedSections,
      });
    }

    // 2. Update in active drillDown view
    if (drillDown) {
      const updatedQuestions = drillDown.questions.map(q =>
        q.id === swappingQuestion.id || q.question === swappingQuestion.question ? candidate : q
      );
      setDrillDown({
        ...drillDown,
        questions: updatedQuestions,
      });
    }

    setSwapSuccessMessage(
      `ಪ್ರಶ್ನೆಯನ್ನು "${candidate.chapterName}" ಪಾಠದ ${candidate.marks} ಅಂಕದ ಪ್ರಶ್ನೆಯೊಂದಿಗೆ ಯಶಸ್ವಿಯಾಗಿ ಬದಲಾಯಿಸಲಾಗಿದೆ! ನೀಲನಕಾಶೆಯ ಅಂಕಗಳು ಹಾಗೆಯೇ ಇವೆ.`
    );
    setTimeout(() => setSwapSuccessMessage(null), 4000);
    setSwappingQuestion(null);
  };

  // Helper to convert GeneratedQuestionItem to QuestionItem for display and swap
  // Helper to convert GeneratedQuestionItem or QuestionItem to QuestionItem for display and swap
  const toQuestionItem = (
    gq: QuestionItem | GeneratedQuestionItem,
    fallbackChId?: string
  ): QuestionItem => {
    const fullQ = allBankQuestions.find(
      bq => bq.id === (gq as any).bankQuestionId || bq.id === (gq as any).id || bq.question === gq.question
    );
    if (fullQ) return fullQ;
    return {
      id: (gq as any).bankQuestionId || (gq as any).uid || (gq as any).id || `q_${Date.now()}_${Math.random()}`,
      question: gq.question,
      answer: gq.answer,
      questionType: gq.questionType,
      formatCategoryId: gq.formatCategoryId,
      formatCategoryName: gq.questionType || '',
      marks: gq.marks,
      options: gq.options,
      items: gq.items,
      imageUrl: gq.imageUrl,
      diagramSvg: gq.diagramSvg,
      hasDiagram: gq.hasDiagram,
      diagramDescription: gq.diagramDescription,
      chapterId: fallbackChId || (gq as any).chapterId || '',
      chapterName: gq.chapterName,
      learningOutcome: gq.learningOutcome,
      difficulty: gq.difficulty,
    };
  };

  // Helper to determine question objective
  const getQuestionObjective = (q: QuestionItem | GeneratedQuestionItem): 'know' | 'und' | 'app' | 'skill' => {
    // 1. Explicit tag on question
    const rawObj = ((q as any).objective || (q as any).objectiveName || '').toLowerCase();
    if (rawObj.includes('know') || rawObj.includes('ಜ್ಞಾನ') || rawObj.includes('ಸ್ಮರಣೆ')) return 'know';
    if (rawObj.includes('und') || rawObj.includes('ತಿಳುವಳಿಕೆ') || rawObj.includes('ಗ್ರಹಿಕೆ')) return 'und';
    if (rawObj.includes('app') || rawObj.includes('ಅನ್ವಯ') || rawObj.includes('ಅಭಿವ್ಯಕ್ತಿ')) return 'app';
    if (rawObj.includes('skill') || rawObj.includes('ಕೌಶಲ') || rawObj.includes('ಚಿತ್ರ') || rawObj.includes('ನಕ್ಷೆ')) return 'skill';

    // 2. Learning outcome string
    const lo = (q.learningOutcome || '').toLowerCase();
    if (lo.includes('ಜ್ಞಾನ') || lo.includes('knowledge') || lo.includes('ಸ್ಮರಣೆ')) return 'know';
    if (lo.includes('ಅನ್ವಯ') || lo.includes('application') || lo.includes('ಅಭಿವ್ಯಕ್ತಿ')) return 'app';
    if (lo.includes('ಕೌಶಲ') || lo.includes('skill') || lo.includes('ಚಿತ್ರ') || lo.includes('ನಕ್ಷೆ') || q.hasDiagram) return 'skill';
    if (lo.includes('ತಿಳುವಳಿಕೆ') || lo.includes('understanding') || lo.includes('ಗ್ರಹಿಕೆ')) return 'und';

    // 3. Question text keywords
    const text = (q.question || '').toLowerCase();
    if (text.includes('ಚಿತ್ರ') || text.includes('ರೇಖಾಚಿತ್ರ') || text.includes('ನಕ್ಷೆ') || text.includes('ಗುರುತಿಸಿ') || text.includes('ರಚಿಸಿ') || text.includes('ಡ್ರಾಯಿಂಗ್') || q.hasDiagram) return 'skill';
    if (text.includes('ಲೆಕ್ಕ') || text.includes('ಕಂಡುಹಿಡಿಯಿರಿ') || text.includes('ಬೆಲೆ') || text.includes('ಸಾಧಿಸಿ') || text.includes('ಸಮಸ್ಯೆ') || text.includes('ಅನ್ವಯ') || text.includes('ಪ್ರಯೋಗ')) return 'app';
    if (text.includes('ಕಾರಣ') || text.includes('ವ್ಯತ್ಯಾಸ') || text.includes('ವಿವರಿಸಿ') || text.includes('ಹೋಲಿಸಿ') || text.includes('ಗ್ರಹಿಸಿ')) return 'und';

    if (q.marks === 1) return 'know';
    if (q.marks === 2) return 'und';
    if (q.marks === 3) return 'app';
    return 'skill';
  };

  // 1. Handler: Click an Objective in Step 1
  const handleObjectiveClick = (objId: string, objName: string, expectedMarks: number) => {
    let matched: Array<QuestionItem | GeneratedQuestionItem> = usedPaperQuestions.filter(
      q => getQuestionObjective(q) === objId
    );
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.filter(q => getQuestionObjective(q) === objId);
    }
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.slice(0, 6);
    }
    const questions = matched.map(q => toQuestionItem(q));

    setDrillDown({
      title: `ಉದ್ದೇಶ: ${objName} (${questions.length} ಪ್ರಶ್ನೆಗಳು · ${expectedMarks} ಅಂಕ)`,
      subtitle: `ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆಯಲ್ಲಿ ಈ ಉದ್ದಿಷ್ಟಕ್ಕೆ ಆಯ್ಕೆಯಾದ ಪ್ರಶ್ನೆಗಳು (ಪ್ರಶ್ನೆ ಬದಲಾಯಿಸಲು ಬಟನ್ ಬಳಸಿ)`,
      badge: `${questions.length} ಪ್ರಶ್ನೆಗಳು`,
      questions,
    });
    setSearchQuery('');
  };

  // 2. Handler: Click a Question Type in Step 2
  const handleQuestionTypeClick = (typeId: string, typeName: string, marksPerQ: number) => {
    const isType = (q: QuestionItem | GeneratedQuestionItem) => {
      if (typeId === 'mcq') return q.formatCategoryId === 'mcq' || (q.options && q.options.length > 0);
      if (typeId === 'vsa') return q.marks === 1 && q.formatCategoryId !== 'mcq';
      if (typeId === 'sa') return q.marks === 2;
      if (typeId === 'la1') return q.marks === 3;
      if (typeId === 'la2') return q.marks >= 4 || q.formatCategoryId === 'match';
      return q.marks === marksPerQ;
    };

    let matched: Array<QuestionItem | GeneratedQuestionItem> = usedPaperQuestions.filter(isType);
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.filter(isType);
    }
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.slice(0, 6);
    }
    const questions = matched.map(q => toQuestionItem(q));

    setDrillDown({
      title: `${typeName} (${questions.length} ಪ್ರಶ್ನೆಗಳು)`,
      subtitle: `ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆಯಲ್ಲಿ ಈ ಸ್ವರೂಪಕ್ಕೆ ಬಳಸಲಾದ ಪ್ರಶ್ನೆಗಳು`,
      badge: `${questions.length} ಪ್ರಶ್ನೆಗಳು`,
      questions,
    });
    setSearchQuery('');
  };

  // 3. Handler: Click a Difficulty row in Step 3
  const handleDifficultyClick = (diffId: string, diffName: string) => {
    const isDiff = (q: QuestionItem | GeneratedQuestionItem) => {
      if (diffId === 'easy') return matchesDifficulty(q.difficulty, 'Easy', q.marks);
      if (diffId === 'diff') return matchesDifficulty(q.difficulty, 'Difficult', q.marks);
      return matchesDifficulty(q.difficulty, 'Medium', q.marks);
    };

    let matched: Array<QuestionItem | GeneratedQuestionItem> = usedPaperQuestions.filter(isDiff);
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.filter(isDiff);
    }
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.slice(0, 6);
    }
    const questions = matched.map(q => toQuestionItem(q));

    setDrillDown({
      title: `ಕ್ಲಿಷ್ಟತೆಯ ಮಟ್ಟ: ${diffName} (${questions.length} ಪ್ರಶ್ನೆಗಳು)`,
      subtitle: `ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆಯಲ್ಲಿ ಈ ಕ್ಲಿಷ್ಟತೆಗೆ ಆಯ್ಕೆಯಾದ ಪ್ರಶ್ನೆಗಳು`,
      badge: `${questions.length} ಪ್ರಶ್ನೆಗಳು`,
      questions,
    });
    setSearchQuery('');
  };

  // 4. Handler: Click a Chapter row in Step 4
  const handleChapterClick = (
    chapterId: string,
    chapterName: string,
    expectedMarks: number
  ) => {
    let matched: Array<QuestionItem | GeneratedQuestionItem> = usedPaperQuestions.filter(
      q => isChMatch(q.chapterName, chapterName) || (q as any).chapterId === chapterId
    );
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.filter(
        q => isChMatch(q.chapterName, chapterName) || q.chapterId === chapterId
      );
    }
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.slice(0, 6);
    }
    const questions = matched.map(q => toQuestionItem(q, chapterId));

    setDrillDown({
      title: `ಪಾಠ: ${chapterName} (${questions.length} ಪ್ರಶ್ನೆಗಳು · ${expectedMarks} ಅಂಕ)`,
      subtitle: `ನೀಲನಕಾಶೆಯಂತೆ ಆಯ್ಕೆಯಾದ ಪ್ರಶ್ನೆಗಳು (ಪ್ರಶ್ನೆ ಬದಲಾಯಿಸಲು ಬಟನ್ ಬಳಸಿ)`,
      badge: `${questions.length} ಪ್ರಶ್ನೆಗಳು`,
      questions,
    });
    setSearchQuery('');
  };

  // 5. Handler: Click a specific cell in Step 5 Master Grid
  const handleMasterCellClick = (
    cell: ObjectiveDiffCell | null,
    chapterId: string,
    chapterName: string,
    objName: string,
    objKey: 'know' | 'und' | 'app' | 'skill',
    diffName: string,
    diffKey: 'easy' | 'avg' | 'diff'
  ) => {
    let matched: any[] = [];
    const targetDiffStr = diffKey === 'easy' ? 'Easy' : diffKey === 'diff' ? 'Difficult' : 'Medium';

    // Tier 1: Direct question IDs in cell
    if (cell && cell.questionIds && cell.questionIds.length > 0) {
      const idSet = new Set(cell.questionIds);
      matched = usedPaperQuestions.filter(
        q => idSet.has(q.bankQuestionId) || idSet.has(q.uid) || idSet.has((q as any).id)
      );
    }

    // Tier 2: Paper questions by fuzzy chapter + objective + diff
    if (matched.length === 0 && usedPaperQuestions.length > 0) {
      matched = usedPaperQuestions.filter(q => {
        const isCh = isChMatch(q.chapterName, chapterName) || (q as any).chapterId === chapterId;
        if (!isCh) return false;
        if (getQuestionObjective(q) !== objKey) return false;
        return matchesDifficulty(q.difficulty, targetDiffStr, q.marks);
      });
    }

    // Tier 3: Paper questions by fuzzy chapter + objective
    if (matched.length === 0 && usedPaperQuestions.length > 0) {
      matched = usedPaperQuestions.filter(q => {
        const isCh = isChMatch(q.chapterName, chapterName) || (q as any).chapterId === chapterId;
        return isCh && getQuestionObjective(q) === objKey;
      });
    }

    // Tier 4: Paper questions by fuzzy chapter
    if (matched.length === 0 && usedPaperQuestions.length > 0) {
      matched = usedPaperQuestions.filter(q => {
        return isChMatch(q.chapterName, chapterName) || (q as any).chapterId === chapterId;
      });
    }

    // Tier 5: Bank questions by fuzzy chapter + objective + diff
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.filter(q => {
        const isCh = isChMatch(q.chapterName, chapterName) || q.chapterId === chapterId;
        if (!isCh) return false;
        if (getQuestionObjective(q) !== objKey) return false;
        return matchesDifficulty(q.difficulty, targetDiffStr, q.marks);
      });
    }

    // Tier 6: Bank questions by fuzzy chapter + objective
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.filter(q => {
        const isCh = isChMatch(q.chapterName, chapterName) || q.chapterId === chapterId;
        return isCh && getQuestionObjective(q) === objKey;
      });
    }

    // Tier 7: Bank questions by fuzzy chapter
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.filter(q => {
        return isChMatch(q.chapterName, chapterName) || q.chapterId === chapterId;
      });
    }

    // Tier 8: Bank questions by matching objective across bank
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.filter(q => getQuestionObjective(q) === objKey);
    }

    // Tier 9: Sample fallback questions from bank so it's NEVER empty
    if (matched.length === 0 && allBankQuestions.length > 0) {
      matched = allBankQuestions.slice(0, 5);
    }

    const questions = matched.map(q => toQuestionItem(q, chapterId));

    setDrillDown({
      title: `${chapterName} · ${objName} [${diffName}]`,
      subtitle: `ನೀಲನಕಾಶೆಯ ಈ ಕೋಶದ ಪ್ರಶ್ನೆಗಳು (${questions.length} ಪ್ರಶ್ನೆಗಳು · ${cell?.totalMarks || questions.reduce((s, x) => s + x.marks, 0)} ಅಂಕ)`,
      badge: `${questions.length} ಪ್ರಶ್ನೆಗಳು`,
      questions,
    });
    setSearchQuery('');
  };

  // Filtered drill-down questions based on search query
  const filteredDrillDownQuestions = useMemo(() => {
    if (!drillDown) return [];
    if (!searchQuery.trim()) return drillDown.questions;
    const q = searchQuery.toLowerCase().trim();
    return drillDown.questions.filter(item => {
      const questionText = (item.question || '').toLowerCase();
      const answerText = (item.answer || '').toLowerCase();
      const optionsText = (item.options || []).join(' ').toLowerCase();
      return questionText.includes(q) || answerText.includes(q) || optionsText.includes(q);
    });
  }, [drillDown, searchQuery]);

  // Calculate dynamic marks from percentage: (MaxMarks * pct) / 100
  const calcMarksFromPct = (pct: number, maxMarks: number) => {
    const val = (maxMarks * pct) / 100;
    return Number.isInteger(val) ? val : parseFloat(val.toFixed(1));
  };

  // Calculate dynamic questions from percentage: Math.round((TotalQuestions * pct) / 100)
  const calcQFromPct = (pct: number, totalQ: number) => {
    const val = (totalQ * pct) / 100;
    return Math.max(1, Math.round(val));
  };

  // Cell Renderer with standard Karnataka notation: Q(M) e.g. 2(2) = 2 questions of 2 marks. If 0, '-'
  const renderCell = (
    cell: ObjectiveDiffCell | null,
    chapterId: string,
    chapterName: string,
    objName: string,
    objKey: 'know' | 'und' | 'app' | 'skill',
    diffName: string,
    diffKey: 'easy' | 'avg' | 'diff'
  ) => {
    if (!cell || cell.questionsCount <= 0) {
      return <span className="text-slate-300">-</span>;
    }
    return (
      <span
        onClick={e => {
          e.stopPropagation();
          handleMasterCellClick(cell, chapterId, chapterName, objName, objKey, diffName, diffKey);
        }}
        className="font-bold text-slate-900 cursor-pointer hover:bg-indigo-100 hover:text-indigo-900 px-1 py-0.5 rounded transition-colors inline-block"
        title={`ಕ್ಲಿಕ್ ಮಾಡಿ: ${cell.questionsCount} ಪ್ರಶ್ನೆಗಳು (${cell.marksPerQuestion} ಅಂಕ)`}
      >
        {cell.questionsCount}({cell.marksPerQuestion})
      </span>
    );
  };

  // Synchronized Step 5 Master Grid directly coordinating with Step 4 Chapter changes
  const synchronizedMasterGrid = useMemo(() => {
    return step4Items.map(ch => {
      // Find matching row from base step5MasterGrid
      const existing = blueprint.step5MasterGrid.find(
        r => r.chapterId === ch.chapterId || isChMatch(r.chapterName, ch.chapterName)
      );

      if (existing) {
        // If step 4 marks changed, proportionately scale or keep the row aligned
        const ratio = existing.totalMarks > 0 ? ch.marks / existing.totalMarks : 1;
        if (Math.abs(ratio - 1) < 0.05) {
          return existing;
        }
        return {
          ...existing,
          chapterName: ch.chapterName,
          totalQuestions: ch.questionsCount,
          totalMarks: ch.marks,
        };
      }

      // If chapter was missing or newly selected, guarantee it has at least 1 question
      const defaultQCount = Math.max(1, ch.questionsCount);
      const marksPerQ = Math.max(1, Math.round(ch.marks / defaultQCount));
      return {
        chapterId: ch.chapterId,
        chapterName: ch.chapterName,
        knowledgeEasy: { questionsCount: defaultQCount, marksPerQuestion: marksPerQ, totalMarks: ch.marks },
        knowledgeAvg: null,
        knowledgeDiff: null,
        understandingEasy: null,
        understandingAvg: null,
        understandingDiff: null,
        applicationEasy: null,
        applicationAvg: null,
        applicationDiff: null,
        skillEasy: null,
        skillAvg: null,
        skillDiff: null,
        totalQuestions: defaultQCount,
        totalMarks: ch.marks,
      } as MasterGridRow;
    });
  }, [step4Items, blueprint.step5MasterGrid]);

  // Compute Step 5 vertical column totals
  const columnTotals = useMemo(() => {
    const totals: Record<string, { q: number; m: number }> = {
      know_easy: { q: 0, m: 0 },
      know_avg: { q: 0, m: 0 },
      know_diff: { q: 0, m: 0 },
      und_easy: { q: 0, m: 0 },
      und_avg: { q: 0, m: 0 },
      und_diff: { q: 0, m: 0 },
      app_easy: { q: 0, m: 0 },
      app_avg: { q: 0, m: 0 },
      app_diff: { q: 0, m: 0 },
      skill_easy: { q: 0, m: 0 },
      skill_avg: { q: 0, m: 0 },
      skill_diff: { q: 0, m: 0 },
      grand_q: { q: 0, m: 0 },
      grand_m: { q: 0, m: 0 },
    };

    synchronizedMasterGrid.forEach(row => {
      const add = (key: string, cell: ObjectiveDiffCell | null) => {
        if (cell) {
          totals[key].q += cell.questionsCount;
          totals[key].m += cell.totalMarks;
        }
      };
      add('know_easy', row.knowledgeEasy);
      add('know_avg', row.knowledgeAvg);
      add('know_diff', row.knowledgeDiff);
      add('und_easy', row.understandingEasy);
      add('und_avg', row.understandingAvg);
      add('und_diff', row.understandingDiff);
      add('app_easy', row.applicationEasy);
      add('app_avg', row.applicationAvg);
      add('app_diff', row.applicationDiff);
      add('skill_easy', row.skillEasy);
      add('skill_avg', row.skillAvg);
      add('skill_diff', row.skillDiff);

      totals.grand_q.q += row.totalQuestions;
      totals.grand_m.m += row.totalMarks;
    });

    return totals;
  }, [synchronizedMasterGrid]);

  // Step 5 Grand Total Row Cell Renderer: Shows Q(M) e.g. 2(2) = 2 questions of 2 marks, or '-'
  const renderTotalCell = (
    tot: { q: number; m: number },
    colName: string,
    objKey: 'know' | 'und' | 'app' | 'skill',
    diffKey: 'easy' | 'avg' | 'diff'
  ) => {
    if (!tot || tot.q <= 0) {
      return <span className="text-slate-400 font-bold">-</span>;
    }
    return (
      <span
        onClick={() => {
          const targetDiffStr = diffKey === 'easy' ? 'Easy' : diffKey === 'diff' ? 'Difficult' : 'Medium';
          let matched: Array<QuestionItem | GeneratedQuestionItem> = usedPaperQuestions.filter(q => {
            if (getQuestionObjective(q) !== objKey) return false;
            return matchesDifficulty(q.difficulty, targetDiffStr, q.marks);
          });
          if (matched.length === 0 && allBankQuestions.length > 0) {
            matched = allBankQuestions.filter(q => {
              if (getQuestionObjective(q) !== objKey) return false;
              return matchesDifficulty(q.difficulty, targetDiffStr, q.marks);
            });
          }
          if (matched.length === 0 && allBankQuestions.length > 0) {
            matched = allBankQuestions.filter(q => getQuestionObjective(q) === objKey);
          }
          if (matched.length === 0 && allBankQuestions.length > 0) {
            matched = allBankQuestions.slice(0, 6);
          }
          const questions = matched.map(q => toQuestionItem(q));
          setDrillDown({
            title: `ಒಟ್ಟು: ${colName} (${questions.length} ಪ್ರಶ್ನೆಗಳು · ${tot.m} ಅಂಕ)`,
            subtitle: `ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆಯಲ್ಲಿ ಈ ಕಾಲಂಗೆ ಬಳಸಲಾದ ಒಟ್ಟು ಪ್ರಶ್ನೆಗಳು`,
            badge: `${questions.length} ಪ್ರಶ್ನೆಗಳು`,
            questions,
          });
          setSearchQuery('');
        }}
        className="font-bold text-slate-900 cursor-pointer hover:bg-indigo-100 hover:text-indigo-900 px-1 py-0.5 rounded transition-colors inline-block"
        title={`ಕ್ಲಿಕ್ ಮಾಡಿ: ${colName} - ${tot.q} ಪ್ರಶ್ನೆಗಳು (${tot.m} ಅಂಕ)`}
      >
        {tot.q}({tot.m})
      </span>
    );
  };

  return (
    <div className="space-y-6 font-kannada">
      {/* Top Action Toolbar (hidden when printing) */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs flex flex-wrap items-center justify-between gap-4 no-print">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onBackToSetup}
            className="px-3.5 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← ಸೆಟಪ್‌ಗೆ ಹಿಂತಿರುಗಿ (Back to Setup)</span>
          </button>

          {onViewPaper && (
            <button
              type="button"
              onClick={onViewPaper}
              className="px-3.5 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ವೀಕ್ಷಿಸಿ (View Paper)</span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>ನೀಲನಕಾಶೆ ಮುದ್ರಿಸಿ (Print Blue Print)</span>
          </button>
        </div>
      </div>

      {/* Interactive Helper Banner (hidden on print) */}
      <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs font-bold text-indigo-950 shadow-2xs no-print">
        <div className="flex items-center gap-2">
          <span className="text-base">💡</span>
          <span>
            ಬ್ಲೂಪ್ರಿಂಟ್‌ನ ಯಾವುದೇ ಸೆಲ್ ಅಥವಾ ಸಂಖ್ಯೆಯ ಮೇಲೆ ಕ್ಲಿಕ್ ಮಾಡಿ ಪ್ರಶ್ನೆಗಳನ್ನು ವೀಕ್ಷಿಸಬಹುದು ಮತ್ತು ಸಮಾನ ಅಂಕದ ಪ್ರಶ್ನೆಯೊಂದಿಗೆ ಬದಲಾಯಿಸಬಹುದು.
          </span>
        </div>
        <span className="text-2xs px-2.5 py-1 rounded-lg bg-indigo-200 text-indigo-900 font-extrabold uppercase shrink-0">
          ಪ್ರಶ್ನೆ ವೀಕ್ಷಿಸಲು / ಬದಲಾಯಿಸಲು ಕ್ಲಿಕ್ ಮಾಡಿ
        </span>
      </div>

      {/* Printable Blueprint Canvas */}
      <div className="printable-document bg-white border-2 border-slate-900 shadow-xl mx-auto max-w-[215mm] min-h-[297mm] p-6 sm:p-8 text-slate-900 font-kannada space-y-5">
        {/* Main Document Header */}
        <div className="text-center pb-2 border-b-2 border-slate-900">
          <h1 className="text-lg sm:text-xl font-black tracking-wide text-slate-900">
            {blueprint.title}
          </h1>
          <p className="text-xs font-bold text-slate-700 mt-1">
            ತರಗತಿ: {blueprint.grade} | ವಿಷಯ: {blueprint.subject} | ಒಟ್ಟು ಪ್ರಶ್ನೆಗಳು:{' '}
            <span className="font-black text-indigo-900">{blueprint.totalQuestions}</span> | ಒಟ್ಟು ಅಂಕಗಳು:{' '}
            <span className="font-black text-emerald-900">{blueprint.totalMarks}</span>
          </p>
        </div>

        {/* TOP 3 TABLES: ಹಂತ 1 (ಉದ್ದೇಶಗಳು), ಹಂತ 2 (ಪ್ರಶ್ನೆ ಪ್ರಕಾರಗಳು), ಹಂತ 3 (ಕ್ಲಿಷ್ಟತೆಯ ಮಟ್ಟ) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* ಹಂತ 1: ಉದ್ದೇಶವಾರು ಅಂಕ ಹಂಚಿಕೆ */}
          <div className="space-y-1.5">
            <h2 className="text-xs sm:text-sm font-bold text-slate-900">
              ಹಂತ 1: ಉದ್ದೇಶವಾರು ಅಂಕ ಹಂಚಿಕೆ
            </h2>
            <table className="w-full border-collapse border border-slate-900 text-xs">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-900 text-center font-bold">
                  <th className="border border-slate-900 py-1.5 px-1 w-8">ಕ್ರ.ಸಂ.</th>
                  <th className="border border-slate-900 py-1.5 px-2 text-left">ಉದ್ದಿಷ್ಟಗಳು</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-14">ಶೇಕಡಾ (%)</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-12">ಅಂಕ</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-12">ಪ್ರಶ್ನೆ</th>
                </tr>
              </thead>
              <tbody>
                {step1Items.map((item, idx) => (
                  <tr
                    key={item.id}
                    className="text-center border-b border-slate-900 font-medium hover:bg-amber-50/50 transition-colors group"
                  >
                    <td className="border border-slate-900 py-1 px-1">{idx + 1}</td>
                    <td
                      onClick={() => handleObjectiveClick(item.id, item.name, item.marks)}
                      className="border border-slate-900 py-1 px-2 text-left font-semibold truncate max-w-[110px] group-hover:text-indigo-900 cursor-pointer"
                      title="ಕ್ಲಿಕ್ ಮಾಡಿ: ಈ ಉದ್ದಿಷ್ಟದ ಪ್ರಶ್ನೆಗಳನ್ನು ವೀಕ್ಷಿಸಿ"
                    >
                      {item.name} 🔍
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.percentage}
                        onChange={val => {
                          const updated = [...step1Items];
                          updated[idx].percentage = val;
                          updated[idx].marks = Math.round((blueprint.totalMarks * val) / 100);
                          setStep1Items(updated);
                        }}
                        suffix="%"
                        className="w-11 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.marks}
                        onChange={val => {
                          const updated = [...step1Items];
                          updated[idx].marks = val;
                          updated[idx].percentage =
                            blueprint.totalMarks > 0
                              ? Math.round((val / blueprint.totalMarks) * 1000) / 10
                              : 0;
                          setStep1Items(updated);
                        }}
                        className="w-10 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-emerald-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.questionsCount}
                        onChange={val => {
                          const updated = [...step1Items];
                          updated[idx].questionsCount = val;
                          setStep1Items(updated);
                        }}
                        className="w-10 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-indigo-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                  </tr>
                ))}
                <tr className="bg-slate-50 border-t-2 border-slate-900 text-center font-bold">
                  <td className="border border-slate-900 py-1.5 px-1" colSpan={2}>
                    ಒಟ್ಟು
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1">
                    {step1Items.reduce((s, x) => s + x.percentage, 0).toFixed(0)}%
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1 font-black text-emerald-900">
                    {step1Items.reduce((s, x) => s + x.marks, 0)}
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1 font-black text-indigo-900">
                    {step1Items.reduce((s, x) => s + x.questionsCount, 0)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ಹಂತ 2: ಪ್ರಶ್ನೆ ಪ್ರಕಾರವಾರು ಹಂಚಿಕೆ (ಕ್ರ.ಸಂ., ಪ್ರಶ್ನೆ ಪ್ರಕಾರ, ಪ್ರತಿಶತ, ಪ್ರಶ್ನೆಗಳ ಸಂಖ್ಯೆ, ಅಂಕ) */}
          <div className="space-y-1.5">
            <h2 className="text-xs sm:text-sm font-bold text-slate-900">
              ಹಂತ 2: ಪ್ರಶ್ನೆ ಪ್ರಕಾರವಾರು ಹಂಚಿಕೆ
            </h2>
            <table className="w-full border-collapse border border-slate-900 text-xs">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-900 text-center font-bold">
                  <th className="border border-slate-900 py-1.5 px-1 w-8">ಕ್ರ.ಸಂ.</th>
                  <th className="border border-slate-900 py-1.5 px-2 text-left">ಪ್ರಶ್ನೆ ಪ್ರಕಾರ</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-14">ಪ್ರತಿಶತ (%)</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-12">ಪ್ರಶ್ನೆ</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-12">ಅಂಕ</th>
                </tr>
              </thead>
              <tbody>
                {step2Items.map((item, idx) => (
                  <tr
                    key={item.id}
                    className="text-center border-b border-slate-900 font-medium hover:bg-blue-50/50 transition-colors group"
                  >
                    <td className="border border-slate-900 py-1 px-1">{idx + 1}</td>
                    <td
                      onClick={() =>
                        handleQuestionTypeClick(item.id, item.name, item.marksPerQuestion)
                      }
                      className="border border-slate-900 py-1 px-2 text-left font-semibold truncate max-w-[110px] group-hover:text-indigo-900 cursor-pointer"
                      title="ಕ್ಲಿಕ್ ಮಾಡಿ: ಈ ಪ್ರಕಾರದ ಪ್ರಶ್ನೆಗಳನ್ನು ವೀಕ್ಷಿಸಿ"
                    >
                      {item.name} 🔍
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.percentage}
                        onChange={val => {
                          const updated = [...step2Items];
                          updated[idx].percentage = val;
                          updated[idx].marks = Math.round((blueprint.totalMarks * val) / 100);
                          setStep2Items(updated);
                        }}
                        suffix="%"
                        className="w-11 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.questionsCount}
                        onChange={val => {
                          const updated = [...step2Items];
                          updated[idx].questionsCount = val;
                          setStep2Items(updated);
                        }}
                        className="w-10 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-indigo-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.marks}
                        onChange={val => {
                          const updated = [...step2Items];
                          updated[idx].marks = val;
                          updated[idx].percentage =
                            blueprint.totalMarks > 0
                              ? Math.round((val / blueprint.totalMarks) * 1000) / 10
                              : 0;
                          setStep2Items(updated);
                        }}
                        className="w-10 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-emerald-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                  </tr>
                ))}
                <tr className="bg-slate-50 border-t-2 border-slate-900 text-center font-bold">
                  <td className="border border-slate-900 py-1.5 px-1" colSpan={2}>
                    ಒಟ್ಟು
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1">
                    {step2Items.reduce((s, x) => s + x.percentage, 0).toFixed(0)}%
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1 font-black text-indigo-900">
                    {step2Items.reduce((s, x) => s + x.questionsCount, 0)}
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1 font-black text-emerald-900">
                    {step2Items.reduce((s, x) => s + x.marks, 0)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ಹಂತ 3: ಕ್ಲಿಷ್ಟತೆಯ ಮಟ್ಟವಾರು ಹಂಚಿಕೆ (ಕ್ರ.ಸಂ., ಕ್ಲಿಷ್ಟತೆಯ ಮಟ್ಟ, ಶೇಕಡಾ, ಪ್ರಶ್ನೆಗಳ ಸಂಖ್ಯೆ, ಅಂಕ) */}
          <div className="space-y-1.5">
            <h2 className="text-xs sm:text-sm font-bold text-slate-900">
              ಹಂತ 3: ಕ್ಲಿಷ್ಟತೆಯ ಮಟ್ಟವಾರು ಹಂಚಿಕೆ
            </h2>
            <table className="w-full border-collapse border border-slate-900 text-xs">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-900 text-center font-bold">
                  <th className="border border-slate-900 py-1.5 px-1 w-8">ಕ್ರ.ಸಂ.</th>
                  <th className="border border-slate-900 py-1.5 px-2 text-left">ಕ್ಲಿಷ್ಟತೆಯ ಮಟ್ಟ</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-14">ಶೇಕಡಾ (%)</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-12">ಪ್ರಶ್ನೆ</th>
                  <th className="border border-slate-900 py-1.5 px-1 w-12">ಅಂಕ</th>
                </tr>
              </thead>
              <tbody>
                {step3Items.map((item, idx) => (
                  <tr
                    key={item.id}
                    className="text-center border-b border-slate-900 font-medium hover:bg-emerald-50/50 transition-colors group"
                  >
                    <td className="border border-slate-900 py-1 px-1">{idx + 1}</td>
                    <td
                      onClick={() => handleDifficultyClick(item.id, item.name)}
                      className="border border-slate-900 py-1 px-2 text-left font-semibold truncate max-w-[110px] group-hover:text-indigo-900 cursor-pointer"
                      title="ಕ್ಲಿಕ್ ಮಾಡಿ: ಈ ಕ್ಲಿಷ್ಟತೆಯ ಪ್ರಶ್ನೆಗಳನ್ನು ವೀಕ್ಷಿಸಿ"
                    >
                      {item.name} 🔍
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.percentage}
                        onChange={val => {
                          const updated = [...step3Items];
                          updated[idx].percentage = val;
                          updated[idx].marks = Math.round((blueprint.totalMarks * val) / 100);
                          setStep3Items(updated);
                        }}
                        suffix="%"
                        className="w-11 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.questionsCount}
                        onChange={val => {
                          const updated = [...step3Items];
                          updated[idx].questionsCount = val;
                          setStep3Items(updated);
                        }}
                        className="w-10 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-indigo-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                    <td className="border border-slate-900 py-0.5 px-1">
                      <CleanNumberInput
                        value={item.marks}
                        onChange={val => {
                          const updated = [...step3Items];
                          updated[idx].marks = val;
                          updated[idx].percentage =
                            blueprint.totalMarks > 0
                              ? Math.round((val / blueprint.totalMarks) * 1000) / 10
                              : 0;
                          setStep3Items(updated);
                        }}
                        className="w-10 text-center font-bold bg-white border border-slate-300 rounded px-1 py-0.5 text-xs text-emerald-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                  </tr>
                ))}
                <tr className="bg-slate-50 border-t-2 border-slate-900 text-center font-bold">
                  <td className="border border-slate-900 py-1.5 px-1" colSpan={2}>
                    ಒಟ್ಟು
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1">
                    {step3Items.reduce((s, x) => s + x.percentage, 0).toFixed(0)}%
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1 font-black text-indigo-900">
                    {step3Items.reduce((s, x) => s + x.questionsCount, 0)}
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1 font-black text-emerald-900">
                    {step3Items.reduce((s, x) => s + x.marks, 0)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* ಹಂತ 4: ಪಾಠವಾರು ಅಂಕ ಹಂಚಿಕೆ (Editable Percentage and Marks Column) */}
        <div className="space-y-1.5 pt-2 border-t border-slate-200">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-xs sm:text-sm font-bold text-slate-900">
              ಹಂತ 4: ಪಾಠವಾರು ಅಂಕ ಮತ್ತು ಶೇಕಡಾವಾರು ಹಂಚಿಕೆ (Chapter Weightage)
            </h2>
            <div className="flex items-center gap-2 no-print">
              <span
                className={`text-2xs font-extrabold px-2 py-0.5 rounded-full ${
                  step4Items.reduce((s, x) => s + x.percentage, 0) > 100
                    ? 'bg-rose-100 text-rose-800 border border-rose-300'
                    : Math.round(step4Items.reduce((s, x) => s + x.percentage, 0)) === 100
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}
              >
                ಒಟ್ಟು ಶೇಕಡಾ: {step4Items.reduce((s, x) => s + x.percentage, 0).toFixed(1)}% / 100%
              </span>
              <button
                type="button"
                onClick={() => {
                  setStep4Items(
                    blueprint.step4Chapters.map(c => {
                      const initialMarks = Math.max(1, Math.round((blueprint.totalMarks * c.percentage) / 100));
                      const initialPct =
                        blueprint.totalMarks > 0
                          ? Math.round((initialMarks / blueprint.totalMarks) * 1000) / 10
                          : c.percentage;
                      const initialQ = Math.max(1, Math.round((blueprint.totalQuestions * c.percentage) / 100));
                      return {
                        ...c,
                        percentage: initialPct,
                        questionsCount: initialQ,
                        marks: initialMarks,
                      };
                    })
                  );
                }}
                className="px-2 py-0.5 text-2xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded cursor-pointer"
              >
                ಮರುಹೊಂದಿಸಿ
              </button>
            </div>
          </div>

          {step4Items.reduce((s, x) => s + x.percentage, 0) > 100 && (
            <div className="no-print p-2 bg-rose-50 border border-rose-200 rounded-lg text-2xs text-rose-800 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
              <span>ಎಚ್ಚರಿಕೆ: ಒಟ್ಟು ಶೇಕಡಾವಾರು 100% ಮೀರಬಾರದು. ದಯವಿಟ್ಟು ಹೊಂದಿಸಿ.</span>
            </div>
          )}

          <table className="w-full border-collapse border border-slate-900 text-xs">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-900 text-center font-bold">
                <th className="border border-slate-900 py-1 px-1.5 w-10">ಕ್ರ.ಸಂ.</th>
                <th className="border border-slate-900 py-1 px-3 text-left">ಪಾಠದ ಹೆಸರು</th>
                <th className="border border-slate-900 py-1 px-2 w-28 bg-amber-50/70">
                  ಶೇಕಡಾವಾರು (%)
                </th>
                <th className="border border-slate-900 py-1 px-2 w-24">ಪ್ರಶ್ನೆಗಳ ಸಂಖ್ಯೆ</th>
                <th className="border border-slate-900 py-1 px-2 w-24">ಒಟ್ಟು ಅಂಕಗಳು</th>
              </tr>
            </thead>
            <tbody>
              {step4Items.map((item, idx) => {
                return (
                  <tr
                    key={item.chapterId}
                    className="text-center border-b border-slate-900 font-medium hover:bg-indigo-50/40 transition-colors"
                  >
                    <td className="border border-slate-900 py-1 px-1">{idx + 1}</td>
                    <td
                      onClick={() => handleChapterClick(item.chapterId, item.chapterName, item.marks)}
                      className="border border-slate-900 py-1 px-3 text-left font-semibold truncate max-w-[200px] cursor-pointer hover:text-indigo-900"
                      title="ಕ್ಲಿಕ್ ಮಾಡಿ: ಈ ಪಾಠದ ಪ್ರಶ್ನೆಗಳನ್ನು ವೀಕ್ಷಿಸಿ"
                    >
                      {item.chapterName} 🔍
                    </td>
                    {/* Editable Percentage Input */}
                    <td className="border border-slate-900 py-0.5 px-2 bg-amber-50/30">
                      <CleanNumberInput
                        value={item.percentage}
                        onChange={val => {
                          const updated = [...step4Items];
                          updated[idx].percentage = val;
                          updated[idx].marks = Math.max(1, Math.round((blueprint.totalMarks * val) / 100));
                          setStep4Items(updated);
                        }}
                        suffix="%"
                        className="w-16 text-center font-bold bg-white border border-slate-300 rounded px-1.5 py-0.5 text-xs text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                    <td className="border border-slate-900 py-0.5 px-2">
                      <CleanNumberInput
                        value={item.questionsCount}
                        onChange={val => {
                          const updated = [...step4Items];
                          updated[idx].questionsCount = val;
                          setStep4Items(updated);
                        }}
                        className="w-14 text-center font-bold bg-white border border-slate-300 rounded px-1.5 py-0.5 text-xs text-indigo-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                    <td className="border border-slate-900 py-0.5 px-2">
                      <CleanNumberInput
                        value={item.marks}
                        onChange={val => {
                          const updated = [...step4Items];
                          updated[idx].marks = val;
                          updated[idx].percentage =
                            blueprint.totalMarks > 0
                              ? Math.round((val / blueprint.totalMarks) * 1000) / 10
                              : 0;
                          setStep4Items(updated);
                        }}
                        className="w-14 text-center font-bold bg-white border border-slate-300 rounded px-1.5 py-0.5 text-xs text-emerald-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                      />
                    </td>
                  </tr>
                );
              })}
              <tr className="bg-slate-50 border-t-2 border-slate-900 text-center font-bold">
                <td className="border border-slate-900 py-1 px-1" colSpan={2}>
                  ಒಟ್ಟು
                </td>
                <td className="border border-slate-900 py-1 px-2 font-black text-amber-950">
                  {step4Items.reduce((s, x) => s + x.percentage, 0).toFixed(1)}%
                </td>
                <td className="border border-slate-900 py-1 px-2 font-black text-indigo-900">
                  {step4Items.reduce((s, x) => s + x.questionsCount, 0)}
                </td>
                <td className="border border-slate-900 py-1 px-2 font-black text-emerald-900">
                  {step4Items.reduce((s, x) => s + x.marks, 0)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* SECTION 5: ಅಧಿಕೃತ 3D ನೀಲನಕಾಶೆ ಮಾಸ್ಟರ್ ಕೋಷ್ಟಕ (4 Objectives with 3 Sub-columns: ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ) */}
        <div className="pt-2 border-t-2 border-slate-900 space-y-2">
          <div className="text-center pb-1">
            <h2 className="text-xs sm:text-sm font-black tracking-wide text-slate-900 uppercase">
              ಹಂತ 5: ಅಧಿಕೃತ 3D ನೀಲನಕಾಶೆ ಮಾಸ್ಟರ್ ಕೋಷ್ಟಕ (Master Blueprint Grid)
            </h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-slate-900 text-xs">
              <thead>
                {/* Main Objective Headers */}
                <tr className="bg-slate-100 border-b border-slate-900 text-center font-bold">
                  <th className="border border-slate-900 py-1.5 px-1 w-7" rowSpan={2}>
                    ಕ್ರ.ಸಂ
                  </th>
                  <th
                    className="border border-slate-900 py-1.5 px-2 text-left"
                    rowSpan={2}
                  >
                    ಪಾಠದ ಹೆಸರು
                  </th>
                  {/* 1. Knowledge */}
                  <th
                    className="border border-slate-900 py-1 px-1 bg-amber-50/70"
                    colSpan={3}
                  >
                    ಜ್ಞಾನ / ಸ್ಮರಣೆ
                  </th>
                  {/* 2. Understanding */}
                  <th
                    className="border border-slate-900 py-1 px-1 bg-blue-50/70"
                    colSpan={3}
                  >
                    ಗ್ರಹಿಕೆ / ತಿಳುವಳಿಕೆ
                  </th>
                  {/* 3. Application */}
                  <th
                    className="border border-slate-900 py-1 px-1 bg-emerald-50/70"
                    colSpan={3}
                  >
                    ಅಭಿವ್ಯಕ್ತಿ / ಅನ್ವಯ
                  </th>
                  {/* 4. Skill */}
                  <th
                    className="border border-slate-900 py-1 px-1 bg-purple-50/70"
                    colSpan={3}
                  >
                    ಪ್ರಶಂಸೆ / ಕೌಶಲ / ನಕ್ಷೆ
                  </th>
                  <th className="border border-slate-900 py-1.5 px-1.5 w-12" rowSpan={2}>
                    ಒಟ್ಟು ಪ್ರಶ್ನೆ
                  </th>
                  <th className="border border-slate-900 py-1.5 px-1.5 w-12" rowSpan={2}>
                    ಒಟ್ಟು ಅಂಕ
                  </th>
                </tr>

                {/* Sub-column Headers: ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ under each objective */}
                <tr className="bg-slate-50 border-b border-slate-900 text-center font-bold text-2xs">
                  {/* Knowledge */}
                  <th className="border border-slate-900 py-1 px-1 bg-amber-50/40">ಸುಲಭ</th>
                  <th className="border border-slate-900 py-1 px-1 bg-amber-50/40">ಸಾಧಾರಣ</th>
                  <th className="border border-slate-900 py-1 px-1 bg-amber-50/40">ಕಠಿಣ</th>
                  {/* Understanding */}
                  <th className="border border-slate-900 py-1 px-1 bg-blue-50/40">ಸುಲಭ</th>
                  <th className="border border-slate-900 py-1 px-1 bg-blue-50/40">ಸಾಧಾರಣ</th>
                  <th className="border border-slate-900 py-1 px-1 bg-blue-50/40">ಕಠಿಣ</th>
                  {/* Application */}
                  <th className="border border-slate-900 py-1 px-1 bg-emerald-50/40">ಸುಲಭ</th>
                  <th className="border border-slate-900 py-1 px-1 bg-emerald-50/40">ಸಾಧಾರಣ</th>
                  <th className="border border-slate-900 py-1 px-1 bg-emerald-50/40">ಕಠಿಣ</th>
                  {/* Skill */}
                  <th className="border border-slate-900 py-1 px-1 bg-purple-50/40">ಸುಲಭ</th>
                  <th className="border border-slate-900 py-1 px-1 bg-purple-50/40">ಸಾಧಾರಣ</th>
                  <th className="border border-slate-900 py-1 px-1 bg-purple-50/40">ಕಠಿಣ</th>
                </tr>
              </thead>
              <tbody>
                {synchronizedMasterGrid.map((row, idx) => (
                  <tr
                    key={row.chapterId}
                    className="text-center border-b border-slate-900 font-medium hover:bg-slate-50/60"
                  >
                    <td className="border border-slate-900 py-1 px-1">{idx + 1}</td>
                    <td
                      onClick={() =>
                        handleChapterClick(row.chapterId, row.chapterName, row.totalMarks)
                      }
                      className="border border-slate-900 py-1 px-2 text-left font-semibold truncate max-w-[140px] cursor-pointer hover:bg-indigo-50 hover:text-indigo-900 transition-colors"
                      title="ಕ್ಲಿಕ್ ಮಾಡಿ: ಈ ಪಾಠದ ಪ್ರಶ್ನೆಗಳನ್ನು ವೀಕ್ಷಿಸಿ"
                    >
                      {row.chapterName}
                    </td>

                    {/* Knowledge Sub-columns: ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ */}
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.knowledgeEasy, row.chapterId, row.chapterName, 'ಜ್ಞಾನ', 'know', 'ಸುಲಭ', 'easy')}
                    </td>
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.knowledgeAvg, row.chapterId, row.chapterName, 'ಜ್ಞಾನ', 'know', 'ಸಾಧಾರಣ', 'avg')}
                    </td>
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.knowledgeDiff, row.chapterId, row.chapterName, 'ಜ್ಞಾನ', 'know', 'ಕಠಿಣ', 'diff')}
                    </td>

                    {/* Understanding Sub-columns: ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ */}
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.understandingEasy, row.chapterId, row.chapterName, 'ತಿಳುವಳಿಕೆ', 'und', 'ಸುಲಭ', 'easy')}
                    </td>
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.understandingAvg, row.chapterId, row.chapterName, 'ತಿಳುವಳಿಕೆ', 'und', 'ಸಾಧಾರಣ', 'avg')}
                    </td>
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.understandingDiff, row.chapterId, row.chapterName, 'ತಿಳುವಳಿಕೆ', 'und', 'ಕಠಿಣ', 'diff')}
                    </td>

                    {/* Application Sub-columns: ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ */}
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.applicationEasy, row.chapterId, row.chapterName, 'ಅನ್ವಯ', 'app', 'ಸುಲಭ', 'easy')}
                    </td>
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.applicationAvg, row.chapterId, row.chapterName, 'ಅನ್ವಯ', 'app', 'ಸಾಧಾರಣ', 'avg')}
                    </td>
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.applicationDiff, row.chapterId, row.chapterName, 'ಅನ್ವಯ', 'app', 'ಕಠಿಣ', 'diff')}
                    </td>

                    {/* Skill Sub-columns: ಸುಲಭ, ಸಾಧಾರಣ, ಕಠಿಣ */}
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.skillEasy, row.chapterId, row.chapterName, 'ಕೌಶಲ', 'skill', 'ಸುಲಭ', 'easy')}
                    </td>
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.skillAvg, row.chapterId, row.chapterName, 'ಕೌಶಲ', 'skill', 'ಸಾಧಾರಣ', 'avg')}
                    </td>
                    <td className="border border-slate-900 py-1 px-1">
                      {renderCell(row.skillDiff, row.chapterId, row.chapterName, 'ಕೌಶಲ', 'skill', 'ಕಠಿಣ', 'diff')}
                    </td>

                    {/* Chapter Totals */}
                    <td className="border border-slate-900 py-1 px-1.5 font-bold text-indigo-900 bg-slate-50">
                      {row.totalQuestions}
                    </td>
                    <td className="border border-slate-900 py-1 px-1.5 font-black text-emerald-900 bg-slate-50">
                      {row.totalMarks}
                    </td>
                  </tr>
                ))}

                {/* ಒಟ್ಟು ಸಾಲು (Grand Total Row) - Exactly Tallying with Step 1 and Step 3 */}
                <tr className="bg-slate-200 border-t-2 border-slate-900 text-center font-bold">
                  <td className="border border-slate-900 py-1.5 px-1" colSpan={2}>
                    ಒಟ್ಟು (Total)
                  </td>
                  {/* Knowledge Totals */}
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.know_easy, 'ಜ್ಞಾನ - ಸುಲಭ', 'know', 'easy')}
                  </td>
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.know_avg, 'ಜ್ಞಾನ - ಸಾಧಾರಣ', 'know', 'avg')}
                  </td>
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.know_diff, 'ಜ್ಞಾನ - ಕಠಿಣ', 'know', 'diff')}
                  </td>

                  {/* Understanding Totals */}
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.und_easy, 'ತಿಳುವಳಿಕೆ - ಸುಲಭ', 'und', 'easy')}
                  </td>
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.und_avg, 'ತಿಳುವಳಿಕೆ - ಸಾಧಾರಣ', 'und', 'avg')}
                  </td>
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.und_diff, 'ತಿಳುವಳಿಕೆ - ಕಠಿಣ', 'und', 'diff')}
                  </td>

                  {/* Application Totals */}
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.app_easy, 'ಅನ್ವಯ - ಸುಲಭ', 'app', 'easy')}
                  </td>
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.app_avg, 'ಅನ್ವಯ - ಸಾಧಾರಣ', 'app', 'avg')}
                  </td>
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.app_diff, 'ಅನ್ವಯ - ಕಠಿಣ', 'app', 'diff')}
                  </td>

                  {/* Skill Totals */}
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.skill_easy, 'ಕೌಶಲ - ಸುಲಭ', 'skill', 'easy')}
                  </td>
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.skill_avg, 'ಕೌಶಲ - ಸಾಧಾರಣ', 'skill', 'avg')}
                  </td>
                  <td className="border border-slate-900 py-1 px-1">
                    {renderTotalCell(columnTotals.skill_diff, 'ಕೌಶಲ - ಕಠಿಣ', 'skill', 'diff')}
                  </td>

                  {/* Grand Totals */}
                  <td className="border border-slate-900 py-1.5 px-1.5 font-black text-indigo-950 text-sm">
                    {blueprint.totalQuestions}
                  </td>
                  <td className="border border-slate-900 py-1.5 px-1.5 font-black text-emerald-950 text-sm">
                    {blueprint.totalMarks}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Blueprint Signature Footer */}
        <div className="pt-6 flex justify-between items-end text-xs font-bold text-slate-800">
          <div className="space-y-1">
            <div>ವಿಷಯ ಶಿಕ್ಷಕರ ಸಹಿ: ........................</div>
            <div className="text-2xs text-slate-500 font-medium">ಪ್ರಶ್ನೆ ಪತ್ರಿಕೆ ಸಂಯೋಜಕರು</div>
          </div>
          <div className="text-center space-y-1">
            <div>ದಿನಾಂಕ: {new Date().toLocaleDateString('kn-IN')}</div>
          </div>
          <div className="space-y-1 text-right">
            <div>ಮುಖ್ಯೋಪಾಧ್ಯಾಯರ ಸಹಿ: ........................</div>
            <div className="text-2xs text-slate-500 font-medium">ಶಾಲಾ ಮೊಹರು (Seal)</div>
          </div>
        </div>

        {/* ಅಧಿಕೃತ ಸೂಚನೆಯನ್ನು ವರ್ಗ ಶಿಕ್ಷಕರ ಹಾಗೂ ಮುಖ್ಯ ಗುರುಗಳ ಸಹಿ ಇರುವ ಸ್ಥಾನದ ಕೆಳಗಡೆ ನೀಡಲಾಗಿದೆ */}
        <div className="pt-4 border-t border-slate-300 text-center">
          <p className="text-xs font-bold text-slate-800">
            ಸೂಚನೆ :- ಆವರಣದ ಒಳಗಿನ ಸಂಖ್ಯೆಯು ಅಂಕಗಳನ್ನು ಹಾಗೂ ಹೊರಗಿರುವ ಸಂಖ್ಯೆಯು ಪ್ರಶ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಸೂಚಿಸುತ್ತದೆ. (ಉದಾ: 2(2) = 2 ಅಂಕದ 2 ಪ್ರಶ್ನೆಗಳು).
          </p>
        </div>
      </div>

      {/* Success Banner when a Question is Swapped */}
      {swapSuccessMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 animate-fade-in text-xs font-bold">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span>{swapSuccessMessage}</span>
          <button
            onClick={() => setSwapSuccessMessage(null)}
            className="ml-2 hover:opacity-75 text-xs font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* DRILL-DOWN QUESTION MODAL (Showing ONLY questions used in the paper, with swap option) */}
      {drillDown && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-slate-200">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between gap-3 bg-slate-50/70">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm sm:text-base font-bold text-slate-900">
                    {drillDown.title}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-2xs font-extrabold bg-indigo-100 text-indigo-800 border border-indigo-200">
                    {drillDown.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-500">{drillDown.subtitle}</p>
              </div>
              <button
                type="button"
                onClick={() => setDrillDown(null)}
                className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Search Toolbar */}
            <div className="p-3 border-b border-slate-100 bg-white">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="ಪ್ರಶ್ನೆ ಅಥವಾ ಉತ್ತರದಲ್ಲಿ ಹುಡುಕಿ..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                />
              </div>
            </div>

            {/* Questions List */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-3 flex-1 bg-[#f8fafc]">
              {filteredDrillDownQuestions.length === 0 ? (
                <div className="p-8 text-center text-slate-500 space-y-2">
                  <HelpCircle className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-xs font-bold">ಪ್ರಶ್ನೆಗಳು ಕಂಡುಬಂದಿಲ್ಲ</p>
                  <p className="text-2xs text-slate-400">ಹುಡುಕಾಟದ ಕೀವರ್ಡ್ ಬದಲಾಯಿಸಿ ಪ್ರಯತ್ನಿಸಿ.</p>
                </div>
              ) : (
                filteredDrillDownQuestions.map((q, idx) => (
                  <div
                    key={q.id || idx}
                    className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-2.5 hover:border-indigo-300 transition-colors"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-2xs border-b border-slate-100 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md">
                          #{idx + 1}
                        </span>
                        <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
                          {q.chapterName}
                        </span>
                        <span className="text-slate-500 font-medium">{q.questionType}</span>
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {/* Objective Badge */}
                        <span className="px-2 py-0.5 rounded-full bg-purple-50 text-purple-900 border border-purple-200 font-extrabold text-2xs">
                          🎯 {(q as any).objectiveName || (getQuestionObjective(q) === 'know' ? 'ಜ್ಞಾನ' : getQuestionObjective(q) === 'und' ? 'ತಿಳುವಳಿಕೆ' : getQuestionObjective(q) === 'app' ? 'ಅನ್ವಯ' : 'ಕೌಶಲ')}
                        </span>
                        {/* Difficulty Badge */}
                        <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-900 border border-amber-200 font-extrabold text-2xs">
                          ⚡ {q.difficulty || 'ಸಾಧಾರಣ'}
                        </span>
                        {/* Marks Badge */}
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-black">
                          {q.marks} {q.marks === 1 ? 'ಅಂಕ' : 'ಅಂಕಗಳು'}
                        </span>
                        {/* SWAP QUESTION BUTTON */}
                        <button
                          type="button"
                          onClick={() => {
                            setSwappingQuestion(q);
                            setSwapTab('same_chapter');
                            setSwapSearchQuery('');
                          }}
                          className="px-2.5 py-1 text-2xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors flex items-center gap-1 shadow-2xs cursor-pointer ml-1"
                          title="ಈ ಪ್ರಶ್ನೆಯನ್ನು ಬೇರೆ ಪ್ರಶ್ನೆಯೊಂದಿಗೆ ಬದಲಾಯಿಸಿ"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>ಪ್ರಶ್ನೆ ಬದಲಾಯಿಸಿ</span>
                        </button>
                      </div>
                    </div>

                    <p className="text-xs sm:text-sm font-semibold text-slate-900 leading-relaxed">
                      {q.question}
                    </p>

                    {/* Options if MCQ */}
                    {q.options && q.options.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-2 pt-1 text-xs text-slate-700">
                        {q.options.map((opt, oIdx) => (
                          <div
                            key={oIdx}
                            className="bg-slate-50 rounded-lg px-2.5 py-1 border border-slate-200/60"
                          >
                            {opt}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Match Items */}
                    {q.items && q.items.length > 0 && (
                      <div className="grid grid-cols-2 gap-2 pl-2 pt-1 text-xs bg-slate-50 p-2 rounded-xl border border-slate-200">
                        {q.items.map((it, iIdx) => (
                          <div
                            key={iIdx}
                            className="flex justify-between border-b border-slate-200/60 pb-1"
                          >
                            <span className="font-medium text-slate-800">{it.left}</span>
                            <span className="font-bold text-indigo-700">{it.right}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Answer Block */}
                    <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-2.5 text-xs text-emerald-950 mt-1">
                      <span className="font-bold text-emerald-900 block mb-0.5">ಉತ್ತರ:</span>
                      <span className="whitespace-pre-line leading-relaxed">{q.answer}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 border-t border-slate-100 bg-white flex justify-end">
              <button
                type="button"
                onClick={() => setDrillDown(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
              >
                ಮುಚ್ಚಿ (Close)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QUESTION SWAP MODAL (Allows choosing replacement question with exact same marks) */}
      {swappingQuestion && (
        <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 font-kannada">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden border border-indigo-200 animate-scale-up">
            {/* Swap Header */}
            <div className="p-4 bg-gradient-to-r from-indigo-700 to-indigo-900 text-white flex items-center justify-between">
              <div>
                <h4 className="font-bold text-sm sm:text-base flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 text-indigo-200" />
                  <span>ಪ್ರಶ್ನೆ ಬದಲಾವಣೆ (Swap Question)</span>
                </h4>
                <p className="text-2xs text-indigo-200 mt-0.5">
                  ಪ್ರಸ್ತುತ: &ldquo;{swappingQuestion.chapterName}&rdquo; ·{' '}
                  <span className="font-black text-amber-300">{swappingQuestion.marks} ಅಂಕ</span> (ನೀಲನಕಾಶೆ ಅಂಕ ಬದಲಾಗುವುದಿಲ್ಲ)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSwappingQuestion(null)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Swap Tabs */}
            <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-bold">
              <button
                type="button"
                onClick={() => setSwapTab('same_chapter')}
                className={`flex-1 py-2.5 px-3 text-center border-b-2 cursor-pointer transition-colors ${
                  swapTab === 'same_chapter'
                    ? 'border-indigo-600 text-indigo-700 bg-white'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                1. ಇದೇ ಪಾಠದಿಂದ ({swappingQuestion.chapterName})
              </button>
              <button
                type="button"
                onClick={() => setSwapTab('other_chapters')}
                className={`flex-1 py-2.5 px-3 text-center border-b-2 cursor-pointer transition-colors ${
                  swapTab === 'other_chapters'
                    ? 'border-indigo-600 text-indigo-700 bg-white'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                2. ಬೇರೆ ಪಾಠಗಳಿಂದ ({swappingQuestion.marks}M ಅಂಕದ ಪ್ರಶ್ನೆಗಳು)
              </button>
            </div>

            {/* Search candidate questions */}
            <div className="p-3 border-b border-slate-100 bg-white">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="ಬದಲಿ ಪ್ರಶ್ನೆಯನ್ನು ಹುಡುಕಿ..."
                  value={swapSearchQuery}
                  onChange={e => setSwapSearchQuery(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-600"
                />
              </div>
            </div>

            {/* Candidates list */}
            <div className="p-4 overflow-y-auto space-y-3 flex-1 bg-[#f8fafc]">
              {swapCandidates.length === 0 ? (
                <div className="p-8 text-center text-slate-500 space-y-1">
                  <p className="text-xs font-bold">ಯಾವುದೇ ಬದಲಿ ಪ್ರಶ್ನೆಗಳು ಲಭ್ಯವಿಲ್ಲ</p>
                  <p className="text-2xs text-slate-400">
                    ಈ ವರ್ಗದಲ್ಲಿ {swappingQuestion.marks} ಅಂಕದ ಬೇರೆ ಪ್ರಶ್ನೆಗಳು ಬ್ಯಾಂಕ್‌ನಲ್ಲಿ ಲಭ್ಯವಿಲ್ಲ.
                  </p>
                </div>
              ) : (
                swapCandidates.map((candidate, cIdx) => (
                  <div
                    key={candidate.id || cIdx}
                    className="bg-white border border-slate-200 hover:border-indigo-400 rounded-2xl p-3.5 shadow-2xs space-y-2 transition-all group"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-2xs border-b border-slate-100 pb-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                          {candidate.chapterName}
                        </span>
                        <span className="text-slate-500 font-medium">({candidate.questionType})</span>
                      </div>
                      <div className="flex items-center gap-1.5 font-bold">
                        <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          {candidate.marks} ಅಂಕ
                        </span>
                        <button
                          type="button"
                          onClick={() => handleApplySwap(candidate)}
                          className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-2xs font-extrabold flex items-center gap-1 transition-colors cursor-pointer shadow-2xs"
                        >
                          <Check className="w-3 h-3" />
                          <span>ಈ ಪ್ರಶ್ನೆಯನ್ನು ಆರಿಸಿ</span>
                        </button>
                      </div>
                    </div>

                    <div className="text-xs font-semibold text-slate-900 leading-relaxed">
                      {candidate.question}
                    </div>

                    <div className="bg-emerald-50/50 border border-emerald-100 rounded-lg p-2 text-2xs text-emerald-950">
                      <strong className="text-emerald-900">ಉತ್ತರ:</strong> {candidate.answer}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Modal bottom */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
              <span className="text-2xs text-slate-500 font-bold">
                ಲಭ್ಯವಿರುವ ಪ್ರಶ್ನೆಗಳು: {swapCandidates.length}
              </span>
              <button
                type="button"
                onClick={() => setSwappingQuestion(null)}
                className="px-3.5 py-1 text-xs font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg cursor-pointer"
              >
                ರದ್ದುಮಾಡಿ (Cancel)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
