/**
 * Question Bank Explorer Component
 * Browse and inspect all questions and answers in the loaded question bank.
 * Allows switching Class, Medium, and Subject directly within the window.
 * Author: S R Angadi / M I Nilaji
 */

import React, { useState, useMemo } from 'react';
import { QuestionBank, QuestionItem, IndexEntry } from '../types/questionBank.ts';
import {
  BookOpen,
  Search,
  Filter,
  CheckCircle2,
  ChevronRight,
  HelpCircle,
  Layers,
  GraduationCap,
  Globe,
  Tag,
  ChevronDown,
} from 'lucide-react';
import {
  matchesGrade,
  extractGradeKey,
  canonicalGradeLabel,
  normalizeSubjectName,
  deduceSubjectCode,
} from '../services/dataLoader.ts';

interface QuestionBankExplorerProps {
  bank: QuestionBank;
  availableFiles?: IndexEntry[];
  grade?: string;
  setGrade?: (g: string) => void;
  medium?: string;
  setMedium?: (m: string) => void;
  selectedFileId?: string;
  onSelectFile?: (fileId: string) => void;
}

export function matchesDifficulty(
  diff: string | undefined | null,
  selectedDiff: string,
  rawMarks?: number | string
): boolean {
  if (!selectedDiff || selectedDiff === 'all') return true;
  const d = String(diff || '').toLowerCase().trim();
  const marks = Number(rawMarks) || 1;

  if (selectedDiff === 'Easy' || selectedDiff === 'ಸುಲಭ') {
    if (d.includes('ಸುಲಭ') || d.includes('easy') || d.includes('सरल') || d === '1' || d === '೧') return true;
    if (!d || d === 'ಸಾಮಾನ್ಯ' || d === '-') return marks === 1;
    return false;
  }
  if (selectedDiff === 'Medium' || selectedDiff === 'ಸಾಧಾರಣ') {
    if (
      d.includes('ಸಾಧಾರಣ') ||
      d.includes('medium') ||
      d.includes('avg') ||
      d.includes('average') ||
      d.includes('सामान्य') ||
      d.includes('ಮಧ್ಯಮ') ||
      d === '2' ||
      d === '೨'
    ) return true;
    if (!d || d === 'ಸಾಮಾನ್ಯ' || d === '-') return marks === 2;
    return false;
  }
  if (selectedDiff === 'Difficult' || selectedDiff === 'ಕಠಿಣ') {
    if (
      d.includes('ಕಠಿಣ') ||
      d.includes('difficult') ||
      d.includes('hard') ||
      d.includes('diff') ||
      d.includes('कठिन') ||
      d === '3' ||
      d === '೩' ||
      d === '೪' ||
      d === '4'
    ) return true;
    if (!d || d === 'ಸಾಮಾನ್ಯ' || d === '-') return marks >= 3;
    return false;
  }
  return true;
}

export function matchesObjective(
  obj: string | undefined | null,
  selectedObj: string
): boolean {
  if (!selectedObj || selectedObj === 'all') return true;
  const o = String(obj || '').toLowerCase().trim();
  if (selectedObj === 'knowledge' || selectedObj === 'ಜ್ಞಾನ') {
    return o.includes('ಜ್ಞಾನ') || o.includes('know') || o.includes('recall') || o.includes('ನೆನಪು');
  }
  if (selectedObj === 'understanding' || selectedObj === 'ತಿಳುವಳಿಕೆ') {
    return o.includes('ತಿಳುವಳಿಕೆ') || o.includes('understand') || o.includes('comprehen') || o.includes('ವಿವರಣೆ');
  }
  if (selectedObj === 'application' || selectedObj === 'ಅನ್ವಯ') {
    return o.includes('ಅನ್ವಯ') || o.includes('apply') || o.includes('applic') || o.includes('ಲೆಕ್ಕ');
  }
  if (selectedObj === 'skill' || selectedObj === 'ಕೌಶಲ' || selectedObj === 'ಕೌಶಲ್ಯ') {
    return o.includes('ಕೌಶಲ') || o.includes('ಕೌಶಲ್ಯ') || o.includes('skill') || o.includes('ಚಿತ್ರ');
  }
  return true;
}

export const QuestionBankExplorer: React.FC<QuestionBankExplorerProps> = ({
  bank,
  availableFiles = [],
  grade = '6 ನೇ ತರಗತಿ (Class 6)',
  setGrade,
  medium = 'ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)',
  setMedium,
  selectedFileId,
  onSelectFile,
}) => {
  const [selectedChapterId, setSelectedChapterId] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedDiff, setSelectedDiff] = useState<string>('all');
  const [selectedObj, setSelectedObj] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Current canonical grade label
  const activeGradeLabel = useMemo(() => {
    return canonicalGradeLabel(extractGradeKey(grade));
  }, [grade]);

  // Clean canonical grades list
  const gradeOptions = useMemo(() => {
    const availableKeys = new Set<string>(['6', '7', '8', '9', '10']);
    availableFiles.forEach(f => {
      const k = extractGradeKey(f.gradeKey || f.grade);
      if (k) availableKeys.add(k);
    });

    const orderedKeys = Array.from(availableKeys).sort((a, b) => {
      const numA = parseInt(a, 10);
      const numB = parseInt(b, 10);
      if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
      return a.localeCompare(b);
    });

    return orderedKeys.map(k => canonicalGradeLabel(k));
  }, [availableFiles]);

  // Clean deduplicated subjects for the selected grade
  const subjectsForGrade = useMemo(() => {
    const matching = availableFiles.filter(f => matchesGrade(f, grade));
    const list = matching.length > 0 ? matching : availableFiles;

    const seenCodes = new Set<string>();
    const unique: IndexEntry[] = [];
    for (const f of list) {
      const sCode = deduceSubjectCode(f.subjectCode || f.subject);
      if (!seenCodes.has(sCode)) {
        seenCodes.add(sCode);
        unique.push({
          ...f,
          subject: normalizeSubjectName(f.subject),
          subjectCode: sCode,
        });
      }
    }
    return unique;
  }, [availableFiles, grade]);

  // Extract all unique question types
  const allQuestionTypes = useMemo(() => {
    const types = new Set<string>();
    bank.chapters.forEach(ch => {
      ch.questions.forEach(q => {
        if (q.questionType) types.add(q.questionType);
      });
    });
    return Array.from(types);
  }, [bank]);

  // Extract all questions with filter
  const filteredQuestions = useMemo(() => {
    let list: QuestionItem[] = [];

    bank.chapters.forEach(ch => {
      if (selectedChapterId !== 'all' && ch.chapterId !== selectedChapterId) {
        return;
      }
      ch.questions.forEach(q => {
        // Type filter
        if (selectedType !== 'all' && q.questionType !== selectedType) {
          return;
        }
        // Diff filter using unified matcher
        if (!matchesDifficulty(q.difficulty, selectedDiff, q.marks)) {
          return;
        }
        // Objective filter
        if (!matchesObjective(q.objective || (q as any).objectiveName, selectedObj)) {
          return;
        }
        // Search query
        if (searchQuery.trim()) {
          const qText = (q.question || '').toLowerCase();
          const aText = (q.answer || '').toLowerCase();
          const s = searchQuery.toLowerCase().trim();
          if (!qText.includes(s) && !aText.includes(s)) {
            return;
          }
        }

        list.push(q);
      });
    });

    return list;
  }, [bank, selectedChapterId, selectedType, selectedDiff, selectedObj, searchQuery]);

  return (
    <div className="space-y-6 font-kannada">
      {/* 1. Header Card with Class, Medium & Subject Quick Switcher */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-3 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              <span>ಪ್ರಶ್ನೆ ಭಂಡಾರ ವೀಕ್ಷಕ (Question Bank Explorer)</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {bank.metadata.grade} · {bank.metadata.subject} — ಒಟ್ಟು {bank.chapters.length} ಅಧ್ಯಾಯಗಳು ಮತ್ತು{' '}
              {bank.chapters.reduce((sum, c) => sum + (c.questions?.length || 0), 0)} ಪ್ರಶ್ನೆಗಳು.
            </p>
          </div>
          <span className="px-3 py-1 bg-indigo-50 text-indigo-700 font-bold text-xs rounded-xl border border-indigo-200">
            {filteredQuestions.length} ಪ್ರಶ್ನೆಗಳು ಪಟ್ಟಿಮಾಡಲಾಗಿದೆ
          </span>
        </div>

        {/* Top Direct Selection Toolbar: Class, Medium, Subject in the same window */}
        {setGrade && onSelectFile && (
          <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            {/* 1. Class selector */}
            <div>
              <label className="block text-2xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                <span>ತರಗತಿ (Class)</span>
              </label>
              <div className="relative">
                <select
                  value={activeGradeLabel}
                  onChange={e => setGrade && setGrade(canonicalGradeLabel(extractGradeKey(e.target.value)))}
                  className="w-full appearance-none bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-800 pr-7 focus:ring-1 focus:ring-indigo-600 focus:outline-hidden cursor-pointer"
                >
                  {gradeOptions.map(g => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-2.5 pointer-events-none" />
              </div>
            </div>

            {/* 2. Medium selector */}
            <div>
              <label className="block text-2xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Globe className="w-3.5 h-3.5 text-emerald-600" />
                <span>ಮಾಧ್ಯಮ (Medium)</span>
              </label>
              <div className="relative">
                <select
                  value={medium}
                  onChange={e => setMedium && setMedium(e.target.value)}
                  className="w-full appearance-none bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-800 pr-7 focus:ring-1 focus:ring-indigo-600 focus:outline-hidden cursor-pointer"
                >
                  <option value="ಕನ್ನಡ ಮಾಧ್ಯಮ (State Syllabus)">ಕನ್ನಡ ಮಾಧ್ಯಮ (Kannada Medium)</option>
                  <option value="English Medium (State Syllabus)">English Medium</option>
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-2.5 pointer-events-none" />
              </div>
            </div>

            {/* 3. Subject selector */}
            <div>
              <label className="block text-2xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                <span>ವಿಷಯ (Subject)</span>
              </label>
              <div className="relative">
                <select
                  value={selectedFileId}
                  onChange={e => onSelectFile && onSelectFile(e.target.value)}
                  className="w-full appearance-none bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-800 pr-7 focus:ring-1 focus:ring-indigo-600 focus:outline-hidden cursor-pointer"
                >
                  {subjectsForGrade.map(file => (
                    <option key={file.id} value={file.id}>
                      {normalizeSubjectName(file.subject)} {file.isUserGenerated ? '★ (ಉಳಿಸಿದ)' : ''}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-2.5 pointer-events-none" />
              </div>
            </div>
          </div>
        )}

        {/* Filter Toolbar for questions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs pt-1">
          {/* Chapter selector */}
          <div>
            <label className="block text-2xs font-bold text-slate-700 mb-1">
              ಅಧ್ಯಾಯ (Chapter)
            </label>
            <select
              value={selectedChapterId}
              onChange={e => setSelectedChapterId(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs font-medium text-slate-800"
            >
              <option value="all">ಎಲ್ಲಾ ಅಧ್ಯಾಯಗಳು ({bank.chapters.length})</option>
              {bank.chapters.map(ch => (
                <option key={ch.chapterId} value={ch.chapterId}>
                  {ch.chapterName} ({ch.questions.length})
                </option>
              ))}
            </select>
          </div>

          {/* Question type selector */}
          <div>
            <label className="block text-2xs font-bold text-slate-700 mb-1">
              ಪ್ರಶ್ನೆ ವಿಧ (Type)
            </label>
            <select
              value={selectedType}
              onChange={e => setSelectedType(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs font-medium text-slate-800"
            >
              <option value="all">ಎಲ್ಲಾ ವಿಧಗಳು ({allQuestionTypes.length})</option>
              {allQuestionTypes.map(type => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          {/* Difficulty selector (Working accurately across Kannada & English & Hindi) */}
          <div>
            <label className="block text-2xs font-bold text-slate-700 mb-1">
              ಕ್ಲಿಷ್ಟತೆ (Difficulty)
            </label>
            <select
              value={selectedDiff}
              onChange={e => setSelectedDiff(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs font-medium text-slate-800"
            >
              <option value="all">ಎಲ್ಲಾ ಹಂತಗಳು (All)</option>
              <option value="Easy">ಸುಲಭ (Easy)</option>
              <option value="Medium">ಸಾಧಾರಣ / ಮಧ್ಯಮ (Medium)</option>
              <option value="Difficult">ಕಠಿಣ (Difficult)</option>
            </select>
          </div>

          {/* Objective selector (ಜ್ಞಾನ, ತಿಳುವಳಿಕೆ, ಅನ್ವಯ, ಕೌಶಲ) */}
          <div>
            <label className="block text-2xs font-bold text-slate-700 mb-1">
              ಉದ್ದಿಷ್ಟ (Objective)
            </label>
            <select
              value={selectedObj}
              onChange={e => setSelectedObj(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs font-medium text-slate-800"
            >
              <option value="all">ಎಲ್ಲಾ ಉದ್ದಿಷ್ಟಗಳು (All)</option>
              <option value="knowledge">ಜ್ಞಾನ (Knowledge)</option>
              <option value="understanding">ತಿಳುವಳಿಕೆ (Understanding)</option>
              <option value="application">ಅನ್ವಯ (Application)</option>
              <option value="skill">ಕೌಶಲ (Skill)</option>
            </select>
          </div>

          {/* Search box */}
          <div>
            <label className="block text-2xs font-bold text-slate-700 mb-1">
              ಪ್ರಶ್ನೆ ಹುಡುಕಿ (Search)
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="ಪ್ರಶ್ನೆ ಅಥವಾ ಉತ್ತರ..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-lg pl-8 pr-2.5 py-2 text-xs text-slate-800 placeholder-slate-400"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* Questions Listing */}
      <div className="space-y-3">
        {filteredQuestions.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500 space-y-2">
            <HelpCircle className="w-8 h-8 text-slate-400 mx-auto" />
            <p className="font-bold text-sm">ಯಾವುದೇ ಪ್ರಶ್ನೆಗಳು ಕಂಡುಬಂದಿಲ್ಲ</p>
            <p className="text-xs">ದಯವಿಟ್ಟು ಫಿಲ್ಟರ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಿ ಅಥವಾ ಹುಡುಕಾಟವನ್ನು ತೆರವುಗೊಳಿಸಿ.</p>
            <button
              onClick={() => {
                setSelectedChapterId('all');
                setSelectedType('all');
                setSelectedDiff('all');
                setSelectedObj('all');
                setSearchQuery('');
              }}
              className="mt-2 px-3 py-1 text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
            >
              ಎಲ್ಲಾ ಫಿಲ್ಟರ್ ತೆರವುಗೊಳಿಸಿ
            </button>
          </div>
        ) : (
          filteredQuestions.map((q, idx) => (
            <div
              key={q.id || `${q.chapterId}_${idx}`}
              className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs space-y-2 hover:border-indigo-300 transition-colors"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md">
                    #{idx + 1}
                  </span>
                  <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
                    {q.chapterName}
                  </span>
                  {q.objective && (
                    <span className="font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100 text-2xs">
                      {q.objective}
                    </span>
                  )}
                  {q.difficulty && (
                    <span className="font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-100 text-2xs">
                      {q.difficulty}
                    </span>
                  )}
                  <span className="text-slate-500 font-medium">({q.questionType})</span>
                </div>
                <div className="flex items-center gap-2 font-bold">
                  <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                    {q.marks} {q.marks === 1 ? 'ಅಂಕ' : 'ಅಂಕಗಳು'}
                  </span>
                </div>
              </div>

              {/* Question Text */}
              <div className="text-slate-900 font-semibold text-xs sm:text-sm leading-relaxed">
                {q.question}
              </div>

              {/* Options if MCQ */}
              {q.options && q.options.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-3 pt-1 text-xs text-slate-700">
                  {q.options.map((opt, oIdx) => (
                    <div key={oIdx} className="bg-slate-50 rounded-lg px-2.5 py-1 border border-slate-200/60">
                      {opt}
                    </div>
                  ))}
                </div>
              )}

              {/* Match Items */}
              {q.items && q.items.length > 0 && (
                <div className="grid grid-cols-2 gap-2 pl-3 pt-1 text-xs bg-slate-50 p-2 rounded-xl border border-slate-200">
                  {q.items.map((it, iIdx) => (
                    <div key={iIdx} className="flex justify-between border-b border-slate-200/60 pb-1">
                      <span className="font-medium text-slate-800">{it.left}</span>
                      <span className="font-bold text-indigo-700">{it.right}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Answer Block */}
              <div className="bg-emerald-50/60 border border-emerald-200/60 rounded-xl p-2.5 text-xs text-emerald-950 mt-1">
                <span className="font-bold text-emerald-900 block mb-0.5">ಉತ್ತರ:</span>
                <span className="whitespace-pre-line leading-relaxed">{q.answer}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
